# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Structure

```text
artifacts-monorepo/
├── artifacts/              # Deployable applications
│   ├── api-server/         # Express API server
│   └── real-estate-card/   # React + Vite PWA — main product
├── lib/                    # Shared libraries
│   ├── api-spec/           # OpenAPI spec + Orval codegen config
│   ├── api-client-react/   # Generated React Query hooks
│   ├── api-zod/            # Generated Zod schemas from OpenAPI
│   └── db/                 # Drizzle ORM schema + DB connection
├── scripts/                # Utility scripts
└── pnpm-workspace.yaml
```

---

# بطاقة عقارية — وصف المشروع الكامل

## ما هو التطبيق
تطبيق ويب موبايل (iPhone-first) لسمسار عقاري اسمه صاحب المشروع.
يبني بطاقات عقارية احترافية لعرضها على الزبائن عبر واتساب.
الشركة: **شقق وأراضي المستقبل** — لها شعار (مفتاح ذهبي + بيت أخضر).

## الألوان
- أخضر غامق: `#1d5c28` (G_DARK)
- أخضر وسط: `#2a8040` (G_MID)
- ذهبي عميق: `#b8912a` (AU_DEEP)
- ذهبي نص: `#d4af37` (AU_TEXT)
- كريمي: `#f5ecd4` (CREAM)
- الحدود: `2px solid #b8912a`

## الملف الرئيسي
`artifacts/real-estate-card/src/pages/home.tsx` — كل شيء في ملف واحد.

## مكونات البطاقة (من فوق لتحت)
1. **رأس الصفحة**: شعار الشركة + اسمها + وصفها
2. **شريط اسم المشروع**: خلفية ذهبية
3. **جدول الطوابق**: أعمدة (الطابق، المساحة، السعر) — `<table>` حقيقي بحدود صلبة
4. **قسم موحّد** في أسفل: رقم الهاتف يسار | ملاحظة الأجور + الملاحظة التسويقية يمين

## حقول خارج البطاقة (لا تظهر في الصورة المصدّرة)
- **المنطقة** 📍: للأرشفة والبحث
- **صاحب المشروع (سري)** 🔒: معلومة خاصة للسمسار فقط

## الميزات الرئيسية
| الميزة | التفاصيل |
|--------|----------|
| **تعديل النصوص** | اضغط على أي نص → bottom-sheet modal يفتح خارج البطاقة |
| **إضافة/حذف صفوف** | زر "صف" في الأعلى لإضافة، سلة حمراء في كل صف للحذف |
| **تصدير الصورة** | `html-to-image` بـ pixelRatio:3، الشعار يتحول base64، السلات والحدود مخفية |
| **حفظ في الأرشيف** | localStorage بـ key `real_estate_archive_v1` |
| **البحث** | في الأرشيف: بحث بالمنطقة أو اسم المشروع أو اسم المالك |
| **تصدير جماعي** | حدد بطاقات متعددة → تصدير واحدة وراء الثانية تلقائياً |
| **بطاقة جديدة** | زر "جديد" يمسح الحقول ويبدأ من الصفر |
| **تحديث** | لما تكون على بطاقة محفوظة الزر يقول "تحديث" بدل "حفظ" |

## منطق الأرشيف (localStorage)
```ts
interface SavedCard {
  id: string;        // unique ID من Date.now() + random
  savedAt: number;   // timestamp
  region: string;    // المنطقة
  owner: string;     // صاحب المشروع (سري)
  data: CardData;    // بيانات البطاقة كاملة
}
```
التعرف على البطاقة يعتمد على `currentCardId` state — وليس على اسم المشروع.

## منطق التصدير الجماعي
- يحمّل بيانات كل بطاقة في `data` state
- ينتظر 700ms للرندر
- يصدّر من `cardRef` (البطاقة الرئيسية المرئية)
- يحفظ بيانات البطاقة الأصلية ويرجع إليها بعد الانتهاء

## تفاصيل تقنية مهمة
- الشعار: `src/assets/logo.jpeg` → يتحول لـ base64 عبر `useBase64Image` hook (ضروري لـ html-to-image)
- العناصر المخفية عند التصدير: `data-export-hide="true"` على أزرار الحذف
- التصدير يشتغل مرتين (الأولى warm-up cache، الثانية للنتيجة النظيفة)
- الخط: Cairo/Tajawal/Arial

## ما يجب الحفاظ عليه عند أي تطوير
- بيانات المستخدم محفوظة في **localStorage فقط** — أي تغيير في الكود لا يمسها
- لا تغيّر `STORAGE_KEY = "real_estate_archive_v1"` إلا إذا كان ضرورياً (وإلا تضيع البيانات)
- البطاقة المرئية في `cardRef` هي ما يُصدَّر — لا تضع عناصر مرئية خارج حدودها بدون `data-export-hide`

## المناطق الثمانية التي يشتغل فيها السمسار
غير معروفة بدقة — يدخلها المستخدم يدوياً في حقل المنطقة.

## لغة الواجهة
عربية كاملة، اتجاه RTL، خط Cairo.
