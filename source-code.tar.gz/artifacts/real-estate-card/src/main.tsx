import { createRoot } from "react-dom/client";
import { Component, type ReactNode } from "react";
import App from "./App";
import "./index.css";

/* ── Global JS error catcher ── */
const ERRORS: string[] = [];
window.onerror = (msg, src, line, col, err) => {
  ERRORS.push(`${msg} @ ${src}:${line}:${col}\n${err?.stack ?? ""}`);
};
window.onunhandledrejection = (e) => {
  ERRORS.push(`Unhandled Promise: ${e.reason}`);
};

/* ── Error Boundary ── */
class ErrorBoundary extends Component<{ children: ReactNode }, { error: string | null }> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { error: null };
  }
  static getDerivedStateFromError(err: Error) {
    return { error: err?.message ?? String(err) };
  }
  componentDidCatch(err: Error, info: { componentStack: string }) {
    console.error("React Error Boundary caught:", err, info);
  }
  render() {
    if (this.state.error) {
      return (
        <div dir="rtl" style={{
          minHeight: "100vh", background: "#0f2b18", color: "#e0b830",
          fontFamily: "monospace", padding: 24, display: "flex", flexDirection: "column", gap: 16
        }}>
          <h1 style={{ fontSize: 20, fontWeight: 900, color: "#f87171" }}>⚠ خطأ في التطبيق</h1>
          <pre style={{ fontSize: 12, color: "#fca5a5", whiteSpace: "pre-wrap", wordBreak: "break-all" }}>
            {this.state.error}
          </pre>
          {ERRORS.map((e, i) => (
            <pre key={i} style={{ fontSize: 11, color: "#fdba74", whiteSpace: "pre-wrap", wordBreak: "break-all" }}>{e}</pre>
          ))}
          <button onClick={() => window.location.reload()}
            style={{ background: "#b8912a", color: "#0f2b18", fontWeight: 900, padding: "12px 24px",
                     borderRadius: 12, border: "none", fontSize: 16, cursor: "pointer" }}>
            إعادة المحاولة
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

createRoot(document.getElementById("root")!).render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);
