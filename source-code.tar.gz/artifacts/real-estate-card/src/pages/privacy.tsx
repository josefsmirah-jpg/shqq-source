export default function Privacy() {
  return (
    <div dir="rtl" style={{
      minHeight: "100vh",
      background: "#1d5c28",
      color: "#f5ecd4",
      fontFamily: "'IBM Plex Sans Arabic', sans-serif",
      padding: "24px 20px",
      maxWidth: 640,
      margin: "0 auto",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 24 }}>
        <button
          onClick={() => window.history.back()}
          style={{
            background: "rgba(255,255,255,0.1)",
            border: "none",
            borderRadius: 8,
            color: "#f5ecd4",
            padding: "8px 14px",
            cursor: "pointer",
            fontSize: 14,
          }}
        >
          ← رجوع
        </button>
        <h1 style={{ fontSize: 20, fontWeight: 800, color: "#e0b830", margin: 0 }}>
          سياسة الخصوصية
        </h1>
      </div>

      <div style={{
        background: "rgba(0,0,0,0.2)",
        borderRadius: 16,
        padding: "20px 18px",
        lineHeight: 1.8,
        fontSize: 15,
        display: "flex",
        flexDirection: "column",
        gap: 16,
      }}>
        <p style={{ color: "#c9b88a", fontSize: 13 }}>
          آخر تحديث: مارس 2026
        </p>

        <section>
          <h2 style={{ color: "#e0b830", fontSize: 16, fontWeight: 700, marginBottom: 6 }}>مقدمة</h2>
          <p>
            يوفر تطبيق <strong>شقق وأراضي المستقبل</strong> منصة لعرض البطاقات العقارية
            وتبادل المعلومات العقارية بين الموظفين والعملاء. نلتزم بحماية خصوصيتك وأمان
            بياناتك.
          </p>
        </section>

        <section>
          <h2 style={{ color: "#e0b830", fontSize: 16, fontWeight: 700, marginBottom: 6 }}>البيانات التي نجمعها</h2>
          <ul style={{ paddingRight: 20, margin: 0 }}>
            <li>معلومات التواصل (الاسم، رقم الهاتف) عند تقديم طلب عقاري</li>
            <li>بيانات الإعلانات العقارية (الموقع، السعر، المساحة)</li>
            <li>الصور المرفقة مع البطاقات العقارية</li>
          </ul>
        </section>

        <section>
          <h2 style={{ color: "#e0b830", fontSize: 16, fontWeight: 700, marginBottom: 6 }}>كيف نستخدم البيانات</h2>
          <ul style={{ paddingRight: 20, margin: 0 }}>
            <li>عرض البطاقات العقارية للزوار</li>
            <li>التواصل بين المهتمين وأصحاب الإعلانات</li>
            <li>إدارة الطلبات والإعلانات المميزة</li>
          </ul>
        </section>

        <section>
          <h2 style={{ color: "#e0b830", fontSize: 16, fontWeight: 700, marginBottom: 6 }}>الأمان</h2>
          <p>
            تُخزَّن جميع البيانات بشكل آمن على خوادم محمية. لا نشارك معلوماتك الشخصية
            مع أي طرف ثالث دون موافقتك.
          </p>
        </section>

        <section>
          <h2 style={{ color: "#e0b830", fontSize: 16, fontWeight: 700, marginBottom: 6 }}>حقوقك</h2>
          <p>
            يحق لك طلب حذف بياناتك أو تعديلها في أي وقت عبر التواصل معنا.
          </p>
        </section>

        <section>
          <h2 style={{ color: "#e0b830", fontSize: 16, fontWeight: 700, marginBottom: 6 }}>التواصل</h2>
          <p>
            للاستفسارات المتعلقة بالخصوصية تواصل معنا عبر واتساب:{" "}
            <a href="https://wa.me/962798561011" style={{ color: "#e0b830" }}>
              0798561011
            </a>
          </p>
        </section>
      </div>
    </div>
  );
}
