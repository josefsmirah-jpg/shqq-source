import { useRef, useState, useEffect, useCallback, createElement, type ChangeEvent } from "react";
import { createRoot } from "react-dom/client";
import { flushSync } from "react-dom";
import { toPng } from "html-to-image";
import {
  Download, Trash2, Plus, X, Check, Archive, Save,
  FilePlus, Search, ChevronRight, Lock, CheckSquare, Square, ImageDown,
  Users, UserPlus, LogOut, Building2, KeyRound, FileText, Phone,
  MapPin, Home as HomeIcon, Send, ShieldCheck, User, Eye, EyeOff, Pencil,
  BarChart2, Camera, Share2, Images, RefreshCw, Gift, Star, Crown,
} from "lucide-react";
import logoSrc from "../assets/logo.jpeg";

/* ─── Colour tokens ──────────────────────────────────────────────── */
/** Convert Arabic-Indic and Persian digits (٠١٢٣...) to Latin digits (0123...) */
const normalizeNums = (s: string) =>
  s.replace(/[\u0660-\u0669\u06F0-\u06F9]/g, d =>
    String(d.charCodeAt(0) - (d.charCodeAt(0) >= 0x06F0 ? 0x06F0 : 0x0660))
  );

const G_DARK  = "#1d5c28";
const G_MID   = "#2a8040";
const AU_DEEP  = "#b8912a";
const AU_MID   = "#c9a227";
const AU_BRT   = "#e0b830";
const AU_TEXT  = "#d4af37";
const CREAM    = "#f5ecd4";
const CREAM_D  = "#c9b88a";
const BORDER   = `2px solid ${AU_DEEP}`;
const FONT     = "'Cairo','Tajawal','Arial',sans-serif";

/* ─── Types ──────────────────────────────────────────────────────── */
interface Floor { id: number; name: string; area: string; price: string; }
interface CardData {
  companyName: string; subtitle: string; projectName: string;
  phone: string; note1: string; note2: string; floors: Floor[];
  description?: string;
}
interface SavedCard {
  id: string; savedAt: number; region: string; owner: string; data: CardData;
  cardNum: number;
  guestPhone?: string;
  ownerContact?: string;
  employeeId?: string;
  employeeName?: string;
  companyName?: string;
}
interface Employee { id: string; username: string; name: string; }
interface EmployeeStats {
  employeeId: string; employeeName: string; total: number; last24h: number;
}
interface Submission {
  id: string; submittedAt: number; ownerType: string; propertyType: string;
  region: string; price: string; floor: string; area: string;
  contactName: string; phone: string; description: string;
  ownerContact?: string;
  status: "pending" | "approved" | "rejected";
  submittedBy: "guest" | "employee" | "company";
  cardData?: CardData;
  cardRegion?: string;
  cardNum?: number;
  employeeId?: string;
  employeeName?: string;
  companyName?: string;
}
type Role = "guest" | "employee" | "admin" | "company";
interface GuestProfile { name: string; phone: string; }
interface CompanyProfile { name: string; phone: string; }
interface FeaturedAd {
  id: number; submissionId: string; companyName: string; companyPhone: string;
  planDays: number; planLabel: string; planPrice: number;
  status: "pending" | "approved" | "rejected";
  submittedAt: number; approvedAt: number | null; expiresAt: number | null;
  contactsCount?: number;
  cardNum?: number | null;
}
interface ContactLog {
  id: number; featuredAdId: number;
  visitorPhone: string; ownerPhone: string; ownerName: string;
  contactedAt: number;
}
const PLANS = [
  { label: "إعلان مميز — شهر واحد",    days: 30,  price: 75  },
  { label: "إعلان مميز — ثلاثة أشهر", days: 90,  price: 200 },
  { label: "إعلان مميز — ستة أشهر",   days: 180, price: 350 },
  { label: "إعلان مميز — سنة كاملة",  days: 365, price: 600 },
];

let nextId = 100;

/* ─── API helpers ─────────────────────────────────────────────────── */
const API = "/api";
const J   = { "Content-Type": "application/json" };

async function apiFetch<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, init);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json() as Promise<T>;
}

const fetchArchive  = () => apiFetch<SavedCard[]>(`${API}/archive`);
const postCard      = (c: SavedCard)  => apiFetch<unknown>(`${API}/archive`, { method: "POST", headers: J, body: JSON.stringify(c) });
const deleteCardApi = (id: string)    => apiFetch<unknown>(`${API}/archive/${id}`, { method: "DELETE" });

const fetchSubmissions  = () => apiFetch<Submission[]>(`${API}/submissions`);
const fetchSubmissionsByPhone = (phone: string) => apiFetch<Submission[]>(`${API}/submissions/by-phone/${encodeURIComponent(phone)}`);
const postSubmission    = (s: Submission) => apiFetch<unknown>(`${API}/submissions`, { method: "POST", headers: J, body: JSON.stringify(s) });
const patchSubmission   = (id: string, u: Partial<Submission>) => apiFetch<unknown>(`${API}/submissions/${id}`, { method: "PUT",  headers: J, body: JSON.stringify(u) });
const deleteSubmissionApi = (id: string) => apiFetch<unknown>(`${API}/submissions/${id}`, { method: "DELETE" });

const fetchEmployees = () => apiFetch<Employee[]>(`${API}/employees`);
const postEmployee   = (e: {id:string;username:string;password:string;name:string}) =>
  apiFetch<unknown>(`${API}/employees`, { method: "POST", headers: J, body: JSON.stringify(e) });
const putEmployee    = (id: string, u: {username?:string;password?:string;name?:string}) =>
  apiFetch<unknown>(`${API}/employees/${id}`, { method: "PUT",  headers: J, body: JSON.stringify(u) });
const deleteEmployeeApi = (id: string) => apiFetch<unknown>(`${API}/employees/${id}`, { method: "DELETE" });
const verifyEmployeeApi = (username: string, password: string) =>
  apiFetch<{ok:boolean;id?:string;name?:string}>(`${API}/employees/verify`, { method: "POST", headers: J, body: JSON.stringify({ username, password }) });

const getAdminApi  = () => apiFetch<{username?:string;configured:boolean}>(`${API}/admin`);
const verifyAdminApi = (username: string, password: string) =>
  apiFetch<{ok:boolean}>(`${API}/admin/verify`, { method: "POST", headers: J, body: JSON.stringify({ username, password }) });
const putAdminApi  = (username: string, password: string) =>
  apiFetch<unknown>(`${API}/admin`, { method: "PUT",  headers: J, body: JSON.stringify({ username, password }) });

const fetchEmployeeStats = () => apiFetch<EmployeeStats[]>(`${API}/stats/employees`);
const fetchOverviewStats = () => apiFetch<{totalCards:number;totalApproved:number}>(`${API}/stats/overview`);
const fetchVisitorCount  = () => apiFetch<{total:number}>(`${API}/visitors/count`);
const deleteAllVisitors  = () => apiFetch<{ok:boolean}>(`${API}/visitors`, { method: "DELETE" });
const pushToProd    = () => apiFetch<{ok:boolean;employeeCount:number}>(`${API}/sync/push-to-prod`,    { method: "POST", headers: J });
const pullFromProd  = () => apiFetch<{ok:boolean;employeeCount:number}>(`${API}/sync/pull-from-prod`, { method: "POST", headers: J });
const postVisitor = (v: {id:string;name:string;phone:string}) =>
  apiFetch<unknown>(`${API}/visitors`, { method: "POST", headers: J, body: JSON.stringify(v) });
const postCompanyVisitor = (v: {id:string;companyName:string;phone:string}) =>
  apiFetch<unknown>(`${API}/company-visitors`, { method: "POST", headers: J, body: JSON.stringify(v) });
const fetchCompanyVisitorCount = () => apiFetch<{total:number}>(`${API}/company-visitors/count`);

const fetchFeaturedAds      = () => apiFetch<FeaturedAd[]>(`${API}/featured-ads`);
const fetchFeaturedApproved = () => apiFetch<FeaturedAd[]>(`${API}/featured-ads/approved`);
const postFeaturedAd        = (d: object) => apiFetch<unknown>(`${API}/featured-ads`, { method: "POST", headers: J, body: JSON.stringify(d) });
const approveFeaturedApi    = (id: number) => apiFetch<unknown>(`${API}/featured-ads/${id}/approve`, { method: "PATCH" });
const rejectFeaturedApi     = (id: number) => apiFetch<unknown>(`${API}/featured-ads/${id}/reject`,  { method: "PATCH" });
const deleteFeaturedApi     = (id: number) => apiFetch<unknown>(`${API}/featured-ads/${id}`,                    { method: "DELETE" });
const deleteContactLogApi   = (id: number) => apiFetch<unknown>(`${API}/featured-ads/contact-logs/${id}`, { method: "DELETE" });
const logFeaturedContact    = (id: number, body?: { visitorPhone?: string; ownerPhone?: string; ownerName?: string }) =>
  apiFetch<unknown>(`${API}/featured-ads/${id}/contact`, { method: "POST", headers: J, body: JSON.stringify(body ?? {}) });
const fetchNextCardNum      = () => apiFetch<{ nextCardNum: number }>(`${API}/featured-ads/next-card-num`);
const fetchContactLogs      = () => apiFetch<ContactLog[]>(`${API}/featured-ads/contact-logs`);

/* ── Photo APIs ── */
interface Photo { id: string; cardId: string; objectPath: string; uploadedAt: number; url?: string | null; }
const photoUrl = (p: Photo) => p.url || `${API}/storage${p.objectPath}`;
const fetchPhotos     = (cardId: string) => apiFetch<Photo[]>(`${API}/archive/${cardId}/photos`);
const postPhoto       = (cardId: string, objectPath: string) =>
  apiFetch<Photo>(`${API}/archive/${cardId}/photos`, { method: "POST", headers: J, body: JSON.stringify({ objectPath }) });
const deletePhotoApi  = (cardId: string, photoId: string) =>
  apiFetch<unknown>(`${API}/archive/${cardId}/photos/${photoId}`, { method: "DELETE" });
const requestUploadUrl = (file: File) =>
  apiFetch<{ uploadURL: string; objectPath: string }>(`${API}/storage/uploads/request-url`, {
    method: "POST", headers: J,
    body: JSON.stringify({ name: file.name, size: file.size, contentType: file.type }),
  });
async function setupAdminIfNeeded() {
  try {
    const info = await getAdminApi();
    if (!info.configured) {
      await apiFetch(`${API}/admin/setup`, { method: "POST", headers: J, body: JSON.stringify({ username: "1", password: "111" }) });
    }
  } catch { /* already configured or network unavailable */ }
}

/* Compute next card number from a loaded array */
function computeNextCardNum(cards: SavedCard[]): number {
  return cards.reduce((m, c) => Math.max(m, c.cardNum ?? 0), 0) + 1;
}

const DEFAULT_DATA: CardData = {
  companyName: "شقق وأراضي المستقبل",
  subtitle: "للاستثمار العقاري المتميز",
  projectName: "اسم المشروع",
  phone: "0798561011",
  note1: "",
  note2: "مع شركة شقق وأراضي المستقبل نقدم لكم أفضل العروض والأسعار ؛ بأعلى مستويات الجودة في التشطيب السوبر ديلوكس",
  floors: [
    { id: 1, name: "الطابق التسوية",              area: "م²", price: "ألف" },
    { id: 2, name: "الطابق الارضي مع ترس",        area: "م²", price: "ألف" },
    { id: 3, name: "الطابق الارضي مع حديقة",      area: "م²", price: "ألف" },
    { id: 4, name: "الطوابق الاول والثاني مكرر",   area: "م²", price: "ألف" },
    { id: 5, name: "الطابق الثالث مع روف وترس",   area: "م²", price: "ألف" },
  ],
};

/* Build a minimal CardData from a guest submission (no cardData field).
   Always uses the COMPANY phone — the guest's phone stays private/admin-only. */
function submissionToCardData(sub: Submission): CardData {
  const areaStr = sub.area ? `${sub.area} م²` : "—";
  const floors: Floor[] = sub.floor
    ? [{ id: 1, name: sub.floor, area: areaStr, price: sub.price }]
    : [{ id: 1, name: sub.propertyType || "عقار", area: areaStr, price: sub.price }];
  return {
    ...DEFAULT_DATA,
    projectName: `${sub.propertyType || "عقار"} — ${sub.region}`,
    phone: DEFAULT_DATA.phone,
    note1: "",
    description: sub.description || undefined,  // shown separately below table
    floors,
  };
}

/* ─── base64 image hook ──────────────────────────────────────────── */
function useBase64Image(src: string) {
  const [dataUrl, setDataUrl] = useState(src);
  useEffect(() => {
    fetch(src).then(r => r.blob()).then(blob => {
      const reader = new FileReader();
      reader.onloadend = () => setDataUrl(reader.result as string);
      reader.readAsDataURL(blob);
    }).catch(() => {});
  }, [src]);
  return dataUrl;
}

/* ─── Edit Modal ─────────────────────────────────────────────────── */
function EditModal({ label, value, multiline, onSave, onClose }: {
  label: string; value: string; multiline?: boolean;
  onSave: (v: string) => void; onClose: () => void;
}) {
  const [temp, setTemp] = useState(value);
  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end"
      style={{ background: "rgba(0,0,0,0.55)" }}
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="rounded-t-2xl p-5 flex flex-col gap-4" dir="rtl"
        style={{ background: G_DARK, border: `1.5px solid ${AU_MID}`, borderBottom: "none" }}>
        <div className="flex items-center justify-between">
          <span className="font-bold text-base" style={{ color: AU_TEXT }}>{label}</span>
          <button onClick={onClose} className="text-white/60 hover:text-white"><X size={20} /></button>
        </div>
        {multiline ? (
          <textarea value={temp} onChange={e => setTemp(e.target.value)} autoFocus rows={4} dir="rtl"
            className="w-full rounded-xl px-4 py-3 text-base outline-none resize-none"
            style={{ border: `2px solid ${AU_MID}`, fontSize: "1rem", fontFamily: FONT,
              background: "rgba(255,255,255,0.08)", color: CREAM,
              WebkitTextFillColor: CREAM, caretColor: CREAM }} />
        ) : (
          <input value={temp} onChange={e => setTemp(e.target.value)} autoFocus dir="rtl"
            className="w-full rounded-xl px-4 py-3 text-base outline-none"
            style={{ border: `2px solid ${AU_MID}`, fontSize: "1rem", fontFamily: FONT,
              background: "rgba(255,255,255,0.08)", color: CREAM,
              WebkitTextFillColor: CREAM, caretColor: CREAM }} />
        )}
        <div className="flex gap-3">
          <button onClick={() => { onSave(temp); onClose(); }}
            className="flex-1 py-3 rounded-xl font-bold text-base flex items-center justify-center gap-2"
            style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK }}>
            <Check size={18} /> حفظ
          </button>
          <button onClick={onClose} className="py-3 px-6 rounded-xl font-bold text-base"
            style={{ background: "rgba(255,255,255,0.1)", color: CREAM }}>إلغاء</button>
        </div>
      </div>
    </div>
  );
}

/* ─── CardPreview (read-only card display) ───────────────────────── */
function CardPreview({ data, logoUrl, cardNum, overridePhone }: { data: CardData; logoUrl: string; cardNum?: number | null; overridePhone?: string }) {
  return (
    <div dir="rtl" className="w-full rounded-2xl overflow-hidden shadow-2xl"
      style={{ background: `linear-gradient(170deg,${G_DARK} 0%,${G_MID} 55%,${G_DARK} 100%)`, fontFamily: FONT, border: BORDER }}>

      <div className="px-5 pt-5 pb-4 flex items-center justify-between gap-3">
        <div className="flex-1 min-w-0">
          <h1 className="font-black text-right leading-tight"
            style={{ color: AU_TEXT, fontSize: "1.35rem", textShadow: "0 1px 4px rgba(0,0,0,0.5)" }}>
            {data.companyName}
          </h1>
          <p className="text-sm mt-1" style={{ color: CREAM_D }}>{data.subtitle}</p>
        </div>
        <div className="w-16 h-16 rounded-xl shrink-0 shadow-lg overflow-hidden"
          style={{ background: "#fff", border: `2px solid ${AU_MID}` }}>
          <img src={logoUrl} alt="شعار الشركة" className="w-full h-full object-contain" />
        </div>
      </div>

      <div className="mx-4 h-px" style={{ background: `linear-gradient(90deg,transparent,${AU_MID},transparent)` }} />

      <div className="mx-4 mt-3 mb-2 rounded-lg py-2 px-3 flex items-center justify-center gap-3"
        style={{ background: `linear-gradient(90deg,${AU_DEEP},${AU_BRT},${AU_DEEP})` }}>
        <span style={{ color: G_DARK, fontSize: "0.65rem" }}>◆</span>
        <span className="font-black text-lg" style={{ color: G_DARK }}>{data.projectName}</span>
        <span style={{ color: G_DARK, fontSize: "0.65rem" }}>◆</span>
      </div>

      <div className="mx-4 mt-1 rounded-xl overflow-hidden" style={{ border: BORDER }}>
        <table style={{ width: "100%", borderCollapse: "collapse", tableLayout: "fixed" }}>
          <colgroup>
            <col style={{ width: "42%" }} /><col style={{ width: "29%" }} /><col style={{ width: "29%" }} />
          </colgroup>
          <thead>
            <tr style={{ background: `linear-gradient(90deg,${G_DARK},${G_MID},${G_DARK})` }}>
              {["الطابق", "المساحة", "السعر"].map(h => (
                <th key={h} style={{ padding: "10px 6px", border: BORDER, color: AU_TEXT, fontWeight: 800, fontSize: "0.95rem", textAlign: "center" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {(data.floors ?? []).map((floor, i) => (
              <tr key={floor.id} style={{ background: i % 2 === 0 ? "rgba(180,145,42,0.07)" : "rgba(26,92,42,0.35)" }}>
                <td style={{ padding: "10px 8px", border: BORDER, color: CREAM, fontSize: "0.9rem", fontWeight: 600, textAlign: "right" }}>
                  {floor.name}
                </td>
                <td style={{ padding: "10px 8px", border: BORDER, color: CREAM, fontSize: "0.95rem", fontWeight: 700, textAlign: "center" }}>
                  {floor.area}
                </td>
                <td style={{ padding: "10px 8px", border: BORDER, color: "#fff", fontSize: "0.95rem", fontWeight: 800, textAlign: "center" }}>
                  {floor.price}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {data.description && (
        <div className="mx-4 mt-2 rounded-xl px-3 py-2 text-center leading-relaxed"
          style={{ background: "rgba(201,162,39,0.1)", border: `1px solid ${AU_DEEP}66`, color: CREAM, fontSize: "0.75rem", fontWeight: 600 }}>
          {data.description}
        </div>
      )}

      <div className="mx-4 mt-3 mb-4 rounded-xl overflow-hidden" style={{ border: BORDER }}>
        <div className="flex items-stretch">
          <div className="flex flex-col items-center justify-center gap-1 px-3 py-3 shrink-0"
            style={{ background: "rgba(201,162,39,0.18)", borderLeft: BORDER, minWidth: "100px" }}>
            <span style={{ fontSize: "0.95rem" }}>📞</span>
            <span className="font-black text-sm tracking-wide" style={{ color: AU_TEXT, direction: "ltr" }}>{overridePhone ?? data.phone}</span>
            <span className="text-xs" style={{ color: CREAM_D }}>للتواصل</span>
          </div>
          <div className="flex-1 flex flex-col">
            {data.note1 ? (
              <div className="flex-1 flex items-center justify-center px-3 py-2 text-xs font-semibold text-center leading-relaxed"
                style={{ color: CREAM, borderBottom: BORDER }}>
                {data.note1}
              </div>
            ) : null}
            <div className="flex-1 flex items-center justify-center px-3 py-2 text-xs font-medium text-center leading-relaxed"
              style={{ color: "#fff", background: "rgba(26,61,28,0.4)" }}>
              {data.note2}
            </div>
          </div>
        </div>
      </div>

      {cardNum && (
        <div className="mx-4 mb-4 mt-2 flex items-center justify-between px-4 py-2 rounded-lg"
          style={{ background: `linear-gradient(90deg,${AU_DEEP}55,${G_DARK}88)`, border: `1px solid ${AU_DEEP}` }}>
          <span className="text-xs font-semibold" style={{ color: CREAM_D }}>شقق وأراضي المستقبل</span>
          <span className="font-black text-base" style={{ color: AU_TEXT }}>بطاقة #{cardNum}</span>
        </div>
      )}
    </div>
  );
}

/* ─── CardViewer (full-screen with prev/next + photo gallery) ────── */
type ViewerItem = { data: CardData; cardNum?: number; label?: string; photoCardId?: string; featuredPhone?: string; featuredAdId?: number };

/**
 * Inline photo gallery — sits inside the slide (not fixed),
 * so vertical scroll passes through to the snap-scroll container.
 * No X button — user exits by scrolling to next card.
 */
function ImageGallery({ images, initialIndex = 0, onClose }: {
  images: string[]; initialIndex?: number; onClose?: () => void;
}) {
  const [current, setCurrent] = useState(initialIndex);
  const touchStartX = useRef(0);

  const goTo = (idx: number) => setCurrent(Math.max(0, Math.min(images.length - 1, idx)));

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
  };
  const handleTouchEnd = (e: React.TouchEvent) => {
    const dx = e.changedTouches[0].clientX - touchStartX.current;
    if (Math.abs(dx) < 40) return;
    if (dx > 0) goTo(current + 1);
    else goTo(current - 1);
  };

  return (
    <div className="fixed inset-0 flex flex-col z-[70]"
      style={{ background: "rgba(6,6,6,0.98)", touchAction: "pan-y" }}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}>

      {/* Top bar: counter + close */}
      <div className="flex items-center justify-between px-4 pt-5 pb-2 shrink-0">
        <span className="text-xs font-bold px-3 py-1.5 rounded-full"
          style={{ background: "rgba(255,255,255,0.1)", color: CREAM_D }}>
          {current + 1} / {images.length}
        </span>
        {onClose && (
          <button onClick={onClose}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold text-sm active:scale-95"
            style={{ background: "rgba(255,255,255,0.1)", color: CREAM }}>
            <X size={16} /> إغلاق
          </button>
        )}
      </div>

      {/* Photo — smooth fade on change */}
      <div className="flex-1 flex items-center justify-center overflow-hidden px-3"
        style={{ pointerEvents: "none" }}>
        <img
          key={current}
          src={images[current]}
          alt={`صورة ${current + 1}`}
          className="max-w-full object-contain rounded-2xl"
          loading="eager"
          style={{ maxHeight: "calc(100% - 8px)", animation: "fadeIn 0.18s ease" }} />
      </div>

      {/* Bottom dots */}
      <div className="shrink-0 pb-10 pt-3 px-4 flex flex-col items-center gap-3">
        {images.length > 1 && (
          <div className="flex items-center justify-center gap-1.5" style={{ pointerEvents: "auto" }}>
            {images.map((_, idx) => (
              <div key={idx} onClick={() => goTo(idx)} className="rounded-full cursor-pointer"
                style={{
                  width: idx === current ? 22 : 6, height: 6,
                  background: idx === current ? AU_BRT : "rgba(255,255,255,0.25)",
                  transition: "width 0.25s, background 0.25s",
                }} />
            ))}
          </div>
        )}
        <p className="text-xs" style={{ color: CREAM_D }}>اسحب للتنقل بين الصور ←</p>
      </div>
    </div>
  );
}

/* ── CardSlide: one card + its photo navigation ─────────────────── */
/** Scale the card to fully fit inside its container — no internal scroll */
function FitCard({ data, logoUrl, cardNum, overridePhone }: { data: CardData; logoUrl: string; cardNum?: number; overridePhone?: string }) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const innerRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);

  useEffect(() => {
    const wrap  = wrapRef.current;
    const inner = innerRef.current;
    if (!wrap || !inner) return;
    const scaleH = wrap.clientHeight / inner.scrollHeight;
    const scaleW = wrap.clientWidth  / inner.scrollWidth;
    setScale(Math.min(scaleH, scaleW, 1));
  }, [data]);

  return (
    <div ref={wrapRef} className="w-full h-full flex items-start justify-center overflow-hidden">
      <div ref={innerRef} className="w-full" style={{ transform: `scale(${scale})`, transformOrigin: "top center" }}>
        <CardPreview data={data} logoUrl={logoUrl} cardNum={cardNum} overridePhone={overridePhone} />
      </div>
    </div>
  );
}

function CardSlide({ item, logoUrl, isActive, preloadedPhotos }: {
  item: ViewerItem; logoUrl: string; isActive: boolean; preloadedPhotos?: string[] | null;
}) {
  const [photos, setPhotos] = useState<string[]>(preloadedPhotos ?? []);
  const [fetchingMeta, setFetchingMeta] = useState(false);
  const [loadedOnce, setLoadedOnce]     = useState(!!preloadedPhotos);
  const [hIdx, setHIdx]                 = useState(0);
  const [dragDx, setDragDx]             = useState(0);
  /* Track which photo indices have finished loading */
  const [ready, setReady] = useState<Set<number>>(new Set());
  const slideRef   = useRef<HTMLDivElement>(null);
  /* gesture state kept in ref (not state) to avoid re-renders during drag */
  const gestureRef = useRef<{ startX: number; startY: number; lock: "h" | "v" | null }>({
    startX: 0, startY: 0, lock: null,
  });
  /* expose current hIdx & totalPages to non-React event handlers */
  const hIdxRef      = useRef(hIdx);
  const totalRef     = useRef(0);
  useEffect(() => { hIdxRef.current = hIdx; }, [hIdx]);

  /* Accept preloaded URLs from parent cache */
  useEffect(() => {
    if (preloadedPhotos && preloadedPhotos.length > 0) {
      setPhotos(preloadedPhotos);
      setLoadedOnce(true);
    }
  }, [preloadedPhotos]);

  /* Fallback: fetch metadata when the card becomes active and cache is empty */
  useEffect(() => {
    if (!isActive || loadedOnce || !item.photoCardId) return;
    setLoadedOnce(true);
    setFetchingMeta(true);
    fetchPhotos(item.photoCardId)
      .then(ps => { setPhotos(ps.map(p => photoUrl(p))); })
      .catch(() => {})
      .finally(() => setFetchingMeta(false));
  }, [isActive, item.photoCardId, loadedOnce]);

  /* Reset horizontal index when this slide loses focus */
  useEffect(() => { if (!isActive) { setHIdx(0); setDragDx(0); } }, [isActive]);

  const totalPages = 1 + photos.length;
  const hasPhotos  = photos.length > 0;
  totalRef.current = totalPages;

  /* ── Non-passive touch handling — must be DOM-level to allow preventDefault ── */
  useEffect(() => {
    const el = slideRef.current;
    if (!el) return;

    const onStart = (e: TouchEvent) => {
      gestureRef.current = { startX: e.touches[0].clientX, startY: e.touches[0].clientY, lock: null };
      setDragDx(0);
    };

    const onMove = (e: TouchEvent) => {
      const g  = gestureRef.current;
      const dx = e.touches[0].clientX - g.startX;
      const dy = e.touches[0].clientY - g.startY;

      /* Decide direction lock after first 8px of movement */
      if (!g.lock && (Math.abs(dx) > 8 || Math.abs(dy) > 8)) {
        g.lock = Math.abs(dx) > Math.abs(dy) ? "h" : "v";
      }

      if (g.lock === "h") {
        e.preventDefault();   /* block vertical scroll / snap while swiping horizontally */
        const cur   = hIdxRef.current;
        const total = totalRef.current;
        /* Rubber-band: resist dragging past first/last page */
        const atEdge = (dx < 0 && cur === 0) || (dx > 0 && cur === total - 1);
        setDragDx(atEdge ? dx * 0.25 : dx);
      }
    };

    const onEnd = (e: TouchEvent) => {
      const g  = gestureRef.current;
      const dx = e.changedTouches[0].clientX - g.startX;
      setDragDx(0);
      if (g.lock !== "h" || Math.abs(dx) < 40) return;
      const cur   = hIdxRef.current;
      const total = totalRef.current;
      if (dx > 0 && cur < total - 1) setHIdx(h => h + 1);
      if (dx < 0 && cur > 0)         setHIdx(h => h - 1);
    };

    el.addEventListener("touchstart", onStart, { passive: true });
    el.addEventListener("touchmove",  onMove,  { passive: false }); /* non-passive = can preventDefault */
    el.addEventListener("touchend",   onEnd,   { passive: true });
    return () => {
      el.removeEventListener("touchstart", onStart);
      el.removeEventListener("touchmove",  onMove);
      el.removeEventListener("touchend",   onEnd);
    };
  }, []); /* attach once — reads live values via refs */

  const markReady = (i: number) => setReady(prev => { const n = new Set(prev); n.add(i); return n; });

  return (
    <div ref={slideRef} className="shrink-0 w-full flex flex-col"
      style={{ scrollSnapAlign: "start", height: "100%" }}>

      {/* ── Paged area: translateX follows finger in real-time, snaps on release ── */}
      <div className="flex-1 min-h-0 overflow-hidden relative"
        style={{ transform: `translateX(${dragDx}px)`,
                 transition: dragDx === 0 ? "transform 0.2s ease" : "none" }}>

        {/* Layer 0 — card preview */}
        <div className="absolute inset-0 px-3 pt-2 pb-1"
          style={{ opacity: hIdx === 0 ? 1 : 0, pointerEvents: hIdx === 0 ? "auto" : "none",
                   transition: "opacity 0.15s ease" }}>
          <FitCard data={item.data} logoUrl={logoUrl} cardNum={item.cardNum} overridePhone={item.featuredPhone} />
        </div>

        {/* Layers 1…N — photo slides: ALL rendered simultaneously so browser downloads them in parallel */}
        {photos.map((url, i) => {
          const active = hIdx === i + 1;
          const loaded = ready.has(i);
          return (
            <div key={url} className="absolute inset-0 flex items-center justify-center px-2 py-4"
              style={{ background: "#0a0a0a", opacity: active ? 1 : 0,
                       pointerEvents: active ? "auto" : "none",
                       transition: "opacity 0.15s ease" }}>
              {/* Spinner visible only while this photo is still loading AND active */}
              {!loaded && active && (
                <div className="absolute inset-0 flex items-center justify-center z-10">
                  <div className="w-10 h-10 border-4 border-t-transparent rounded-full animate-spin"
                    style={{ borderColor: `${AU_DEEP} transparent ${AU_DEEP} ${AU_DEEP}` }} />
                </div>
              )}
              <img
                src={url}
                alt={`صورة ${i + 1}`}
                loading="eager"
                decoding="async"
                onLoad={() => markReady(i)}
                className="max-w-full max-h-full object-contain rounded-2xl"
                style={{ maxHeight: "calc(100% - 8px)",
                         opacity: loaded ? 1 : 0, transition: "opacity 0.25s ease" }}
              />
            </div>
          );
        })}

        {/* Meta-fetch spinner (waiting for URL list) */}
        {fetchingMeta && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-10 h-10 border-4 border-t-transparent rounded-full animate-spin"
              style={{ borderColor: `${AU_DEEP} transparent ${AU_DEEP} ${AU_DEEP}` }} />
          </div>
        )}
      </div>

      {/* ── Bottom indicator bar ── */}
      <div className="shrink-0 pb-5 pt-2 px-4 flex flex-col items-center gap-1.5">
        {totalPages > 1 && (
          <div className="flex items-center gap-1.5">
            {Array.from({ length: totalPages }).map((_, idx) => (
              <div key={idx} className="rounded-full transition-all duration-200"
                style={{ width: idx === hIdx ? 20 : 6, height: 6,
                         background: idx === hIdx ? AU_BRT : "rgba(255,255,255,0.25)" }} />
            ))}
          </div>
        )}
        <div className="px-4 py-2 rounded-xl text-sm font-bold text-center"
          style={{ background: "rgba(255,255,255,0.12)", color: CREAM, border: "1px solid rgba(255,255,255,0.2)" }}>
          {hIdx === 0
            ? hasPhotos ? "← اسحب يميناً للصور  |  ↓ بطاقة تالية" : "↓ اسحب للبطاقة التالية"
            : `صورة ${hIdx} من ${photos.length}  |  اسحب يساراً للبطاقة →`}
        </div>
      </div>
    </div>
  );
}

/* ── CardViewer: vertical snap-scroll between cards ─────────────── */
function CardViewer({ items, startIndex, onClose, logoUrl }: {
  items: ViewerItem[]; startIndex: number; onClose: () => void; logoUrl: string;
}) {
  const [currentIdx, setCurrentIdx] = useState(startIndex);
  const scrollRef = useRef<HTMLDivElement>(null);

  /* Photo pre-fetch cache: photoCardId → string[] of URLs */
  const cacheRef = useRef<Map<string, string[]>>(new Map());
  const [photoCache, setPhotoCache] = useState<Map<string, string[]>>(new Map());

  /* Pre-fetch photos for a window of nearby cards */
  const prefetchRange = useCallback((centerIdx: number) => {
    const WINDOW = 3; // load center ± 3
    const start  = Math.max(0, centerIdx - WINDOW);
    const end    = Math.min(items.length - 1, centerIdx + WINDOW);
    for (let i = start; i <= end; i++) {
      const item = items[i];
      if (!item?.photoCardId || cacheRef.current.has(item.photoCardId)) continue;
      cacheRef.current.set(item.photoCardId, []); // mark as in-flight
      fetchPhotos(item.photoCardId)
        .then(ps => {
          const urls = ps.map(p => photoUrl(p));
          urls.forEach(url => { const img = new Image(); img.src = url; });
          cacheRef.current.set(item.photoCardId!, urls);
          setPhotoCache(prev => { const m = new Map(prev); m.set(item.photoCardId!, urls); return m; });
        })
        .catch(() => { cacheRef.current.delete(item.photoCardId!); });
    }
  }, [items]);

  /* Initial prefetch around startIndex */
  useEffect(() => { prefetchRange(startIndex); }, []);  // eslint-disable-line

  /* Jump to startIndex on mount (no animation) */
  useEffect(() => {
    const el = scrollRef.current;
    if (!el || startIndex === 0) return;
    requestAnimationFrame(() => {
      el.scrollTop = startIndex * el.clientHeight;
    });
  }, []);

  const handleScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    const idx = Math.max(0, Math.min(items.length - 1, Math.round(el.scrollTop / el.clientHeight)));
    setCurrentIdx(idx);
    prefetchRange(idx);
  };

  const currentItem = items[currentIdx];

  return (
    <div className="fixed inset-0 z-50 flex flex-col" dir="rtl"
      style={{ background: "rgba(0,0,0,0.94)" }}>
      {/* Fixed top bar */}
      <div className="flex items-center justify-between px-4 pt-5 pb-3 shrink-0">
        <button onClick={onClose}
          className="flex items-center gap-2 px-3 py-2 rounded-xl font-bold text-sm active:scale-95"
          style={{ background: "rgba(255,255,255,0.1)", color: CREAM }}>
          <X size={18} /> إغلاق
        </button>
        <span className="text-xs font-bold text-center" style={{ color: CREAM_D }}>
          <span className="block" style={{ color: CREAM, fontSize: 15 }}>{currentIdx + 1} / {items.length}</span>
          <span style={{ fontSize: 10, opacity: 0.7 }}>إجمالي البطاقات</span>
        </span>
        {currentItem && (() => {
          const isFeatured = !!currentItem.featuredPhone;
          const phone = isFeatured
            ? `962${(currentItem.featuredPhone ?? "").replace(/^0/, "")}`
            : "962798561011";
          const cardRef = currentItem.cardNum ? ` | رقم البطاقة: #${currentItem.cardNum}` : "";
          const msg = `أهلاً، أريد الاستفسار عن ${currentItem.data.projectName}${cardRef}`;
          return (
            <a href={`https://api.whatsapp.com/send?phone=${phone}&text=${encodeURIComponent(msg)}`}
              target="_blank" rel="noopener noreferrer"
              onClick={() => { if (isFeatured && currentItem.featuredAdId) { logFeaturedContact(currentItem.featuredAdId).catch(() => {}); } }}
              className="flex items-center gap-2 px-3 py-2 rounded-xl font-bold text-sm active:scale-95"
              style={{ background: "#25D366", color: "#fff" }}>
              <Phone size={16} /> تواصل
            </a>
          );
        })()}
      </div>

      {/* Vertical snap-scroll container */}
      <div
        ref={scrollRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-scroll flex flex-col"
        style={{
          scrollSnapType: "y mandatory",
          scrollbarWidth: "none",
          msOverflowStyle: "none",
        }}>
        {items.map((item, idx) => (
          <CardSlide
            key={idx}
            item={item}
            logoUrl={logoUrl}
            isActive={idx === currentIdx}
            preloadedPhotos={item.photoCardId ? (photoCache.get(item.photoCardId) ?? null) : null}
          />
        ))}
      </div>

      {/* Scroll hint (only when more cards below) */}
      {currentIdx < items.length - 1 && (
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 pointer-events-none">
          <div className="flex flex-col items-center gap-0.5 opacity-50">
            <div className="w-0.5 h-5 rounded-full" style={{ background: CREAM_D }} />
            <div className="text-xs" style={{ color: CREAM_D }}>اسحب للأسفل</div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── Employee Editor (submit-only card editor) ───────────────────── */
function EmployeeEditor({ onLogout, savedCards, employee, isAdmin = false }: { onLogout: () => void; savedCards: SavedCard[]; employee?: { id: string; name: string }; isAdmin?: boolean }) {
  const logoDataUrl = useBase64Image(logoSrc);
  const [modal, setModal] = useState<{ label: string; value: string; multiline?: boolean; onSave: (v: string) => void } | null>(null);
  const [data, setData] = useState<CardData>({ ...DEFAULT_DATA, floors: DEFAULT_DATA.floors.map(f => ({ ...f })) });
  const [region, setRegion] = useState("");
  const [ownerName, setOwnerName]       = useState("");
  const [ownerPhone, setOwnerPhone]     = useState("");
  const [locationUrl, setLocationUrl]   = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [projectNameEdited, setProjectNameEdited] = useState(false);

  let localId = 200;
  const setField = (k: keyof CardData, v: string) => setData(p => ({ ...p, [k]: v }));
  const setFloorField = (id: number, k: keyof Floor, v: string) =>
    setData(p => ({ ...p, floors: p.floors.map(f => f.id === id ? { ...f, [k]: v } : f) }));
  const delFloor = (id: number) => setData(p => ({ ...p, floors: p.floors.filter(f => f.id !== id) }));
  const addFloor = () => setData(p => ({ ...p, floors: [...p.floors, { id: localId++, name: "اسم الطابق", area: "م²", price: "ألف" }] }));
  const edit = (label: string, value: string, onSave: (v: string) => void, multiline?: boolean) =>
    setModal({ label, value, onSave, multiline });

  // Auto-sync: region → projectName unless user manually edited project name
  const handleRegionChange = (v: string) => {
    setRegion(v);
    if (!projectNameEdited) {
      setField("projectName", v || DEFAULT_DATA.projectName);
    }
  };

  const [submitting, setSubmitting] = useState(false);
  const [submitErr, setSubmitErr]   = useState("");
  // Pre-generate a stable ID for linking photos; refreshed after each successful submission
  const genId = () => `${Date.now()}_${Math.random().toString(36).slice(2)}`;
  const [empSubId, setEmpSubId]     = useState(genId);
  const empPhotoCardId              = `sub_${empSubId}`;

  const resetForm = () => {
    setData({ ...DEFAULT_DATA, floors: DEFAULT_DATA.floors.map(f => ({ ...f })) });
    setRegion(""); setOwnerName(""); setOwnerPhone(""); setLocationUrl("");
    setProjectNameEdited(false); setSubmitted(false); setSubmitErr("");
    setEmpSubId(genId());
  };

  const submitForApproval = async () => {
    setSubmitErr("");
    if (!region.trim())     { setSubmitErr("✱ المنطقة مطلوبة"); return; }
    if (!ownerName.trim())  { setSubmitErr("✱ اسم صاحب المشروع مطلوب"); return; }
    if (!ownerPhone.trim()) { setSubmitErr("✱ رقم هاتف صاحب المشروع مطلوب"); return; }
    setSubmitting(true);
    const ownerContactStr = [
      `اسم: ${ownerName.trim()}`,
      `هاتف: ${ownerPhone.trim()}`,
      locationUrl.trim() ? `موقع: ${locationUrl.trim()}` : "",
    ].filter(Boolean).join("\n");
    const sub: Submission = {
      id: empSubId,
      submittedAt: Date.now(),
      status: "pending",
      submittedBy: "employee",
      ownerType: "موظف",
      propertyType: data.projectName,
      region: region,
      price: "",
      floor: "",
      area: "",
      contactName: "",
      phone: "",
      description: "",
      ownerContact: ownerContactStr,
      cardData: data,
      cardRegion: region,
      employeeId:   employee?.id,
      employeeName: employee?.name,
    };
    try {
      await postSubmission(sub);
      setSubmitted(true);
      setTimeout(() => resetForm(), 2000);
    } catch {
      setSubmitErr("تعذّر إرسال الطلب، حاول مجدداً");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-start py-6 px-3"
      style={{ background: `linear-gradient(145deg,${G_DARK} 0%,${G_MID} 50%,${G_DARK} 100%)`, fontFamily: FONT }}>

      {modal && <EditModal label={modal.label} value={modal.value} multiline={modal.multiline} onSave={modal.onSave} onClose={() => setModal(null)} />}

      {/* Top bar — logout + quick reset */}
      <div className="mb-3 flex items-center justify-between w-full max-w-sm">
        {/* Reset — most important for fast workflow */}
        <button
          onClick={resetForm}
          className="flex items-center gap-1.5 px-3 py-2 rounded-full font-bold transition-all active:scale-95 text-xs"
          style={{ background: "rgba(201,162,39,0.15)", color: AU_TEXT, border: `1px solid ${AU_DEEP}66` }}>
          <FilePlus size={13} /> إعلان جديد
        </button>
        <button onClick={onLogout}
          className="flex items-center gap-1.5 px-3 py-2 rounded-full font-bold transition-all active:scale-95 text-xs"
          style={{ background: "rgba(239,68,68,0.1)", color: "#f87171", border: "1px solid #f8717133" }}>
          <LogOut size={13} /> خروج
        </button>
      </div>

      {/* Required fields block */}
      <div className="mb-4 w-full max-w-sm flex flex-col gap-2">
        {/* Region — required */}
        <div className="flex items-center gap-2 rounded-xl px-3 py-2.5"
          style={{ background: "rgba(255,255,255,0.08)", border: !region.trim() ? "1.5px solid #f87171" : BORDER }}>
          <span style={{ color: AU_TEXT }}>📍</span>
          <input value={region} onChange={e => handleRegionChange(e.target.value)}
            placeholder="المنطقة ✱" dir="rtl"
            className="flex-1 bg-transparent outline-none text-sm"
            style={{ color: CREAM, fontFamily: FONT }} />
        </div>

        {/* Owner info block — secret, admin-only */}
        <div className="rounded-xl overflow-hidden" style={{ border: `1.5px solid ${AU_DEEP}88` }}>
          <div className="px-3 py-1.5 flex items-center gap-1.5"
            style={{ background: "rgba(184,145,42,0.18)", borderBottom: `1px solid ${AU_DEEP}44` }}>
            <Lock size={11} style={{ color: AU_TEXT }} />
            <span className="text-xs font-bold" style={{ color: AU_TEXT }}>معلومات سرية — للمدير فقط، لن تظهر في البطاقة</span>
          </div>
          {/* Owner name */}
          <div className="flex items-center gap-2 px-3 py-2.5"
            style={{ background: "rgba(184,145,42,0.08)", borderBottom: `1px solid ${AU_DEEP}33`,
              outline: !ownerName.trim() ? "1.5px solid #f87171" : "none", outlineOffset: "-1px" }}>
            <span style={{ color: AU_TEXT, fontSize: "0.85rem" }}>👤</span>
            <input value={ownerName} onChange={e => setOwnerName(e.target.value)}
              placeholder="اسم صاحب المشروع ✱" dir="rtl"
              className="flex-1 bg-transparent outline-none text-sm"
              style={{ color: CREAM, fontFamily: FONT }} />
          </div>
          {/* Owner phone */}
          <div className="flex items-center gap-2 px-3 py-2.5"
            style={{ background: "rgba(184,145,42,0.08)", borderBottom: `1px solid ${AU_DEEP}33`,
              outline: !ownerPhone.trim() ? "1.5px solid #f87171" : "none", outlineOffset: "-1px" }}>
            <Phone size={13} style={{ color: AU_TEXT, flexShrink: 0 }} />
            <input value={ownerPhone} onChange={e => setOwnerPhone(normalizeNums(e.target.value))}
              placeholder="رقم هاتف صاحب المشروع ✱" dir="ltr"
              type="tel" className="flex-1 bg-transparent outline-none text-sm"
              style={{ color: CREAM, fontFamily: FONT }} />
          </div>
          {/* Location URL */}
          <div className="flex items-center gap-2 px-3 py-2.5"
            style={{ background: "rgba(184,145,42,0.06)" }}>
            <MapPin size={13} style={{ color: AU_TEXT, flexShrink: 0 }} />
            <input value={locationUrl} onChange={e => setLocationUrl(e.target.value)}
              placeholder="رابط موقع العمارة (Google Maps — اختياري)" dir="ltr"
              className="flex-1 bg-transparent outline-none text-sm"
              style={{ color: CREAM, fontFamily: FONT }} />
          </div>
        </div>
      </div>

      {/* Card Preview (editable) */}
      <div dir="rtl" className="w-full max-w-sm rounded-2xl overflow-hidden shadow-2xl"
        style={{ background: `linear-gradient(170deg,${G_DARK} 0%,${G_MID} 55%,${G_DARK} 100%)`, fontFamily: FONT, border: BORDER }}>

        <div className="px-5 pt-5 pb-4 flex items-center justify-between gap-3">
          <div className="flex-1 min-w-0">
            <h1 className="font-black text-right leading-tight cursor-pointer active:opacity-70"
              style={{ color: AU_TEXT, fontSize: "1.35rem", textShadow: "0 1px 4px rgba(0,0,0,0.5)" }}
              onClick={() => edit("اسم الشركة", data.companyName, v => setField("companyName", v))}>
              {data.companyName}
            </h1>
            <p className="text-sm mt-1 cursor-pointer active:opacity-70" style={{ color: CREAM_D }}
              onClick={() => edit("الوصف", data.subtitle, v => setField("subtitle", v))}>
              {data.subtitle}
            </p>
          </div>
          <div className="w-16 h-16 rounded-xl shrink-0 shadow-lg overflow-hidden"
            style={{ background: "#fff", border: `2px solid ${AU_MID}` }}>
            <img src={logoDataUrl} alt="شعار الشركة" className="w-full h-full object-contain" />
          </div>
        </div>

        <div className="mx-4 h-px" style={{ background: `linear-gradient(90deg,transparent,${AU_MID},transparent)` }} />

        <div className="mx-4 mt-3 mb-2 rounded-lg py-2 px-3 flex items-center justify-center gap-3 cursor-pointer active:opacity-80"
          style={{ background: `linear-gradient(90deg,${AU_DEEP},${AU_BRT},${AU_DEEP})` }}
          onClick={() => edit("اسم المشروع", data.projectName, v => { setField("projectName", v); setProjectNameEdited(true); })}>
          <span style={{ color: G_DARK, fontSize: "0.65rem" }}>◆</span>
          <span className="font-black text-lg" style={{ color: G_DARK }}>{data.projectName}</span>
          <span style={{ color: G_DARK, fontSize: "0.65rem" }}>◆</span>
        </div>

        <div className="mx-4 mt-1 rounded-xl overflow-hidden" style={{ border: BORDER }}>
          <table style={{ width: "100%", borderCollapse: "collapse", tableLayout: "fixed" }}>
            <colgroup>
              <col style={{ width: "42%" }} /><col style={{ width: "29%" }} /><col style={{ width: "29%" }} />
            </colgroup>
            <thead>
              <tr style={{ background: `linear-gradient(90deg,${G_DARK},${G_MID},${G_DARK})` }}>
                {["الطابق", "المساحة", "السعر"].map(h => (
                  <th key={h} style={{ padding: "10px 6px", border: BORDER, color: AU_TEXT, fontWeight: 800, fontSize: "0.95rem", textAlign: "center" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {(data.floors ?? []).map((floor, fi) => (
                <tr key={floor.id} style={{ background: fi % 2 === 0 ? "rgba(180,145,42,0.07)" : "rgba(26,92,42,0.35)" }}>
                  <td style={{ padding: "4px 6px", border: BORDER }}>
                    <div className="flex items-center gap-1">
                      <input value={floor.name} onChange={e => setFloorField(floor.id, "name", e.target.value)}
                        dir="rtl" className="flex-1 min-w-0 bg-transparent outline-none text-right text-sm font-semibold"
                        style={{ color: CREAM, fontFamily: FONT }} />
                      <button onClick={() => delFloor(floor.id)}
                        className="shrink-0 text-red-400 active:scale-90 p-0.5 rounded">
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </td>
                  <td style={{ padding: "4px", border: BORDER }}>
                    <div className="flex items-center justify-center gap-0.5">
                      <input value={floor.area.replace(/\s*م²\s*$/, "")}
                        onChange={e => setFloorField(floor.id, "area", (e.target.value.trim() || "") + " م²")}
                        onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); document.querySelector<HTMLInputElement>(`[data-price="${floor.id}"]`)?.focus(); } }}
                        data-area={floor.id}
                        dir="ltr" placeholder="المساحة"
                        className="w-full bg-transparent outline-none text-center text-sm font-bold"
                        style={{ color: CREAM, fontFamily: FONT, maxWidth: "60px" }} />
                      <span className="text-xs shrink-0 font-bold" style={{ color: AU_TEXT }}>م²</span>
                    </div>
                  </td>
                  <td style={{ padding: "4px", border: BORDER }}>
                    <div className="flex items-center justify-center gap-0.5">
                      <input value={floor.price.replace(/\s*ألف\s*$/, "")}
                        onChange={e => setFloorField(floor.id, "price", (e.target.value.trim() || "") + " ألف")}
                        onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); const next = data.floors[fi + 1]; if (next) document.querySelector<HTMLInputElement>(`[data-area="${next.id}"]`)?.focus(); } }}
                        data-price={floor.id}
                        dir="ltr" placeholder="السعر"
                        className="w-full bg-transparent outline-none text-center text-sm font-bold"
                        style={{ color: "#fff", fontFamily: FONT, maxWidth: "55px" }} />
                      <span className="text-xs shrink-0 font-bold" style={{ color: AU_TEXT }}>ألف</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mx-4 mt-3 mb-4 rounded-xl overflow-hidden" style={{ border: BORDER }}>
          <div className="flex items-stretch">
            <div className="flex flex-col items-center justify-center gap-1 px-3 py-3 cursor-pointer active:opacity-80 shrink-0"
              style={{ background: "rgba(201,162,39,0.18)", borderLeft: BORDER, minWidth: "100px" }}
              onClick={() => edit("رقم الهاتف", data.phone, v => setField("phone", v))}>
              <span style={{ fontSize: "0.95rem" }}>📞</span>
              <span className="font-black text-sm tracking-wide" style={{ color: AU_TEXT, direction: "ltr" }}>{data.phone}</span>
              <span className="text-xs" style={{ color: CREAM_D }}>للتواصل</span>
            </div>
            <div className="flex-1 flex flex-col">
              {data.note1 ? (
                <div className="flex-1 flex items-center justify-center px-3 py-2 text-xs font-semibold text-center cursor-pointer active:opacity-80 leading-relaxed"
                  style={{ color: CREAM, borderBottom: BORDER }}
                  onClick={() => edit("ملاحظة الأجور", data.note1, v => setField("note1", v), true)}>
                  {data.note1}
                </div>
              ) : null}
              <div className="flex-1 flex items-center justify-center px-3 py-2 text-xs font-medium text-center cursor-pointer active:opacity-80 leading-relaxed"
                style={{ color: "#fff", background: "rgba(26,61,28,0.4)" }}
                onClick={() => edit("الملاحظة التسويقية", data.note2, v => setField("note2", v), true)}>
                {data.note2}
              </div>
            </div>
          </div>
        </div>
      </div>

      <p className="mt-4 text-sm" style={{ color: "rgba(255,255,255,0.45)" }}>
        اضغط على أي نص لتعديله ✏️
      </p>

      {/* Photo upload — below card, above actions */}
      <div className="mt-4 mb-1 w-full max-w-sm rounded-2xl px-4 py-4"
        style={{ background: "rgba(255,255,255,0.06)", border: BORDER }}>
        <PhotoUploadSection key={empPhotoCardId} cardId={empPhotoCardId} />
      </div>

      {/* Action buttons — below card */}
      <div className="mt-3 mb-8 w-full max-w-sm flex flex-col gap-3">
        {submitErr && (
          <p className="text-sm text-center text-red-400 bg-red-900/20 rounded-xl px-3 py-2">{submitErr}</p>
        )}
        <button onClick={submitForApproval} disabled={submitting || submitted}
          className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl font-black text-base shadow-2xl active:scale-95 disabled:opacity-80"
          style={{ background: submitted ? "linear-gradient(135deg,#16a34a,#22c55e)" : `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK }}>
          <Send size={18} />
          {submitting ? "جاري الإرسال..." : submitted ? "تم الإرسال ✓ — جاري المراجعة" : "تقديم للنشر"}
        </button>
        <button onClick={addFloor}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-sm active:scale-95"
            style={{ background: "rgba(255,255,255,0.1)", color: CREAM, border: `1.5px solid ${AU_DEEP}` }}>
            <Plus size={15} /> إضافة صف للبطاقة
          </button>
      </div>
    </div>
  );
}

/* ─── Guest Profile Page ─────────────────────────────────────────── */
function GuestProfilePage({ onBack }: { onBack: () => void }) {
  const logoDataUrl = useBase64Image(logoSrc);
  const [phone, setPhone]   = useState("");
  const [name, setName]     = useState("");
  const [step, setStep]     = useState<"login" | "profile">("login");
  const [subs, setSubs]     = useState<Submission[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError]   = useState("");
  const [deleting, setDeleting] = useState<string | null>(null);

  const handleLogin = async () => {
    const ph = phone.trim();
    const nm = name.trim();
    if (!ph) { setError("أدخل رقم هاتفك"); return; }
    setLoading(true); setError("");
    try {
      const res = await fetchSubmissionsByPhone(ph);
      const filtered = nm
        ? res.filter(s => s.contactName.toLowerCase().includes(nm.toLowerCase()))
        : res;
      if (filtered.length === 0) {
        setError("لا توجد إعلانات مسجلة بهذا الرقم");
      } else {
        setSubs(filtered.sort((a, b) => b.submittedAt - a.submittedAt));
        setStep("profile");
      }
    } catch { setError("تعذّر الاتصال بالسيرفر"); }
    finally { setLoading(false); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("حذف هذا الإعلان نهائياً؟")) return;
    setDeleting(id);
    try {
      await deleteSubmissionApi(id);
      setSubs(prev => prev.filter(s => s.id !== id));
    } catch { setError("تعذّر حذف الإعلان"); }
    finally { setDeleting(null); }
  };

  const statusLabel = (s: Submission["status"]) =>
    s === "approved" ? { text: "✅ منشور", bg: "rgba(34,197,94,0.15)", color: "#4ade80" }
    : s === "rejected" ? { text: "❌ مرفوض", bg: "rgba(239,68,68,0.12)", color: "#f87171" }
    : { text: "⏳ قيد المراجعة", bg: "rgba(234,179,8,0.12)", color: "#facc15" };

  return (
    <div className="min-h-screen flex flex-col items-center py-8 px-5" dir="rtl"
      style={{ background: `linear-gradient(160deg,${G_DARK} 0%,${G_MID} 55%,${G_DARK} 100%)`, fontFamily: FONT }}>

      {/* Header */}
      <div className="flex items-center gap-3 w-full max-w-sm mb-6">
        <button onClick={onBack} className="p-2 rounded-full active:scale-90"
          style={{ background: "rgba(255,255,255,0.1)", color: CREAM }}>
          <ChevronRight size={22} />
        </button>
        <img src={logoDataUrl} alt="logo" className="w-10 h-10 rounded-xl object-cover"
          style={{ border: `2px solid ${AU_DEEP}` }} />
        <div>
          <p className="font-black text-sm" style={{ color: AU_TEXT }}>إعلاناتي</p>
          <p className="text-xs" style={{ color: CREAM_D }}>
            {step === "login" ? "أدخل بياناتك لعرض إعلاناتك" : `${subs.length} إعلان مسجّل`}
          </p>
        </div>
      </div>

      {step === "login" ? (
        <div className="w-full max-w-sm flex flex-col gap-4">
          <div className="rounded-2xl p-5 flex flex-col gap-4"
            style={{ background: "rgba(255,255,255,0.06)", border: BORDER }}>
            <div>
              <p className="text-sm font-bold mb-1.5" style={{ color: CREAM_D }}>👤 اسمك الكريم</p>
              <input value={name} onChange={e => setName(e.target.value)}
                placeholder="اختياري للتحقق" dir="rtl"
                className="w-full rounded-xl px-4 py-3 text-base outline-none"
                style={{ background: "rgba(255,255,255,0.12)", color: CREAM, WebkitTextFillColor: CREAM, caretColor: CREAM, border: BORDER, fontFamily: FONT }} />
            </div>
            <div>
              <p className="text-sm font-bold mb-1.5" style={{ color: CREAM_D }}>📞 رقم هاتفك *</p>
              <input value={phone} onChange={e => setPhone(e.target.value)}
                placeholder="نفس الرقم المسجّل في الإعلان" dir="ltr"
                onKeyDown={e => e.key === "Enter" && handleLogin()}
                className="w-full rounded-xl px-4 py-3 text-base outline-none"
                style={{ background: "rgba(255,255,255,0.12)", color: CREAM, WebkitTextFillColor: CREAM, caretColor: CREAM, border: BORDER, fontFamily: FONT }} />
            </div>
            {error && <p className="text-sm text-red-400 text-center">{error}</p>}
            <button onClick={handleLogin} disabled={loading}
              className="w-full py-3 rounded-xl font-black text-base active:scale-95 disabled:opacity-60"
              style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK }}>
              {loading ? "جاري البحث..." : "عرض إعلاناتي"}
            </button>
          </div>
        </div>
      ) : (
        <div className="w-full max-w-sm flex flex-col gap-3">
          {error && <p className="text-sm text-red-400 text-center bg-red-900/20 rounded-xl px-3 py-2">{error}</p>}
          {subs.map(s => {
            const st = statusLabel(s.status as Submission["status"]);
            return (
              <div key={s.id} className="rounded-2xl p-4 flex flex-col gap-2"
                style={{ background: "rgba(255,255,255,0.07)", border: BORDER }}>
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="font-black text-base truncate" style={{ color: CREAM }}>
                      {s.propertyType} — {s.region}
                    </p>
                    <p className="text-xs mt-0.5" style={{ color: CREAM_D }}>
                      {new Date(s.submittedAt).toLocaleDateString("ar-JO")}
                    </p>
                  </div>
                  <span className="text-xs px-2 py-1 rounded-full font-bold shrink-0"
                    style={{ background: st.bg, color: st.color }}>
                    {st.text}
                  </span>
                </div>
                {s.price && <p className="text-sm" style={{ color: AU_TEXT }}>💰 {s.price}</p>}
                {s.description && (
                  <p className="text-xs leading-relaxed" style={{ color: CREAM_D }}>{s.description}</p>
                )}
                {(s.status as string) === "pending" && (
                  <button onClick={() => handleDelete(s.id)}
                    disabled={deleting === s.id}
                    className="mt-1 flex items-center justify-center gap-2 py-2 rounded-xl font-bold text-sm active:scale-95 disabled:opacity-50"
                    style={{ background: "rgba(239,68,68,0.12)", color: "#f87171", border: "1px solid #f8717133" }}>
                    <Trash2 size={14} />
                    {deleting === s.id ? "جاري الحذف..." : "حذف الإعلان"}
                  </button>
                )}
              </div>
            );
          })}
          {subs.length === 0 && (
            <p className="text-center mt-8" style={{ color: CREAM_D }}>لا توجد إعلانات</p>
          )}
        </div>
      )}
    </div>
  );
}

/* ─── Login Page ─────────────────────────────────────────────────── */
function LoginPage({ onLogin, employees }: {
  onLogin: (role: Role, empInfo?: { id: string; name: string }, guestProfile?: GuestProfile, companyProfile?: CompanyProfile) => void;
  employees: Employee[];
}) {
  const logoDataUrl = useBase64Image(logoSrc);
  const [panel, setPanel]   = useState<"none" | "guest" | "company" | "employee" | "admin">("none");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [error, setError]   = useState("");
  const [guestName, setGuestName]   = useState("");
  const [guestPhone, setGuestPhone] = useState("");
  const [guestError, setGuestError] = useState("");
  const [companyNameIn, setCompanyNameIn] = useState("");
  const [companyPhoneIn, setCompanyPhoneIn] = useState("");
  const [companyError, setCompanyError] = useState("");
  const [loggingIn, setLoggingIn] = useState(false);
  const [installPrompt, setInstallPrompt] = useState<Event & { prompt?: () => Promise<void> } | null>(null);
  const [isIOS, setIsIOS] = useState(false);
  const [showIOSHint, setShowIOSHint] = useState(false);

  /* Tap-logo Easter egg:
     5 taps  → reveals Employee login (stays visible for 5 minutes)
     7 taps  → reveals Admin login   (stays visible for 5 minutes)
     Tap counter resets after 3s inactivity; unlocked state persists 5 min */
  const [logoTaps, setLogoTaps]       = useState(0);
  const [unlockedLevel, setUnlocked]  = useState(0); // 1=employee, 2=admin
  const tapTimerRef   = useRef<ReturnType<typeof setTimeout> | null>(null);
  const unlockTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleLogoTap = () => {
    setLogoTaps(prev => {
      const next = prev + 1;

      // Reset counter after 3 s of inactivity
      if (tapTimerRef.current) clearTimeout(tapTimerRef.current);
      tapTimerRef.current = setTimeout(() => setLogoTaps(0), 3000);

      // Unlock employee at 5, admin at 7 — keep unlocked for 5 minutes
      if (next >= 7) {
        setUnlocked(2);
        if (unlockTimerRef.current) clearTimeout(unlockTimerRef.current);
        unlockTimerRef.current = setTimeout(() => { setUnlocked(0); setLogoTaps(0); }, 5 * 60 * 1000);
      } else if (next >= 5) {
        setUnlocked(prev2 => Math.max(prev2, 1));
        if (unlockTimerRef.current) clearTimeout(unlockTimerRef.current);
        unlockTimerRef.current = setTimeout(() => { setUnlocked(0); setLogoTaps(0); }, 5 * 60 * 1000);
      }

      return next;
    });
  };

  const showEmployee = unlockedLevel >= 1 || logoTaps >= 5;
  const showAdmin    = unlockedLevel >= 2 || logoTaps >= 7;

  useEffect(() => {
    const ios = /iphone|ipad|ipod/i.test(navigator.userAgent) && !(window.navigator as { standalone?: boolean }).standalone;
    setIsIOS(ios);
    const handler = (e: Event) => { e.preventDefault(); setInstallPrompt(e as Event & { prompt?: () => Promise<void> }); };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const handleGuestEnter = async () => {
    const name  = guestName.trim();
    const phone = guestPhone.trim();
    setGuestError("");
    if (!name) { setGuestError("الاسم مطلوب"); return; }
    if (!/^\d+$/.test(phone) || phone.length < 10) { setGuestError("رقم الهاتف يجب أن لا يقل عن ١٠ أرقام"); return; }
    localStorage.setItem("guestProfile", JSON.stringify({ name, phone }));
    postVisitor({ id: `v_${phone}`, name, phone }).catch(() => {});
    onLogin("guest", undefined, { name, phone });
  };

  const handleCompanyEnter = async () => {
    const name  = companyNameIn.trim();
    const phone = companyPhoneIn.trim();
    setCompanyError("");
    if (!name) { setCompanyError("اسم الشركة مطلوب"); return; }
    if (!/^\d+$/.test(phone) || phone.length < 10) { setCompanyError("رقم الهاتف يجب أن لا يقل عن ١٠ أرقام"); return; }
    localStorage.setItem("companyProfile", JSON.stringify({ name, phone }));
    postCompanyVisitor({ id: `co_${phone}`, companyName: name, phone }).catch(() => {});
    onLogin("company", undefined, undefined, { name, phone });
  };

  const handleLogin = async () => {
    setError("");
    setLoggingIn(true);
    try {
      if (panel === "admin") {
        const { ok } = await verifyAdminApi(username, password);
        if (ok) { onLogin("admin"); }
        else { setError("اسم المستخدم أو كلمة السر غير صحيحة"); }
      } else {
        const res = await verifyEmployeeApi(username, password);
        if (res.ok && res.id && res.name) { onLogin("employee", { id: res.id, name: res.name }); }
        else if (res.ok) { onLogin("employee"); }
        else { setError("اسم المستخدم أو كلمة السر غير صحيحة"); }
      }
    } catch {
      setError("تعذّر الاتصال بالسيرفر، حاول مجدداً");
    } finally {
      setLoggingIn(false);
    }
  };

  const openPanel = (p: typeof panel) => {
    setPanel(prev => prev === p ? "none" : p);
    setError(""); setGuestError(""); setCompanyError("");
    setUsername(""); setPassword(""); setShowPw(false);
  };

  /* ── Input style shorthand ── */
  const inputStyle = (hasErr?: boolean) => ({
    background: "rgba(255,255,255,0.10)",
    color: CREAM, WebkitTextFillColor: CREAM, caretColor: AU_BRT,
    border: hasErr ? "2px solid #f87171" : `1.5px solid ${AU_DEEP}88`,
    fontFamily: FONT, borderRadius: 14, width: "100%",
    padding: "14px 16px", fontSize: "1rem", outline: "none",
  } as React.CSSProperties);

  /* ── Login form JSX (inlined — NOT a nested component) ── */
  const loginFormJSX = (
    <div className="flex flex-col gap-3">
      <input value={username} onChange={e => { setUsername(e.target.value); setError(""); }}
        placeholder="اسم المستخدم" dir="rtl" style={inputStyle()} />
      <div className="relative">
        <input value={password} onChange={e => { setPassword(e.target.value); setError(""); }}
          type={showPw ? "text" : "password"} placeholder="كلمة السر" dir="rtl"
          onKeyDown={e => e.key === "Enter" && handleLogin()}
          style={{ ...inputStyle(), paddingLeft: 48 }} />
        <button onClick={() => setShowPw(p => !p)}
          className="absolute top-1/2 -translate-y-1/2"
          style={{ left: 14, color: CREAM_D }}>
          {showPw ? <EyeOff size={18} /> : <Eye size={18} />}
        </button>
      </div>
      {error && (
        <p className="text-xs text-center px-2 py-1.5 rounded-lg"
          style={{ color: "#fca5a5", background: "rgba(239,68,68,0.15)" }}>{error}</p>
      )}
      <button onClick={handleLogin} disabled={loggingIn}
        className="w-full py-3.5 rounded-2xl font-black text-base active:scale-95 disabled:opacity-50 transition-transform"
        style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK, fontSize: "1.05rem" }}>
        {loggingIn ? "جاري التحقق..." : "دخول ←"}
      </button>
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col" dir="rtl"
      style={{ background: `linear-gradient(175deg,${G_DARK} 0%,#1a4a22 40%,${G_MID} 75%,${G_DARK} 100%)`, fontFamily: FONT }}>

      {/* ── Hero ─────────────────────────────────────── */}
      <div className="flex flex-col items-center pt-14 pb-8 px-6 relative">
        {/* Decorative rings */}
        <div className="absolute top-8 left-1/2 -translate-x-1/2 w-44 h-44 rounded-full pointer-events-none"
          style={{ border: `1px solid ${AU_DEEP}22`, transform: "translateX(-50%) scale(1)" }} />
        <div className="absolute top-4 left-1/2 -translate-x-1/2 w-56 h-56 rounded-full pointer-events-none"
          style={{ border: `1px solid ${AU_DEEP}11` }} />

        {/* Logo — tap 5× for employee, 7× for admin */}
        <div className="relative mb-5">
          <button onClick={handleLogoTap} className="block active:scale-95 transition-transform select-none"
            style={{ WebkitTapHighlightColor: "transparent" }}>
            <div className="w-28 h-28 rounded-3xl overflow-hidden shadow-2xl"
              style={{
                border: `3px solid ${showAdmin ? "#ef4444" : showEmployee ? AU_BRT : AU_BRT}`,
                boxShadow: showAdmin
                  ? "0 0 40px rgba(239,68,68,0.5)"
                  : showEmployee
                    ? `0 0 40px ${AU_BRT}88`
                    : `0 0 40px ${AU_DEEP}66`,
              }}>
              <img src={logoDataUrl} alt="logo" className="w-full h-full object-cover" />
            </div>
          </button>
          {/* Gold dot badge */}
          <div className="absolute -bottom-2 -left-2 w-7 h-7 rounded-full flex items-center justify-center shadow-lg pointer-events-none"
            style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})` }}>
            <Star size={13} style={{ color: G_DARK }} />
          </div>
          {/* Tap progress indicator */}
          {logoTaps > 0 && logoTaps < 7 && unlockedLevel < 2 && (
            <div className="absolute -top-2 -right-2 w-6 h-6 rounded-full flex items-center justify-center text-xs font-black pointer-events-none"
              style={{ background: logoTaps >= 5 ? AU_BRT : "rgba(255,255,255,0.2)", color: logoTaps >= 5 ? G_DARK : CREAM }}>
              {logoTaps}
            </div>
          )}
        </div>

        <h1 className="text-2xl font-black text-center leading-tight"
          style={{ color: AU_TEXT, textShadow: `0 2px 12px ${AU_DEEP}88` }}>
          شقق وأراضي المستقبل
        </h1>
        <p className="text-sm mt-1.5 font-medium" style={{ color: CREAM_D }}>
          للاستثمار العقاري المتميز
        </p>

        {/* Divider */}
        <div className="mt-5 flex items-center gap-3 w-full max-w-xs">
          <div className="flex-1 h-px" style={{ background: `linear-gradient(90deg,transparent,${AU_DEEP}66)` }} />
          <span className="text-xs font-bold px-3 py-1 rounded-full"
            style={{ background: `${AU_DEEP}22`, color: AU_TEXT, border: `1px solid ${AU_DEEP}44` }}>
            اختر طريقة الدخول
          </span>
          <div className="flex-1 h-px" style={{ background: `linear-gradient(90deg,${AU_DEEP}66,transparent)` }} />
        </div>
      </div>

      {/* ── Role Cards ───────────────────────────────── */}
      <div className="flex-1 px-5 pb-8 flex flex-col gap-3 max-w-sm mx-auto w-full">

        {/* ── GUEST ── */}
        <div className="rounded-2xl overflow-hidden"
          style={{ border: panel === "guest" ? `2px solid ${AU_BRT}` : `1.5px solid ${AU_DEEP}55`,
                   background: panel === "guest" ? `${AU_DEEP}22` : "rgba(255,255,255,0.05)",
                   transition: "border 0.2s, background 0.2s" }}>
          <button onClick={() => openPanel("guest")}
            className="w-full flex items-center gap-4 px-5 py-4 active:scale-[0.98] transition-transform">
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 shadow-md"
              style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})` }}>
              <HomeIcon size={22} style={{ color: G_DARK }} />
            </div>
            <div className="flex-1 text-right">
              <p className="font-black text-base leading-tight" style={{ color: AU_TEXT }}>تصفح كزائر</p>
              <p className="text-xs mt-0.5" style={{ color: CREAM_D }}>استعرض البطاقات العقارية</p>
            </div>
            <ChevronRight size={18} style={{ color: AU_DEEP, transform: panel === "guest" ? "rotate(90deg)" : "rotate(0)", transition: "transform 0.2s" }} />
          </button>

          {panel === "guest" && (
            <div className="px-5 pb-5 flex flex-col gap-3 border-t" style={{ borderColor: `${AU_DEEP}44` }}>
              <p className="text-xs text-center pt-3" style={{ color: CREAM_D }}>أدخل اسمك ورقم هاتفك للمتابعة</p>
              <input value={guestName} onChange={e => { setGuestName(e.target.value); setGuestError(""); }}
                placeholder="اسمك الكريم *" dir="rtl" style={inputStyle(!guestName && !!guestError)} />
              <input value={guestPhone} onChange={e => { setGuestPhone(normalizeNums(e.target.value).replace(/\D/g, "")); setGuestError(""); }}
                placeholder="رقم الهاتف — ١٠ أرقام *" dir="ltr" inputMode="numeric"
                onKeyDown={e => e.key === "Enter" && handleGuestEnter()}
                style={inputStyle(!!guestError)} />
              {guestError && (
                <p className="text-xs text-center px-2 py-1.5 rounded-lg"
                  style={{ color: "#fca5a5", background: "rgba(239,68,68,0.15)" }}>{guestError}</p>
              )}
              <button onClick={handleGuestEnter}
                className="w-full py-3.5 rounded-2xl font-black text-base active:scale-95 transition-transform"
                style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK }}>
                دخول ←
              </button>
            </div>
          )}
        </div>

        {/* ── COMPANY ── */}
        <div className="rounded-2xl overflow-hidden"
          style={{ border: panel === "company" ? `2px solid ${AU_BRT}` : `1.5px solid ${AU_DEEP}55`,
                   background: panel === "company" ? `${AU_DEEP}22` : "rgba(255,255,255,0.05)",
                   transition: "border 0.2s, background 0.2s" }}>
          <button onClick={() => openPanel("company")}
            className="w-full flex items-center gap-4 px-5 py-4 active:scale-[0.98] transition-transform">
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 shadow-md"
              style={{ background: panel === "company" ? `linear-gradient(135deg,${AU_DEEP},${AU_BRT})` : "rgba(184,145,42,0.25)", border: `1.5px solid ${AU_DEEP}66` }}>
              <Building2 size={22} style={{ color: panel === "company" ? G_DARK : AU_TEXT }} />
            </div>
            <div className="flex-1 text-right">
              <p className="font-black text-base leading-tight" style={{ color: panel === "company" ? AU_BRT : CREAM }}>دخول كشركة إسكان</p>
              <p className="text-xs mt-0.5" style={{ color: CREAM_D }}>قدّم عقاراتك وطلباتك</p>
            </div>
            <ChevronRight size={18} style={{ color: AU_DEEP, transform: panel === "company" ? "rotate(90deg)" : "rotate(0)", transition: "transform 0.2s" }} />
          </button>

          {panel === "company" && (
            <div className="px-5 pb-5 flex flex-col gap-3 border-t" style={{ borderColor: `${AU_DEEP}44` }}>
              <p className="text-xs text-center pt-3" style={{ color: CREAM_D }}>أدخل اسم الشركة ورقم التواصل</p>
              <input value={companyNameIn} onChange={e => { setCompanyNameIn(e.target.value); setCompanyError(""); }}
                placeholder="اسم الشركة / شركة الإسكان *" dir="rtl" style={inputStyle(!companyNameIn && !!companyError)} />
              <input value={companyPhoneIn} onChange={e => { setCompanyPhoneIn(normalizeNums(e.target.value).replace(/\D/g, "")); setCompanyError(""); }}
                placeholder="رقم الهاتف — ١٠ أرقام *" dir="ltr" inputMode="numeric"
                onKeyDown={e => e.key === "Enter" && handleCompanyEnter()}
                style={inputStyle(!!companyError)} />
              {companyError && (
                <p className="text-xs text-center px-2 py-1.5 rounded-lg"
                  style={{ color: "#fca5a5", background: "rgba(239,68,68,0.15)" }}>{companyError}</p>
              )}
              <button onClick={handleCompanyEnter}
                className="w-full py-3.5 rounded-2xl font-black text-base active:scale-95 transition-transform"
                style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK }}>
                دخول ←
              </button>
            </div>
          )}
        </div>

        {/* ── EMPLOYEE (shown only with ?mode=employee or ?mode=admin) ── */}
        {showEmployee && <div className="rounded-2xl overflow-hidden"
          style={{ border: panel === "employee" ? `2px solid ${AU_BRT}` : `1.5px solid rgba(255,255,255,0.18)`,
                   background: panel === "employee" ? "rgba(255,255,255,0.08)" : "rgba(255,255,255,0.05)",
                   transition: "border 0.2s, background 0.2s" }}>
          <button onClick={() => openPanel("employee")}
            className="w-full flex items-center gap-4 px-5 py-4 active:scale-[0.98] transition-transform">
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center shrink-0"
              style={{ background: "rgba(255,255,255,0.12)", border: "1.5px solid rgba(255,255,255,0.2)" }}>
              <User size={22} style={{ color: CREAM }} />
            </div>
            <div className="flex-1 text-right">
              <p className="font-black text-base leading-tight" style={{ color: CREAM }}>دخول كموظف</p>
              <p className="text-xs mt-0.5" style={{ color: CREAM_D }}>إدارة البطاقات والطلبات</p>
            </div>
            <ChevronRight size={18} style={{ color: "rgba(255,255,255,0.4)", transform: panel === "employee" ? "rotate(90deg)" : "rotate(0)", transition: "transform 0.2s" }} />
          </button>

          {panel === "employee" && (
            <div className="px-5 pb-5 flex flex-col gap-3 border-t" style={{ borderColor: "rgba(255,255,255,0.1)" }}>
              <div className="pt-3">{loginFormJSX}</div>
            </div>
          )}
        </div>}

        {/* ── ADMIN (shown only with ?mode=admin) ── */}
        {showAdmin && <div className="rounded-2xl overflow-hidden"
          style={{ border: panel === "admin" ? `2px solid ${AU_BRT}` : `1px solid rgba(255,255,255,0.10)`,
                   background: panel === "admin" ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.15)",
                   transition: "border 0.2s, background 0.2s" }}>
          <button onClick={() => openPanel("admin")}
            className="w-full flex items-center gap-4 px-5 py-3.5 active:scale-[0.98] transition-transform">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
              style={{ background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.12)" }}>
              <ShieldCheck size={19} style={{ color: CREAM_D }} />
            </div>
            <div className="flex-1 text-right">
              <p className="font-bold text-sm leading-tight" style={{ color: CREAM_D }}>دخول كمدير</p>
            </div>
            <ChevronRight size={16} style={{ color: "rgba(255,255,255,0.25)", transform: panel === "admin" ? "rotate(90deg)" : "rotate(0)", transition: "transform 0.2s" }} />
          </button>

          {panel === "admin" && (
            <div className="px-5 pb-5 flex flex-col gap-3 border-t" style={{ borderColor: "rgba(255,255,255,0.08)" }}>
              <div className="pt-3">{loginFormJSX}</div>
            </div>
          )}
        </div>}

        {/* PWA Install */}
        {(installPrompt || isIOS) && (
          <button
            onClick={async () => {
              if (isIOS) { setShowIOSHint(true); return; }
              if (installPrompt?.prompt) { await installPrompt.prompt(); setInstallPrompt(null); }
            }}
            className="flex items-center justify-center gap-2 py-3 rounded-2xl font-bold text-sm active:scale-95 mt-1"
            style={{ background: "rgba(255,255,255,0.07)", color: CREAM, border: `1px solid ${AU_DEEP}55` }}>
            📲 تثبيت التطبيق على هاتفك
          </button>
        )}

        <p className="text-center text-xs pt-2" style={{ color: "rgba(255,255,255,0.2)" }}>
          شقق وأراضي المستقبل © 2025
        </p>
      </div>

      {/* iOS install hint */}
      {showIOSHint && (
        <div className="fixed inset-0 z-50 flex items-end justify-center p-4" style={{ background: "rgba(0,0,0,0.7)" }}
          onClick={() => setShowIOSHint(false)}>
          <div className="w-full max-w-sm rounded-3xl p-6 flex flex-col gap-3" dir="rtl"
            style={{ background: G_DARK, border: `2px solid ${AU_DEEP}`, boxShadow: "0 20px 60px rgba(0,0,0,0.6)" }}
            onClick={e => e.stopPropagation()}>
            <p className="font-black text-base" style={{ color: AU_TEXT }}>تثبيت على iPhone / iPad</p>
            <div className="flex flex-col gap-2 text-sm" style={{ color: CREAM }}>
              <p>١. اضغط على زر <strong>مشاركة</strong> ⎙ في أسفل الشاشة</p>
              <p>٢. اختر <strong>"إضافة إلى الشاشة الرئيسية"</strong></p>
              <p>٣. اضغط <strong>إضافة</strong> — سيظهر التطبيق على هاتفك!</p>
            </div>
            <button onClick={() => setShowIOSHint(false)}
              className="w-full py-2.5 rounded-xl font-bold active:scale-95"
              style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK }}>
              حسناً
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── Guest Page ─────────────────────────────────────────────────── */
function GuestPage({ cards, onBack, guestProfile }: {
  cards: SavedCard[]; onBack: () => void; guestProfile?: GuestProfile;
}) {
  const logoDataUrl = useBase64Image(logoSrc);
  const [query, setQuery]           = useState("");
  const [showSubmit, setShowSubmit] = useState(false);
  const [viewerIndex, setViewerIndex] = useState<number | null>(null);
  const [galleryCardId, setGalleryCardId] = useState<string | null>(null);
  const [allSubs, setAllSubs] = useState<Submission[]>([]);
  /* Contact prompt modal for featured ads */
  const [contactPrompt, setContactPrompt] = useState<{
    item: ListingEntry; phone: string; href: string;
  } | null>(null);
  const [showMyAds, setShowMyAds]   = useState(false);
  const [myAds, setMyAds]           = useState<Submission[]>([]);
  const [myAdsLoading, setMyAdsLoading] = useState(false);
  const [myAdsError, setMyAdsError] = useState("");
  const [deletingAd, setDeletingAd] = useState<string | null>(null);
  const [editingAd, setEditingAd]   = useState<Submission | null>(null);
  const [editSaving, setEditSaving] = useState(false);
  const [subsLoading, setSubsLoading] = useState(true);
  const [featuredAds, setFeaturedAds] = useState<FeaturedAd[]>([]);
  const listRef = useRef<HTMLDivElement>(null);

  const reloadSubs = async () => {
    try {
      const [subs, fa] = await Promise.all([fetchSubmissions(), fetchFeaturedApproved()]);
      setAllSubs(subs);
      setFeaturedAds(fa.filter(a => !a.expiresAt || a.expiresAt > Date.now()));
    } catch { /* silently keep current list */ } finally {
      setSubsLoading(false);
    }
  };

  useEffect(() => { reloadSubs(); }, []);

  /* Refresh featured ads every 60 s so newly-approved ads show automatically */
  useEffect(() => {
    const id = setInterval(async () => {
      try {
        const fa = await fetchFeaturedApproved();
        setFeaturedAds(fa.filter(a => !a.expiresAt || a.expiresAt > Date.now()));
      } catch { /* silent */ }
    }, 60_000);
    return () => clearInterval(id);
  }, []);

  const handleSubmitClose = () => { setShowSubmit(false); reloadSubs(); };

  const loadMyAds = async () => {
    if (!guestProfile?.phone) return;
    setMyAdsLoading(true); setMyAdsError("");
    try {
      const res = await fetchSubmissionsByPhone(guestProfile.phone);
      setMyAds(res.sort((a, b) => b.submittedAt - a.submittedAt));
    } catch { setMyAdsError("تعذّر الاتصال بالسيرفر"); }
    finally { setMyAdsLoading(false); }
  };

  const handleOpenMyAds = () => {
    setShowMyAds(true);
    if (myAds.length === 0) loadMyAds();
  };

  const handleDeleteMyAd = async (id: string) => {
    if (!confirm("حذف هذا الإعلان نهائياً؟")) return;
    setDeletingAd(id);
    try {
      await deleteSubmissionApi(id);
      setMyAds(prev => prev.filter(s => s.id !== id));
    } catch { setMyAdsError("تعذّر حذف الإعلان"); }
    finally { setDeletingAd(null); }
  };

  const openViewer = (idx: number) => {
    history.pushState({ viewerOpen: true }, "");
    setViewerIndex(idx);
  };

  const closeViewer = () => {
    setViewerIndex(null);
    listRef.current?.scrollTo({ top: 0, behavior: "smooth" });
  };

  useEffect(() => {
    const onPopState = () => {
      if (viewerIndex !== null) setViewerIndex(null);
    };
    window.addEventListener("popstate", onPopState);
    return () => window.removeEventListener("popstate", onPopState);
  }, [viewerIndex]);

  // Build unified listing: agent cards + approved submissions with cardData
  type ListingEntry = { id: string; data: CardData; region: string; cardNum?: number; label?: string; photoCardId: string; featured?: boolean; featuredPhone?: string; featuredAdId?: number };

  /* Agent/company cards — check if any are linked to an active featured ad */
  const agentItems: ListingEntry[] = cards.map(c => {
    const submissionId = c.id.startsWith("sub_") ? c.id.slice(4) : null;
    const fa = submissionId ? featuredAds.find(a => a.submissionId === submissionId) : null;
    return {
      id: c.id, data: c.data, region: c.region, cardNum: c.cardNum, photoCardId: c.id,
      featured: !!fa,
      featuredPhone: fa?.companyPhone,
      featuredAdId: fa?.id,
    };
  });

  /* Guest/company submissions not yet merged into cards */
  const subItems: ListingEntry[] = allSubs
    .filter(s => s.status === "approved")
    .filter(s => !cards.some(c => c.id === `sub_${s.id}`))
    .map(s => {
      const fa = featuredAds.find(a => a.submissionId === s.id);
      return {
        id: s.id,
        data: s.cardData ?? submissionToCardData(s),
        region: s.cardRegion || s.region,
        label: fa ? undefined : (s.submittedBy === "company" ? "شركة إسكان" : s.submittedBy === "guest" ? "عرض زبون" : undefined),
        cardNum: s.cardNum,
        photoCardId: `sub_${s.id}`,
        featured: !!fa,
        featuredPhone: fa?.companyPhone,
        featuredAdId: fa?.id,
      };
    });

  /* Featured cards (from both sources) always appear first, sorted by newest */
  const featuredAgent = agentItems.filter(i => i.featured);
  const featuredSub   = subItems.filter(i => i.featured);
  const regularAgent  = agentItems.filter(i => !i.featured);
  const regularSub    = subItems.filter(i => !i.featured);
  const allItems: ListingEntry[] = [...featuredAgent, ...featuredSub, ...regularAgent, ...regularSub];

  const q = normalizeNums(query.trim().toLowerCase());
  const norm = (s: string) => normalizeNums(s.toLowerCase());
  const filtered = allItems.filter(item => {
    if (!q) return true;
    if (!item.data) return false;
    return (
      norm(item.region || "").includes(q) ||
      norm(item.data.projectName || "").includes(q) ||
      norm(String(item.cardNum || "")).includes(q) ||
      (item.data.floors ?? []).some(f =>
        norm(f.price || "").includes(q) ||
        norm(f.area || "").includes(q) ||
        norm(f.name || "").includes(q)
      ) ||
      norm(item.data.note1 || "").includes(q) ||
      norm(item.data.note2 || "").includes(q) ||
      norm(item.data.description || "").includes(q)
    );
  });

  const viewerItems: ViewerItem[] = filtered.map(f => ({
    data: f.data, cardNum: f.cardNum, photoCardId: f.photoCardId,
    featuredPhone: f.featuredPhone, featuredAdId: f.featuredAdId,
  }));

  return (
    <div className="min-h-screen flex flex-col" dir="rtl"
      style={{ background: `linear-gradient(160deg,${G_DARK} 0%,${G_MID} 55%,${G_DARK} 100%)`, fontFamily: FONT }}>

      {/* Header */}
      <div className="flex items-center gap-3 px-4 pt-6 pb-3">
        <button onClick={onBack} className="p-2 rounded-full active:scale-90"
          style={{ background: "rgba(255,255,255,0.1)", color: CREAM }}>
          <LogOut size={20} />
        </button>
        <img src={logoDataUrl} alt="logo" className="w-9 h-9 rounded-xl object-cover" style={{ border: `2px solid ${AU_DEEP}` }} />
        <div className="flex-1">
          <p className="font-black text-sm leading-tight" style={{ color: AU_TEXT }}>شقق وأراضي المستقبل</p>
          {guestProfile?.name
            ? <p className="text-xs" style={{ color: CREAM_D }}>مرحباً، {guestProfile.name}</p>
            : <p className="text-xs" style={{ color: CREAM_D }}>تصفح العقارات المتاحة</p>
          }
        </div>
        {guestProfile?.phone && (
          <button onClick={handleOpenMyAds}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold active:scale-90"
            style={{ background: `linear-gradient(135deg,${AU_DEEP}99,${AU_BRT}99)`, color: CREAM, border: BORDER }}>
            <User size={13} /> إعلاناتي
          </button>
        )}
      </div>

      {/* Search + Post button */}
      <div className="px-4 mb-3 flex items-center gap-2">
        <div className="flex-1 flex items-center gap-2 rounded-xl px-3 py-2.5"
          style={{ background: "rgba(255,255,255,0.1)", border: BORDER }}>
          <Search size={16} style={{ color: CREAM_D, flexShrink: 0 }} />
          <input value={query} onChange={e => setQuery(e.target.value)}
            placeholder="ابحث بالمنطقة، السعر، المساحة، الغرف..." dir="rtl"
            className="flex-1 bg-transparent outline-none text-sm"
            style={{ color: CREAM, WebkitTextFillColor: CREAM, caretColor: CREAM, fontFamily: FONT }} />
          {query && <button onClick={() => setQuery("")}><X size={14} style={{ color: CREAM_D }} /></button>}
        </div>
        <button onClick={() => setShowSubmit(true)}
          className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl font-black text-sm shrink-0 active:scale-95 shadow-lg"
          style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK }}>
          <Plus size={16} /> اعرض عقارك
        </button>
      </div>

      {/* Cards list */}
      <div ref={listRef} className="flex-1 overflow-y-auto px-4 pb-6 space-y-3">
        {subsLoading && (
          <div className="text-center mt-20" style={{ color: CREAM_D }}>
            <div className="inline-block w-8 h-8 border-4 border-t-transparent rounded-full animate-spin mb-3"
              style={{ borderColor: `${AU_DEEP} transparent ${AU_DEEP} ${AU_DEEP}` }} />
            <p className="text-sm">جاري التحميل...</p>
          </div>
        )}
        {!subsLoading && filtered.length === 0 && (
          <div className="text-center mt-20" style={{ color: CREAM_D }}>
            <Building2 size={48} className="mx-auto mb-3 opacity-40" />
            <p>{query ? "لا توجد نتائج" : "لا توجد عقارات متاحة حالياً"}</p>
          </div>
        )}
        {filtered.map((item, listIndex) => (
          <div key={item.id} className="rounded-2xl p-4 flex flex-col gap-2"
            style={{
              background: item.featured ? "rgba(184,145,42,0.12)" : "rgba(255,255,255,0.08)",
              border: item.featured ? `1.5px solid ${AU_DEEP}cc` : BORDER,
            }}>
            <div className="flex items-center justify-between">
              <p className="font-black text-base truncate flex-1 ml-2" style={{ color: CREAM }}>
                {item.data.projectName}
              </p>
              <div className="flex items-center gap-2 shrink-0">
                {item.featured && (
                  <span className="flex items-center gap-1 text-xs px-2 py-1 rounded-full font-black"
                    style={{ background: "#ef4444", color: "#fff" }}>
                    <Star size={10} /> مميز
                  </span>
                )}
                {item.cardNum && (
                  <span className="text-xs px-2 py-1 rounded-full font-bold" style={{ background: `${AU_DEEP}44`, color: AU_TEXT }}>
                    #{item.cardNum}
                  </span>
                )}
                {item.label && !item.featured && (
                  <span className="text-xs px-2 py-1 rounded-full font-bold" style={{ background: "rgba(255,255,255,0.1)", color: CREAM_D }}>
                    {item.label}
                  </span>
                )}
              </div>
            </div>
            {item.region && (
              <p className="text-sm flex items-center gap-1" style={{ color: CREAM_D }}>
                <MapPin size={13} /> {item.region}
              </p>
            )}
            {(item.data?.floors?.length ?? 0) > 0 && (
              <div className="flex flex-wrap gap-2 mt-1">
                {item.data.floors.slice(0, 3).map(f => (
                  <span key={f.id} className="text-xs px-2 py-1 rounded-lg"
                    style={{ background: "rgba(255,255,255,0.1)", color: CREAM }}>
                    {f.name} — {f.price}
                  </span>
                ))}
              </div>
            )}
            {/* Action buttons */}
            <div className="flex gap-2 mt-1">
              <button
                onClick={() => openViewer(listIndex)}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl font-bold text-sm active:scale-95"
                style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK }}>
                <Building2 size={15} /> فتح البطاقة
              </button>
              <button
                onClick={() => setGalleryCardId(item.photoCardId)}
                className="flex items-center justify-center gap-1 px-3 py-2.5 rounded-xl font-bold text-sm active:scale-95"
                style={{ background: "rgba(201,162,39,0.15)", color: AU_TEXT, border: `1.5px solid ${AU_DEEP}` }}>
                <Camera size={15} /> الصور
              </button>
              {(() => {
                const isFeatured = !!item.featuredPhone;
                const ownerPhoneRaw = isFeatured ? item.featuredPhone! : "0798561011";
                const phone = `962${ownerPhoneRaw.replace(/^0/, "")}`;
                const cardRef = item.cardNum ? ` | رقم البطاقة: #${item.cardNum}` : "";
                const msg = `أهلاً، أريد الاستفسار عن ${item.data.projectName}${cardRef}`;
                const href = `https://api.whatsapp.com/send?phone=${phone}&text=${encodeURIComponent(msg)}`;
                return (
                  <button
                    onClick={() => {
                      if (isFeatured && item.featuredAdId) {
                        setContactPrompt({ item, phone: guestProfile?.phone ?? "", href });
                      } else {
                        window.open(href, "_blank", "noopener,noreferrer");
                      }
                    }}
                    className="flex items-center justify-center gap-1 px-3 py-2.5 rounded-xl font-bold text-sm active:scale-95"
                    style={{ background: "#25D366", color: "#fff" }}>
                    <Phone size={15} />
                  </button>
                );
              })()}
            </div>
          </div>
        ))}
      </div>

      {/* Card Viewer */}
      {viewerIndex !== null && (
        <CardViewer
          items={viewerItems}
          startIndex={viewerIndex}
          onClose={closeViewer}
          logoUrl={logoDataUrl}
        />
      )}

      {/* ── Contact prompt modal for featured ads ── */}
      {contactPrompt && (() => {
        const cp = contactPrompt;
        const ownerName = cp.item.data.projectName || cp.item.data.contactName || "";
        const ownerPhone = cp.item.featuredPhone ?? "";
        return (
          <div className="fixed inset-0 z-[80] flex items-end justify-center"
            style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(4px)" }}>
            <div className="w-full max-w-sm rounded-t-3xl p-6 pb-10 flex flex-col gap-4" dir="rtl"
              style={{ background: `linear-gradient(160deg,${G_DARK},${G_MID})`, border: `1px solid ${AU_DEEP}55` }}>
              <div className="flex items-center justify-between">
                <span className="font-black text-base" style={{ color: AU_TEXT }}>التواصل مع صاحب الإعلان</span>
                <button onClick={() => setContactPrompt(null)} className="p-1.5 rounded-full active:scale-90"
                  style={{ background: "rgba(255,255,255,0.1)", color: CREAM }}>
                  <X size={16} />
                </button>
              </div>
              <p className="text-xs leading-relaxed" style={{ color: CREAM_D }}>
                أدخل رقمك لإتمام التواصل مع صاحب الإعلان، أو اضغط "تخطي" للمتابعة مباشرة.
              </p>
              <input
                type="tel" dir="ltr" placeholder="07xxxxxxxx"
                value={cp.phone}
                onChange={e => setContactPrompt({ ...cp, phone: normalizeNums(e.target.value) })}
                className="rounded-xl px-4 py-3 text-sm font-bold text-center bg-transparent outline-none"
                style={{ border: `1.5px solid ${AU_DEEP}`, color: CREAM, caretColor: CREAM }}
              />
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    const vPhone = cp.phone.trim();
                    if (cp.item.featuredAdId) {
                      logFeaturedContact(cp.item.featuredAdId, {
                        visitorPhone: vPhone || "—",
                        ownerPhone,
                        ownerName,
                      }).catch(() => {});
                    }
                    setContactPrompt(null);
                    window.open(cp.href, "_blank", "noopener,noreferrer");
                  }}
                  className="flex-1 py-3 rounded-xl font-black text-sm active:scale-95"
                  style={{ background: "#25D366", color: "#fff" }}>
                  <Phone size={15} className="inline ml-1" /> تواصل الآن
                </button>
                <button
                  onClick={() => {
                    if (cp.item.featuredAdId) {
                      logFeaturedContact(cp.item.featuredAdId, {
                        visitorPhone: "—",
                        ownerPhone, ownerName,
                      }).catch(() => {});
                    }
                    setContactPrompt(null);
                    window.open(cp.href, "_blank", "noopener,noreferrer");
                  }}
                  className="px-4 py-3 rounded-xl font-bold text-xs active:scale-95"
                  style={{ background: "rgba(255,255,255,0.08)", color: CREAM_D }}>
                  تخطي
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Submit form sheet */}
      {showSubmit && <SubmitForm onClose={handleSubmitClose} guestProfile={guestProfile} />}

      {/* Photo gallery modal — accessible for all */}
      {galleryCardId && (
        <PhotoGalleryModal
          cardId={galleryCardId}
          readOnly
          onClose={() => setGalleryCardId(null)}
        />
      )}

      {/* ── My Ads overlay sheet ── */}
      {showMyAds && (
        <div className="fixed inset-0 z-50 flex flex-col" dir="rtl"
          style={{ background: `linear-gradient(160deg,${G_DARK} 0%,${G_MID} 60%,${G_DARK} 100%)`, fontFamily: FONT }}>
          <div className="flex items-center gap-3 px-4 pt-10 pb-4 shrink-0">
            <button onClick={() => setShowMyAds(false)} className="p-2 rounded-full active:scale-90"
              style={{ background: "rgba(255,255,255,0.1)", color: CREAM }}>
              <ChevronRight size={22} />
            </button>
            <div className="flex-1">
              <p className="font-black text-base" style={{ color: AU_TEXT }}>إعلاناتي</p>
              <p className="text-xs" style={{ color: CREAM_D }}>
                {myAdsLoading ? "جاري البحث..." : `${myAds.length} إعلان مسجّل`}
              </p>
            </div>
            <button onClick={loadMyAds} disabled={myAdsLoading}
              className="p-2 rounded-full active:scale-90 disabled:opacity-50"
              style={{ background: "rgba(255,255,255,0.1)", color: CREAM }}>
              <RefreshCw size={18} className={myAdsLoading ? "animate-spin" : ""} />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto px-4 pb-10 flex flex-col gap-3">
            {myAdsLoading && (
              <div className="flex justify-center mt-10">
                <div className="w-8 h-8 rounded-full border-2 border-t-transparent animate-spin"
                  style={{ borderColor: `${AU_BRT} transparent ${AU_BRT} ${AU_BRT}` }} />
              </div>
            )}
            {myAdsError && <p className="text-sm text-red-400 text-center">{myAdsError}</p>}
            {!myAdsLoading && myAds.length === 0 && !myAdsError && (
              <p className="text-center mt-10 text-sm" style={{ color: CREAM_D }}>لا توجد إعلانات مسجّلة</p>
            )}
            {myAds.map(s => {
              const statusInfo =
                s.status === "approved" ? { text: "✅ منشور", bg: "rgba(34,197,94,0.15)", color: "#4ade80" }
                : s.status === "rejected" ? { text: "❌ مرفوض", bg: "rgba(239,68,68,0.12)", color: "#f87171" }
                : { text: "⏳ قيد المراجعة", bg: "rgba(234,179,8,0.12)", color: "#facc15" };
              return (
                <div key={s.id} className="rounded-2xl p-4 flex flex-col gap-2"
                  style={{ background: "rgba(255,255,255,0.07)", border: BORDER }}>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <p className="font-black text-base truncate" style={{ color: CREAM }}>
                        {s.propertyType} — {s.region}
                      </p>
                      <p className="text-xs mt-0.5" style={{ color: CREAM_D }}>
                        {new Date(s.submittedAt).toLocaleDateString("ar-JO")}
                      </p>
                    </div>
                    <span className="text-xs px-2 py-1 rounded-full font-bold shrink-0"
                      style={{ background: statusInfo.bg, color: statusInfo.color }}>
                      {statusInfo.text}
                    </span>
                  </div>
                  {s.price && <p className="text-sm" style={{ color: AU_TEXT }}>💰 {s.price}</p>}
                  {s.description && (
                    <p className="text-xs leading-relaxed" style={{ color: CREAM_D }}>{s.description}</p>
                  )}
                  <div className="mt-1 flex gap-2">
                    <button onClick={() => setEditingAd({ ...s })}
                      className="flex-1 flex items-center justify-center gap-2 py-2 rounded-xl font-bold text-sm active:scale-95"
                      style={{ background: "rgba(184,145,42,0.12)", color: AU_TEXT, border: `1px solid ${AU_DEEP}44` }}>
                      <Pencil size={14} /> تعديل
                    </button>
                    <button onClick={() => handleDeleteMyAd(s.id)}
                      disabled={deletingAd === s.id}
                      className="flex-1 flex items-center justify-center gap-2 py-2 rounded-xl font-bold text-sm active:scale-95 disabled:opacity-50"
                      style={{ background: "rgba(239,68,68,0.12)", color: "#f87171", border: "1px solid #f8717133" }}>
                      <Trash2 size={14} />
                      {deletingAd === s.id ? "جاري الحذف..." : "حذف"}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── Edit Ad Overlay ── */}
      {editingAd && (
        <div className="fixed inset-0 z-[60] flex items-end justify-center"
          style={{ background: "rgba(0,0,0,0.7)" }}
          onClick={() => setEditingAd(null)}>
          <div className="w-full max-w-md rounded-t-3xl flex flex-col gap-4 p-5 pb-10" dir="rtl"
            style={{ background: `linear-gradient(160deg,${G_DARK},${G_MID})`, border: `2px solid ${AU_DEEP}`, borderBottom: "none", maxHeight: "80vh", overflowY: "auto" }}
            onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <p className="font-black text-base" style={{ color: AU_TEXT }}>تعديل الإعلان</p>
              <button onClick={() => setEditingAd(null)}><X size={20} style={{ color: CREAM_D }} /></button>
            </div>
            {/* Region */}
            <div>
              <label className="text-xs font-bold mb-1 block" style={{ color: CREAM_D }}>المنطقة</label>
              <input value={editingAd.region} onChange={e => setEditingAd(a => a ? { ...a, region: e.target.value } : a)}
                className="w-full rounded-xl px-3 py-2.5 outline-none text-sm" dir="rtl"
                style={{ background: "rgba(255,255,255,0.1)", color: CREAM, border: BORDER, fontFamily: FONT }} />
            </div>
            {/* Property type */}
            <div>
              <label className="text-xs font-bold mb-1 block" style={{ color: CREAM_D }}>نوع العقار</label>
              <input value={editingAd.propertyType} onChange={e => setEditingAd(a => a ? { ...a, propertyType: e.target.value } : a)}
                className="w-full rounded-xl px-3 py-2.5 outline-none text-sm" dir="rtl"
                style={{ background: "rgba(255,255,255,0.1)", color: CREAM, border: BORDER, fontFamily: FONT }} />
            </div>
            {/* Price */}
            <div>
              <label className="text-xs font-bold mb-1 block" style={{ color: CREAM_D }}>السعر</label>
              <input value={editingAd.price} onChange={e => setEditingAd(a => a ? { ...a, price: e.target.value } : a)}
                className="w-full rounded-xl px-3 py-2.5 outline-none text-sm" dir="rtl"
                style={{ background: "rgba(255,255,255,0.1)", color: CREAM, border: BORDER, fontFamily: FONT }} />
            </div>
            {/* Description */}
            <div>
              <label className="text-xs font-bold mb-1 block" style={{ color: CREAM_D }}>الوصف</label>
              <textarea value={editingAd.description} onChange={e => setEditingAd(a => a ? { ...a, description: e.target.value } : a)}
                rows={3} className="w-full rounded-xl px-3 py-2.5 outline-none text-sm resize-none" dir="rtl"
                style={{ background: "rgba(255,255,255,0.1)", color: CREAM, border: BORDER, fontFamily: FONT }} />
            </div>
            <button
              disabled={editSaving}
              onClick={async () => {
                if (!editingAd) return;
                setEditSaving(true);
                try {
                  await patchSubmission(editingAd.id, {
                    region: editingAd.region,
                    propertyType: editingAd.propertyType,
                    price: editingAd.price,
                    description: editingAd.description,
                  });
                  setMyAds(prev => prev.map(s => s.id === editingAd.id ? { ...s, ...editingAd } : s));
                  setEditingAd(null);
                } catch { alert("تعذّر حفظ التعديلات"); }
                finally { setEditSaving(false); }
              }}
              className="w-full py-3 rounded-2xl font-black text-base active:scale-95 disabled:opacity-60"
              style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK }}>
              {editSaving ? "جاري الحفظ..." : "حفظ التعديلات"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── Company Page ───────────────────────────────────────────────── */
const CO_BLUE  = "#1d4ed8";
const CO_BLUE2 = "#2563eb";
const CO_LBLUE = "#93c5fd";

function CompanyPage({ onBack, companyProfile }: { onBack: () => void; companyProfile: CompanyProfile }) {
  const [region,    setRegion]    = useState("");
  const [ownerName, setOwnerName] = useState("");
  const [ownerPhone,setOwnerPhone]= useState("");
  const [locUrl,    setLocUrl]    = useState("");
  const [projectTitle, setProjectTitle] = useState("");
  const [description,  setDescription]  = useState("");
  const DEFAULT_FLOORS: Floor[] = [
    { id: 1, name: "طابق التسوية",              area: "", price: "" },
    { id: 2, name: "الطابق الأرضي مع ترس",       area: "", price: "" },
    { id: 3, name: "الطابق الأرضي مع حديقة",     area: "", price: "" },
    { id: 4, name: "الطابق الأول والثاني مكرر",  area: "", price: "" },
    { id: 5, name: "الطابق الثالث مع روف وترس",  area: "", price: "" },
  ];
  const [floors, setFloors] = useState<Floor[]>(DEFAULT_FLOORS.map(f => ({...f})));
  const [submitErr,  setSubmitErr]  = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitOk,   setSubmitOk]   = useState(false);
  const [submitOkPaid, setSubmitOkPaid] = useState(false);
  const [formKey,    setFormKey]    = useState(0);
  const [submissionId, setSubmissionId] = useState(() => `co_${Date.now()}`);
  const locUrlRef = useRef<HTMLInputElement>(null);
  const photoCardId = `sub_${submissionId}`;

  /* Paid ads tab */
  const [adMode, setAdMode]           = useState<"free"|"paid">("free");
  const [selectedPlan, setSelectedPlan] = useState<typeof PLANS[0] | null>(null);
  const [showPayInfo, setShowPayInfo]   = useState(false);
  const [paymentModal, setPaymentModal] = useState<{ refId: string; plan: typeof PLANS[0]; cardNum?: number } | null>(null);

  /* Photos */
  const [photos, setPhotos]       = useState<Photo[]>([]);
  const [uploading, setUploading] = useState(false);

  /* My Ads */
  const [showMyAds, setShowMyAds]   = useState(false);
  const [myAds, setMyAds]           = useState<Submission[]>([]);
  const [myAdsLoading, setMyAdsLoading] = useState(false);
  const [deletingAd, setDeletingAd] = useState<string | null>(null);
  const [editingAd,  setEditingAd]  = useState<Submission | null>(null);
  const [editFloors, setEditFloors] = useState<Floor[]>([]);
  const [editSaving, setEditSaving] = useState(false);
  const [editPhotos, setEditPhotos] = useState<Photo[]>([]);
  const [editPhotosLoading, setEditPhotosLoading] = useState(false);
  const [deletingPhoto, setDeletingPhoto] = useState<string | null>(null);
  const [featuredNotif, setFeaturedNotif] = useState<string | null>(null);

  /* Poll for featured-ad approval notification */
  useEffect(() => {
    const SEEN_KEY = `feat_seen_${companyProfile.phone}`;
    const seenRaw = localStorage.getItem(SEEN_KEY);
    const seen: string[] = seenRaw ? JSON.parse(seenRaw) : [];

    const check = async () => {
      try {
        const approved = await fetchFeaturedApproved();
        const newlyApproved = approved.filter(a =>
          a.companyPhone === companyProfile.phone &&
          !seen.includes(a.submissionId)
        );
        if (newlyApproved.length > 0) {
          const newSeen = [...seen, ...newlyApproved.map(a => a.submissionId)];
          localStorage.setItem(SEEN_KEY, JSON.stringify(newSeen));
          setFeaturedNotif(`🌟 تم تفعيل إعلانك المميز — ${newlyApproved[0].planLabel.replace("إعلان مميز — ","")}`);
        }
      } catch { /* ignore */ }
    };

    check();
    const timer = setInterval(check, 60_000);
    return () => clearInterval(timer);
  }, [companyProfile.phone]);

  const addFloor = () => setFloors(f => [...f, { id: Date.now(), name: `الطابق ${f.length + 1}`, area: "", price: "" }]);
  const delFloor = (id: number) => setFloors(f => f.filter(x => x.id !== id));
  const setFloorF = (id: number, field: keyof Floor, val: string) =>
    setFloors(f => f.map(x => x.id === id ? { ...x, [field]: val } : x));

  const loadMyAds = async () => {
    setMyAdsLoading(true);
    try {
      const all = await fetchSubmissionsByPhone(companyProfile.phone);
      setMyAds(all.filter(s => s.submittedBy === "company"));
    } catch { /* ignore */ }
    finally { setMyAdsLoading(false); }
  };

  const handleUpload = async (files: FileList | null) => {
    if (!files?.length) return;
    setUploading(true);
    try {
      for (const file of Array.from(files)) {
        const { uploadURL, objectPath } = await requestUploadUrl(file);
        await fetch(uploadURL, { method: "PUT", body: file, headers: { "Content-Type": file.type } });
        const p = await postPhoto(photoCardId, objectPath);
        setPhotos(prev => [...prev, p]);
      }
    } catch { alert("تعذّر رفع الصورة"); }
    finally { setUploading(false); }
  };

  const buildCardData = (): CardData => ({
    companyName: "شقق وأراضي المستقبل",
    subtitle: "للاستثمار العقاري المتميز",
    projectName: projectTitle.trim() || region.trim() || "مشروع عقاري",
    phone: "0798561011",
    note1: "", note2: DEFAULT_DATA.note2,
    floors: floors.filter(f => f.area || f.price),
    description: description.trim() || undefined,
  });

  const submit = async () => {
    setSubmitErr("");
    if (adMode === "paid" && !selectedPlan) { setSubmitErr("اختر باقة الإعلان المميز أولاً"); return; }
    if (!region.trim())    { setSubmitErr("موقع المشروع مطلوب"); return; }
    if (!ownerName.trim()) { setSubmitErr("اسم صاحب المشروع مطلوب"); return; }
    if (!ownerPhone.trim()){ setSubmitErr("رقم هاتف صاحب المشروع مطلوب"); return; }
    if (!locUrl.trim()) {
      setSubmitErr("رابط الموقع على Google Maps مطلوب");
      locUrlRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
      locUrlRef.current?.focus();
      return;
    }
    if (floors.filter(f => f.area && f.price).length === 0) { setSubmitErr("أدخل مساحة وسعر طابق واحد على الأقل"); return; }
    setSubmitting(true);
    try {
      const ownerContact = `اسم: ${ownerName.trim()}\nهاتف: ${ownerPhone.trim()}\nموقع: ${locUrl.trim()}`;
      await postSubmission({
        id: submissionId, submittedAt: Date.now(),
        status: "pending", submittedBy: "company",
        ownerType: "شركة", propertyType: "عمارة سكنية",
        region: region.trim(), price: "",
        floor: "", area: "",
        contactName: companyProfile.name, phone: companyProfile.phone,
        description: description.trim(),
        ownerContact,
        cardData: buildCardData(),
        cardRegion: region.trim(),
        companyName: companyProfile.name,
      } as Submission & { companyName: string });
      /* If paid mode — fetch next card num, post featured ad request, then show payment modal */
      if (adMode === "paid" && selectedPlan) {
        const { nextCardNum } = await fetchNextCardNum().catch(() => ({ nextCardNum: undefined }));
        await postFeaturedAd({
          submissionId,
          companyName: companyProfile.name,
          companyPhone: ownerPhone.trim(),
          planDays: selectedPlan.days,
          planLabel: selectedPlan.label,
          planPrice: selectedPlan.price,
          submittedAt: Date.now(),
          cardNum: nextCardNum ?? null,
        });
        /* Show payment modal — card number is the reference */
        setPaymentModal({ refId: submissionId, plan: selectedPlan, cardNum: nextCardNum });
      }
      /* Full form reset — stay on page */
      setRegion(""); setOwnerName(""); setOwnerPhone(""); setLocUrl("");
      setProjectTitle(""); setDescription("");
      setFloors(DEFAULT_FLOORS.map(f => ({ ...f })));
      setPhotos([]);
      setSubmissionId(`co_${Date.now()}`);
      const wasPaid = adMode === "paid";
      setAdMode("free"); setSelectedPlan(null); setShowPayInfo(false);
      setFormKey(k => k + 1);
      if (!wasPaid) {
        setSubmitOk(true);
        setTimeout(() => { setSubmitOk(false); }, 5000);
      }
    } catch { setSubmitErr("تعذّر نشر الإعلان، حاول مجدداً"); }
    finally { setSubmitting(false); }
  };

  /* ── Edit helpers ── */
  const openEdit = (s: Submission) => {
    setEditingAd({ ...s });
    const cd = s.cardData;
    setEditFloors(cd?.floors ? cd.floors.map(f => ({ ...f })) : []);
    setEditPhotos([]);
    setEditPhotosLoading(true);
    fetchPhotos(`sub_${s.id}`).then(ps => setEditPhotos(ps)).catch(() => {}).finally(() => setEditPhotosLoading(false));
  };
  const setEFloor = (id: number, field: keyof Floor, val: string) =>
    setEditFloors(f => f.map(x => x.id === id ? { ...x, [field]: val } : x));
  const addEFloor = () => setEditFloors(f => [...f, { id: Date.now(), name: `الطابق ${f.length + 1}`, area: "", price: "" }]);
  const delEFloor = (id: number) => setEditFloors(f => f.filter(x => x.id !== id));

  const saveEdit = async () => {
    if (!editingAd) return;
    const lines = (editingAd.ownerContact ?? "").split("\n");
    const parse = (pfx: string) => lines.find(l => l.startsWith(pfx))?.slice(pfx.length).trim() ?? "";
    const eOwnerName  = parse("اسم: ");
    const eOwnerPhone = parse("هاتف: ");
    const eLocUrl     = parse("موقع: ");
    const newOwnerContact = `اسم: ${eOwnerName}\nهاتف: ${eOwnerPhone}${eLocUrl ? `\nموقع: ${eLocUrl}` : ""}`;
    const newCardData: CardData = {
      ...(editingAd.cardData ?? buildCardData()),
      projectName: editingAd.region || editingAd.cardData?.projectName || "",
      floors: editFloors.filter(f => f.area || f.price),
      description: editingAd.description || undefined,
    };
    setEditSaving(true);
    try {
      await patchSubmission(editingAd.id, {
        region: editingAd.region,
        description: editingAd.description,
        ownerContact: newOwnerContact,
        cardData: newCardData,
        cardRegion: editingAd.region,
      });
      setMyAds(prev => prev.map(s => s.id === editingAd.id
        ? { ...s, region: editingAd.region, description: editingAd.description, ownerContact: newOwnerContact, cardData: newCardData }
        : s));
      setEditingAd(null);
    } catch { alert("تعذّر حفظ التعديلات"); }
    finally { setEditSaving(false); }
  };

  return (
    <div className="min-h-screen flex flex-col items-center pb-20" dir="rtl"
      style={{ background: `linear-gradient(160deg,${G_DARK} 0%,${G_MID} 55%,${G_DARK} 100%)`, fontFamily: FONT }}>

      {/* Success banner (free ads only) */}
      {submitOk && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 px-5 py-3.5 rounded-2xl shadow-xl"
          style={{ background: "linear-gradient(135deg,#16a34a,#22c55e)", color: "#fff", minWidth: 260 }}>
          <Check size={20} />
          <div>
            <p className="font-black text-sm">✅ تم إرسال الإعلان بنجاح!</p>
            <p className="text-xs opacity-80">سينشر بعد موافقة الإدارة — يمكنك نشر إعلان آخر</p>
          </div>
        </div>
      )}

      {/* Featured Ad Approval Notification */}
      {featuredNotif && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 px-5 py-3.5 rounded-2xl shadow-xl w-[90%] max-w-sm"
          style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK }}>
          <Star size={20} />
          <div className="flex-1">
            <p className="font-black text-sm">{featuredNotif}</p>
            <p className="text-xs opacity-75">إعلانك يظهر الآن للزوار كإعلان مميز</p>
          </div>
          <button onClick={() => setFeaturedNotif(null)} className="shrink-0">
            <X size={18} />
          </button>
        </div>
      )}

      {/* ─── CliQ Payment Modal (paid ads) ─── */}
      {paymentModal && (
        <div className="fixed inset-0 z-50 flex items-end justify-center p-4"
          style={{ background: "rgba(0,0,0,0.75)" }}>
          <div className="w-full max-w-sm rounded-3xl flex flex-col gap-5 p-6" dir="rtl"
            style={{ background: G_DARK, border: `2px solid ${AU_DEEP}`, boxShadow: "0 -20px 60px rgba(0,0,0,0.6)" }}>
            <div className="text-center">
              <p className="font-black text-lg" style={{ color: AU_TEXT }}>💳 تعليمات الدفع</p>
              <p className="text-xs mt-1" style={{ color: CREAM_D }}>أتمّ الدفع عبر CliQ وأبلغ الإدارة لتفعيل إعلانك المميز</p>
            </div>

            <div className="rounded-2xl p-4 flex flex-col gap-3"
              style={{ background: "rgba(184,145,42,0.13)", border: `1.5px solid ${AU_DEEP}99` }}>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold" style={{ color: CREAM_D }}>الباقة</span>
                <span className="text-sm font-black" style={{ color: AU_BRT }}>{paymentModal.plan.label.replace("إعلان مميز — ","")}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold" style={{ color: CREAM_D }}>المبلغ</span>
                <span className="text-base font-black" style={{ color: AU_BRT }}>{paymentModal.plan.price} دينار أردني</span>
              </div>
              <div className="h-px" style={{ background: `${AU_DEEP}44` }} />
              <div className="flex items-center gap-2">
                <span style={{ color: AU_TEXT }}>💳</span>
                <div className="flex flex-col gap-0.5">
                  <span className="text-xs" style={{ color: CREAM_D }}>الدفع عبر</span>
                  <span className="font-black text-sm" style={{ color: CREAM }}>CliQ</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span style={{ color: AU_TEXT }}>🔑</span>
                <div className="flex flex-col gap-0.5">
                  <span className="text-xs" style={{ color: CREAM_D }}>الاسم المستعار</span>
                  <span className="font-black text-sm" dir="ltr" style={{ color: AU_BRT }}>Yousefsmir</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span style={{ color: AU_TEXT }}>🏦</span>
                <div className="flex flex-col gap-0.5">
                  <span className="text-xs" style={{ color: CREAM_D }}>البنك</span>
                  <span className="font-black text-sm" style={{ color: CREAM }}>البنك العربي الإسلامي</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span style={{ color: AU_TEXT }}>👤</span>
                <div className="flex flex-col gap-0.5">
                  <span className="text-xs" style={{ color: CREAM_D }}>اسم المستفيد</span>
                  <span className="font-black text-sm" dir="ltr" style={{ color: CREAM }}>Yousef musa Yousef sameera</span>
                </div>
              </div>
              <div className="h-px" style={{ background: `${AU_DEEP}44` }} />
              <div className="flex items-center gap-2">
                <span style={{ color: AU_TEXT }}>📋</span>
                <div className="flex flex-col gap-0.5">
                  <span className="text-xs" style={{ color: CREAM_D }}>رقم البطاقة (أذكره عند التحويل)</span>
                  <span className="font-black text-lg" dir="ltr" style={{ color: AU_TEXT }}>
                    {paymentModal.cardNum ? `#${paymentModal.cardNum}` : paymentModal.refId}
                  </span>
                </div>
              </div>
            </div>

            <p className="text-xs text-center" style={{ color: CREAM_D }}>
              بعد إرسال الدفعة، اضغط "تأكيد الدفع" وسيصلنا إشعار عبر الواتساب
            </p>

            <a
              href={`https://api.whatsapp.com/send?phone=962798561011&text=${encodeURIComponent(
                `مرحباً، قمت بتحويل ${paymentModal.plan.price} دينار عبر CliQ لتفعيل الإعلان المميز\n` +
                `الباقة: ${paymentModal.plan.label}\n` +
                `رقم البطاقة: ${paymentModal.cardNum ? `#${paymentModal.cardNum}` : paymentModal.refId}`
              )}`}
              target="_blank" rel="noopener noreferrer"
              onClick={() => setPaymentModal(null)}
              className="flex items-center justify-center gap-2 py-3.5 rounded-2xl font-black text-base active:scale-95"
              style={{ background: "#25D366", color: "#fff" }}>
              <Phone size={18} /> تأكيد الدفع عبر الواتساب
            </a>

            <button onClick={() => setPaymentModal(null)}
              className="py-2 rounded-xl text-sm font-bold active:scale-95"
              style={{ background: "rgba(255,255,255,0.07)", color: CREAM_D }}>
              سأدفع لاحقاً
            </button>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="w-full flex items-center justify-between px-4 pt-6 pb-4">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ background: `linear-gradient(135deg,${CO_BLUE},${CO_BLUE2})` }}>
            <Building2 size={22} style={{ color: "#fff" }} />
          </div>
          <div>
            <p className="font-black text-base leading-none" style={{ color: CO_LBLUE }}>{companyProfile.name}</p>
            <p className="text-xs mt-0.5" style={{ color: CREAM_D }}>شركة إسكان</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => { setShowMyAds(true); loadMyAds(); }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl font-bold text-sm active:scale-95"
            style={{ background: "rgba(255,255,255,0.1)", color: CREAM, border: BORDER }}>
            <FileText size={14} /> إعلاناتي
          </button>
          <button onClick={onBack}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl font-bold text-sm active:scale-95"
            style={{ background: "rgba(255,255,255,0.08)", color: CREAM_D }}>
            <LogOut size={13} /> خروج
          </button>
        </div>
      </div>

      {/* ─── Mode Tabs ─── */}
      <div className="w-full max-w-sm px-4 mb-1">
        <div className="flex rounded-2xl overflow-hidden" style={{ border: BORDER }}>
          {(["free","paid"] as const).map(mode => (
            <button key={mode} onClick={() => setAdMode(mode)}
              className="flex-1 flex items-center justify-center gap-2 py-3 font-black text-sm transition-all active:scale-95"
              style={{
                background: adMode === mode
                  ? (mode === "paid" ? `linear-gradient(135deg,${AU_DEEP},${AU_BRT})` : `linear-gradient(135deg,${G_DARK},${G_MID})`)
                  : "rgba(255,255,255,0.05)",
                color: adMode === mode ? (mode === "paid" ? G_DARK : AU_TEXT) : CREAM_D,
              }}>
              {mode === "free" ? <><Gift size={15} /> إعلانات مجانية</> : <><Star size={15} /> إعلانات مدفوعة</>}
            </button>
          ))}
        </div>
      </div>

      {/* ─── Paid: Plan selector ─── */}
      {adMode === "paid" && (
        <div className="w-full max-w-sm px-4 flex flex-col gap-3 mb-2">
          <p className="font-black text-sm" style={{ color: AU_TEXT }}>اختر باقة الإعلان المميز</p>
          <div className="grid grid-cols-2 gap-2">
            {PLANS.map(plan => (
              <button key={plan.days} onClick={() => setSelectedPlan(plan)}
                className="rounded-2xl p-3 flex flex-col items-center gap-1 transition-all active:scale-95"
                style={{
                  border: selectedPlan?.days === plan.days ? `2px solid ${AU_BRT}` : `1px solid ${AU_DEEP}55`,
                  background: selectedPlan?.days === plan.days ? `rgba(201,162,39,0.18)` : "rgba(255,255,255,0.05)",
                }}>
                <span className="font-black text-xl" style={{ color: AU_BRT }}>{plan.price}</span>
                <span className="text-xs font-bold" style={{ color: AU_TEXT }}>دينار</span>
                <span className="text-xs text-center" style={{ color: CREAM_D, lineHeight: 1.3 }}>{plan.label.replace("إعلان مميز — ","")}</span>
                {selectedPlan?.days === plan.days && (
                  <div className="mt-1 px-2 py-0.5 rounded-full text-xs font-black" style={{ background: AU_BRT, color: G_DARK }}>✓ محدد</div>
                )}
              </button>
            ))}
          </div>
          {selectedPlan && (
            <p className="text-xs text-center" style={{ color: CREAM_D }}>
              ✅ اخترت <strong style={{ color: AU_BRT }}>{selectedPlan.label.replace("إعلان مميز — ","")}</strong> — أكمل بيانات الإعلان ثم اضغط "نشر الإعلان المميز" لتصلك تعليمات الدفع
            </p>
          )}
        </div>
      )}

      <div className="w-full max-w-sm px-4 flex flex-col gap-5" key={formKey}>

        {/* ─── Section 1: Required Info ─── */}
        <div className="rounded-2xl overflow-hidden" style={{ border: `2px solid ${AU_DEEP}88` }}>

          {/* Region */}
          <div className="flex items-center gap-2 px-4 py-3.5 border-b" style={{ borderColor: `${AU_DEEP}33` }}>
            <MapPin size={16} style={{ color: AU_TEXT, flexShrink: 0 }} />
            <input value={region} onChange={e => {
              setRegion(e.target.value);
              if (!projectTitle || projectTitle === region) setProjectTitle(e.target.value);
            }}
              placeholder="موقع / منطقة المشروع ✱" dir="rtl"
              className="flex-1 bg-transparent outline-none text-base font-semibold"
              style={{ color: CREAM, fontFamily: FONT }} />
          </div>

          {/* Owner name */}
          <div className="flex items-center gap-2 px-4 py-3.5 border-b" style={{ borderColor: `${AU_DEEP}33` }}>
            <User size={16} style={{ color: AU_TEXT, flexShrink: 0 }} />
            <input value={ownerName} onChange={e => setOwnerName(e.target.value)}
              placeholder="اسم صاحب المشروع ✱" dir="rtl"
              className="flex-1 bg-transparent outline-none text-base"
              style={{ color: CREAM, fontFamily: FONT }} />
          </div>

          {/* Owner phone */}
          <div className="flex items-center gap-2 px-4 py-3.5 border-b" style={{ borderColor: `${AU_DEEP}33` }}>
            <Phone size={15} style={{ color: AU_TEXT, flexShrink: 0 }} />
            <input value={ownerPhone} onChange={e => setOwnerPhone(normalizeNums(e.target.value))}
              placeholder="رقم هاتف صاحب المشروع ✱" dir="ltr" type="tel"
              className="flex-1 bg-transparent outline-none text-base"
              style={{ color: CREAM, fontFamily: FONT }} />
          </div>

          {/* Location URL — required */}
          <div className="flex items-center gap-2 px-4 py-3.5">
            <MapPin size={15} style={{ color: AU_TEXT, flexShrink: 0 }} />
            <input ref={locUrlRef} value={locUrl} onChange={e => setLocUrl(e.target.value)}
              placeholder="رابط الموقع على Google Maps ✱" dir="ltr"
              className="flex-1 bg-transparent outline-none text-sm"
              style={{ color: CREAM, fontFamily: FONT }} />
          </div>
        </div>

        {/* ─── Section 2: Card Content ─── */}
        <div className="rounded-2xl overflow-hidden" style={{ border: BORDER }}>
          <div className="px-4 py-2.5"
            style={{ background: `linear-gradient(90deg,${G_DARK},${G_MID})` }}>
            <span className="font-black text-sm" style={{ color: AU_TEXT }}>بيانات البطاقة العقارية</span>
          </div>

          {/* Project title */}
          <div className="flex items-center gap-2 px-4 py-3.5 border-b" style={{ borderColor: `${AU_DEEP}33` }}>
            <Building2 size={16} style={{ color: AU_TEXT, flexShrink: 0 }} />
            <input value={projectTitle} onChange={e => setProjectTitle(e.target.value)}
              placeholder="اسم المشروع (اختياري — سيستخدم الموقع افتراضياً)" dir="rtl"
              className="flex-1 bg-transparent outline-none text-base font-semibold"
              style={{ color: CREAM, fontFamily: FONT }} />
          </div>

          {/* Floors table */}
          <div className="px-2 py-3">
            <table className="w-full border-collapse" style={{ tableLayout: "fixed" }}>
              <colgroup>
                <col style={{ width: "45%" }} />
                <col style={{ width: "27.5%" }} />
                <col style={{ width: "27.5%" }} />
              </colgroup>
              <thead>
                <tr style={{ background: `linear-gradient(90deg,${G_DARK},${G_MID})` }}>
                  {["الطابق / الوحدة","المساحة","السعر"].map(h => (
                    <th key={h} className="py-2.5 px-2 text-right font-black text-sm"
                      style={{ color: AU_BRT, border: BORDER }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {floors.map((f, fi) => (
                  <tr key={f.id} style={{ background: fi % 2 === 0 ? "rgba(180,145,42,0.1)" : "rgba(26,92,42,0.4)" }}>
                    <td style={{ padding: "5px 6px", border: BORDER }}>
                      <div className="flex items-center gap-1">
                        <input value={f.name} onChange={e => setFloorF(f.id, "name", e.target.value)}
                          dir="rtl" className="flex-1 min-w-0 bg-transparent outline-none text-right text-sm font-bold"
                          style={{ color: CREAM, fontFamily: FONT }} />
                        <button onClick={() => delFloor(f.id)} className="shrink-0 text-red-400 active:scale-90">
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </td>
                    <td style={{ padding: "5px 3px", border: BORDER }}>
                      <div className="flex items-center justify-center gap-0.5">
                        <input value={f.area.replace(/\s*م²\s*$/,"")}
                          onChange={e => setFloorF(f.id, "area", (e.target.value.trim() || "") + " م²")}
                          onKeyDown={e => { if (e.key==="Enter") { e.preventDefault(); document.querySelector<HTMLInputElement>(`[data-coprice="${f.id}"]`)?.focus(); } }}
                          data-coarea={f.id}
                          placeholder="---" dir="ltr"
                          className="bg-transparent outline-none text-center text-sm font-black w-0 flex-1"
                          style={{ color: CREAM, fontFamily: FONT }} />
                        <span className="text-xs font-bold shrink-0" style={{ color: AU_TEXT }}>م²</span>
                      </div>
                    </td>
                    <td style={{ padding: "5px 3px", border: BORDER }}>
                      <div className="flex items-center justify-center gap-0.5">
                        <input value={f.price.replace(/\s*ألف\s*$/,"")}
                          onChange={e => setFloorF(f.id, "price", (e.target.value.trim() || "") + " ألف")}
                          onKeyDown={e => { if (e.key==="Enter") { e.preventDefault(); const nx = floors[fi+1]; if (nx) document.querySelector<HTMLInputElement>(`[data-coarea="${nx.id}"]`)?.focus(); } }}
                          data-coprice={f.id}
                          placeholder="---" dir="ltr"
                          className="bg-transparent outline-none text-center text-sm font-black w-0 flex-1"
                          style={{ color: "#fff", fontFamily: FONT }} />
                        <span className="text-xs font-bold shrink-0" style={{ color: AU_TEXT }}>ألف</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <button onClick={addFloor}
              className="mt-3 w-full py-2.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 active:scale-95"
              style={{ background: `rgba(201,162,39,0.15)`, color: AU_TEXT, border: `1px dashed ${AU_DEEP}` }}>
              <Plus size={16} /> إضافة طابق / وحدة
            </button>
          </div>
        </div>

        {/* ─── Description ─── */}
        <div className="rounded-2xl overflow-hidden" style={{ border: BORDER }}>
          <div className="px-4 py-2.5 flex items-center justify-between"
            style={{ background: `linear-gradient(90deg,${G_DARK},${G_MID})` }}>
            <span className="font-black text-sm" style={{ color: AU_TEXT }}>المواصفات والتفاصيل</span>
            <span className="text-xs" style={{ color: description.length > 450 ? "#fbbf24" : CREAM_D }}>
              {description.length} / 500
            </span>
          </div>
          <div className="p-3">
            <textarea value={description} onChange={e => { if (e.target.value.length <= 500) setDescription(e.target.value); }}
              rows={4} placeholder="اكتب مواصفات المشروع وتفاصيله هنا..." dir="rtl"
              className="w-full bg-transparent outline-none resize-none text-sm leading-relaxed"
              style={{ color: CREAM, fontFamily: FONT }} />
          </div>
        </div>

        {/* ─── Photos / Videos ─── */}
        <div className="rounded-2xl overflow-hidden" style={{ border: BORDER }}>
          <div className="px-4 py-2.5 flex items-center gap-2"
            style={{ background: `linear-gradient(90deg,${G_DARK},${G_MID})` }}>
            <Camera size={15} style={{ color: AU_TEXT }} />
            <span className="font-black text-sm" style={{ color: AU_TEXT }}>صور وفيديوهات المشروع</span>
          </div>
          <div className="p-3 flex flex-col gap-3">
            <label className="w-full py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 active:scale-95 cursor-pointer"
              style={{ background: "rgba(201,162,39,0.15)", color: AU_TEXT, border: `1px dashed ${AU_DEEP}` }}>
              <input type="file" multiple accept="image/*,video/*" className="hidden"
                onChange={e => handleUpload(e.target.files)} disabled={uploading} />
              {uploading ? "جاري الرفع..." : "📎 اختر صوراً أو فيديوهات"}
            </label>
            {photos.length > 0 && (
              <p className="text-xs text-center" style={{ color: CREAM_D }}>✓ تم رفع {photos.length} ملف</p>
            )}
          </div>
        </div>

        {/* Error */}
        {submitErr && (
          <div className="rounded-xl px-4 py-3 text-sm text-center" style={{ background: "rgba(239,68,68,0.15)", color: "#f87171", border: "1px solid #f8717133" }}>
            {submitErr}
          </div>
        )}

        {/* Submit */}
        <button onClick={submit} disabled={submitting}
          className="w-full py-4 rounded-2xl font-black text-lg flex items-center justify-center gap-3 active:scale-95 disabled:opacity-60 shadow-2xl"
          style={{ background: adMode === "paid" ? `linear-gradient(135deg,${AU_DEEP},${AU_BRT})` : `linear-gradient(135deg,${G_DARK},${G_MID})`, color: adMode === "paid" ? G_DARK : AU_TEXT }}>
          {adMode === "paid" ? <Star size={20} /> : <Send size={20} />}
          {submitting ? "جاري النشر..." : adMode === "paid" ? "نشر الإعلان المميز" : "نشر الإعلان"}
        </button>
      </div>

      {/* ─── My Ads overlay ─── */}
      {showMyAds && (
        <div className="fixed inset-0 z-50 flex flex-col" dir="rtl"
          style={{ background: `linear-gradient(145deg,${G_DARK},${G_MID})` }}>
          <div className="flex items-center gap-3 px-4 pt-6 pb-4">
            <button onClick={() => setShowMyAds(false)}
              className="p-2 rounded-full active:scale-90" style={{ background: "rgba(255,255,255,0.1)", color: CREAM }}>
              <ChevronRight size={22} />
            </button>
            <Building2 size={18} style={{ color: AU_TEXT }} />
            <h2 className="font-black text-lg" style={{ color: AU_TEXT }}>إعلانات شركتي</h2>
          </div>
          <div className="flex-1 overflow-y-auto px-4 pb-10 space-y-4">
            {myAdsLoading && <p className="text-center mt-10 text-sm" style={{ color: CREAM_D }}>جاري التحميل...</p>}
            {!myAdsLoading && myAds.length === 0 && (
              <div className="text-center mt-20">
                <FileText size={48} className="mx-auto mb-3 opacity-40" style={{ color: CREAM_D }} />
                <p style={{ color: CREAM_D }}>لا توجد إعلانات بعد</p>
              </div>
            )}
            {myAds.map(s => (
              <div key={s.id} className="rounded-2xl p-4 space-y-2"
                style={{ background: "rgba(255,255,255,0.07)", border: s.status === "pending" ? `2px solid ${AU_BRT}88` : s.status === "approved" ? "2px solid #22c55e66" : BORDER }}>
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <span className="text-sm font-black px-2 py-1 rounded-lg" style={{ background: `${AU_DEEP}44`, color: AU_TEXT }}>
                    {s.cardData?.projectName || s.region || "مشروع"}
                  </span>
                  <span className="text-xs px-2 py-1 rounded-lg" style={{
                    background: s.status === "approved" ? "rgba(34,197,94,0.15)" : s.status === "pending" ? "rgba(251,191,36,0.15)" : "rgba(239,68,68,0.15)",
                    color: s.status === "approved" ? "#22c55e" : s.status === "pending" ? "#fbbf24" : "#f87171",
                  }}>
                    {s.status === "approved" ? "✅ معتمد" : s.status === "pending" ? "⏳ قيد المراجعة" : "❌ مرفوض"}
                  </span>
                </div>
                {s.region && <p className="text-sm" style={{ color: CREAM }}>📍 {s.region}</p>}
                {s.description && <p className="text-xs leading-relaxed" style={{ color: CREAM_D }}>{s.description}</p>}
                <div className="flex gap-2 mt-1">
                  <button onClick={() => openEdit(s)}
                    className="flex-1 flex items-center justify-center gap-2 py-2 rounded-xl font-bold text-sm active:scale-95"
                    style={{ background: "rgba(184,145,42,0.12)", color: AU_TEXT, border: `1px solid ${AU_DEEP}44` }}>
                    <Pencil size={14} /> تعديل
                  </button>
                  <button onClick={async () => {
                    if (!confirm("حذف هذا الإعلان؟")) return;
                    setDeletingAd(s.id);
                    try { await deleteSubmissionApi(s.id); setMyAds(prev => prev.filter(x => x.id !== s.id)); }
                    catch { alert("تعذّر الحذف"); }
                    finally { setDeletingAd(null); }
                  }} disabled={deletingAd === s.id}
                    className="flex-1 flex items-center justify-center gap-2 py-2 rounded-xl font-bold text-sm active:scale-95 disabled:opacity-50"
                    style={{ background: "rgba(239,68,68,0.12)", color: "#f87171", border: "1px solid #f8717133" }}>
                    <Trash2 size={14} /> {deletingAd === s.id ? "جاري الحذف..." : "حذف"}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ─── Edit Ad Full-Form Overlay ─── */}
      {editingAd && (() => {
        const lines = (editingAd.ownerContact ?? "").split("\n");
        const parse = (pfx: string) => lines.find(l => l.startsWith(pfx))?.slice(pfx.length).trim() ?? "";
        const eRegion = editingAd.region;
        const eOwnerName  = parse("اسم: ");
        const eOwnerPhone = parse("هاتف: ");
        const eLocUrl     = parse("موقع: ");
        const setOC = (field: "اسم" | "هاتف" | "موقع", val: string) => {
          const updated = (editingAd.ownerContact ?? "").split("\n")
            .map(l => l.startsWith(`${field}: `) ? `${field}: ${val}` : l).join("\n");
          setEditingAd(a => a ? { ...a, ownerContact: updated } : a);
        };
        return (
          <div className="fixed inset-0 z-[60] flex flex-col overflow-y-auto" dir="rtl"
            style={{ background: `linear-gradient(145deg,${G_DARK},${G_MID})` }}>
            {/* Header */}
            <div className="sticky top-0 z-10 flex items-center gap-3 px-4 pt-6 pb-4"
              style={{ background: G_DARK, borderBottom: `2px solid ${AU_DEEP}` }}>
              <button onClick={() => setEditingAd(null)}
                className="p-2 rounded-full active:scale-90" style={{ background: "rgba(255,255,255,0.1)", color: CREAM }}>
                <X size={20} />
              </button>
              <Pencil size={16} style={{ color: AU_TEXT }} />
              <span className="font-black text-base" style={{ color: AU_TEXT }}>تعديل الإعلان</span>
            </div>

            <div className="px-4 py-4 flex flex-col gap-5 pb-20">
              {/* Secret info */}
              <div className="rounded-2xl overflow-hidden" style={{ border: `2px solid ${AU_DEEP}88` }}>
                <div className="flex flex-col divide-y" style={{ borderColor: `${AU_DEEP}33` }}>
                  <div className="flex items-center gap-2 px-4 py-3">
                    <MapPin size={15} style={{ color: AU_TEXT }} />
                    <input value={editingAd.region}
                      onChange={e => setEditingAd(a => a ? { ...a, region: e.target.value } : a)}
                      placeholder="موقع المشروع ✱" dir="rtl"
                      className="flex-1 bg-transparent outline-none text-base"
                      style={{ color: CREAM, fontFamily: FONT }} />
                  </div>
                  <div className="flex items-center gap-2 px-4 py-3">
                    <User size={15} style={{ color: AU_TEXT }} />
                    <input value={eOwnerName} onChange={e => setOC("اسم", e.target.value)}
                      placeholder="اسم صاحب المشروع ✱" dir="rtl"
                      className="flex-1 bg-transparent outline-none text-base"
                      style={{ color: CREAM, fontFamily: FONT }} />
                  </div>
                  <div className="flex items-center gap-2 px-4 py-3">
                    <Phone size={14} style={{ color: AU_TEXT }} />
                    <input value={eOwnerPhone} onChange={e => setOC("هاتف", normalizeNums(e.target.value))}
                      placeholder="رقم هاتف صاحب المشروع ✱" dir="ltr" type="tel"
                      className="flex-1 bg-transparent outline-none text-base"
                      style={{ color: CREAM, fontFamily: FONT }} />
                  </div>
                  <div className="flex items-center gap-2 px-4 py-3">
                    <MapPin size={14} style={{ color: AU_TEXT }} />
                    <input value={eLocUrl} onChange={e => setOC("موقع", e.target.value)}
                      placeholder="رابط Google Maps (اختياري)" dir="ltr"
                      className="flex-1 bg-transparent outline-none text-sm"
                      style={{ color: CREAM, fontFamily: FONT }} />
                  </div>
                </div>
              </div>

              {/* Floor table edit */}
              <div className="rounded-2xl overflow-hidden" style={{ border: BORDER }}>
                <div className="px-4 py-2.5" style={{ background: `linear-gradient(90deg,${G_DARK},${G_MID})` }}>
                  <span className="font-black text-sm" style={{ color: AU_TEXT }}>جدول الطوابق</span>
                </div>
                <div className="overflow-x-auto px-2 py-3">
                  <table className="w-full border-collapse text-base">
                    <thead>
                      <tr style={{ background: `linear-gradient(90deg,${G_DARK},${G_MID})` }}>
                        {["الطابق","المساحة","السعر"].map(h => (
                          <th key={h} className="py-2 px-2 text-right font-black text-sm" style={{ color: AU_BRT, border: BORDER }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {editFloors.map((f, fi) => (
                        <tr key={f.id} style={{ background: fi%2===0 ? "rgba(180,145,42,0.1)" : "rgba(26,92,42,0.4)" }}>
                          <td style={{ padding: "5px 7px", border: BORDER }}>
                            <div className="flex items-center gap-1">
                              <input value={f.name} onChange={e => setEFloor(f.id,"name",e.target.value)}
                                dir="rtl" className="flex-1 bg-transparent outline-none text-sm font-bold"
                                style={{ color: CREAM, fontFamily: FONT }} />
                              <button onClick={() => delEFloor(f.id)} className="text-red-400"><Trash2 size={13}/></button>
                            </div>
                          </td>
                          <td style={{ padding: "5px 3px", border: BORDER }}>
                            <input value={f.area.replace(/\s*م²\s*$/,"")}
                              onChange={e => setEFloor(f.id,"area",(e.target.value.trim()||"")+" م²")}
                              placeholder="م²" dir="ltr"
                              className="w-14 bg-transparent outline-none text-center text-sm font-bold"
                              style={{ color: CREAM, fontFamily: FONT }} />
                          </td>
                          <td style={{ padding: "5px 3px", border: BORDER }}>
                            <input value={f.price.replace(/\s*ألف\s*$/,"")}
                              onChange={e => setEFloor(f.id,"price",(e.target.value.trim()||"")+" ألف")}
                              placeholder="ألف" dir="ltr"
                              className="w-12 bg-transparent outline-none text-center text-sm font-bold"
                              style={{ color: "#fff", fontFamily: FONT }} />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  <button onClick={addEFloor}
                    className="mt-2 w-full py-2 rounded-xl font-bold text-sm flex items-center justify-center gap-2 active:scale-95"
                    style={{ background: "rgba(201,162,39,0.15)", color: AU_TEXT, border: `1px dashed ${AU_DEEP}` }}>
                    <Plus size={15}/> إضافة طابق
                  </button>
                </div>
              </div>

              {/* Description edit */}
              <div className="rounded-2xl overflow-hidden" style={{ border: BORDER }}>
                <div className="px-4 py-2.5 flex items-center justify-between"
                  style={{ background: `linear-gradient(90deg,${G_DARK},${G_MID})` }}>
                  <span className="font-black text-sm" style={{ color: AU_TEXT }}>المواصفات والتفاصيل</span>
                  <span className="text-xs" style={{ color: CREAM_D }}>{(editingAd.description||"").length}/500</span>
                </div>
                <div className="p-3">
                  <textarea value={editingAd.description || ""}
                    onChange={e => { if (e.target.value.length<=500) setEditingAd(a => a ? { ...a, description: e.target.value } : a); }}
                    rows={4} placeholder="المواصفات والتفاصيل..." dir="rtl"
                    className="w-full bg-transparent outline-none resize-none text-sm"
                    style={{ color: CREAM, fontFamily: FONT }} />
                </div>
              </div>

              {/* Photos in edit */}
              <div className="rounded-2xl overflow-hidden" style={{ border: BORDER }}>
                <div className="px-4 py-2.5 flex items-center gap-2"
                  style={{ background: `linear-gradient(90deg,${G_DARK},${G_MID})` }}>
                  <Camera size={14} style={{ color: AU_TEXT }}/>
                  <span className="font-black text-sm" style={{ color: AU_TEXT }}>الصور والفيديوهات</span>
                </div>
                <div className="p-3 flex flex-col gap-2">
                  {editPhotosLoading && <p className="text-xs text-center" style={{ color: CREAM_D }}>جاري تحميل الصور...</p>}
                  {!editPhotosLoading && editPhotos.length === 0 && (
                    <p className="text-xs text-center" style={{ color: CREAM_D }}>لا توجد صور مرفقة</p>
                  )}
                  {editPhotos.length > 0 && (
                    <div className="grid grid-cols-3 gap-2">
                      {editPhotos.map(ph => {
                        const url = photoUrl(ph);
                        return (
                          <div key={ph.id} className="relative aspect-square rounded-lg overflow-hidden"
                            style={{ background: "rgba(0,0,0,0.3)" }}>
                            <img src={url} alt="" className="w-full h-full object-cover" />
                            <button
                              onClick={async () => {
                                if (!confirm("حذف هذه الصورة؟")) return;
                                setDeletingPhoto(ph.id);
                                try {
                                  await deletePhotoApi(`sub_${editingAd!.id}`, ph.id);
                                  setEditPhotos(prev => prev.filter(p => p.id !== ph.id));
                                } catch { alert("تعذّر حذف الصورة"); }
                                finally { setDeletingPhoto(null); }
                              }}
                              disabled={deletingPhoto === ph.id}
                              className="absolute top-1 left-1 w-6 h-6 rounded-full flex items-center justify-center active:scale-90 disabled:opacity-50"
                              style={{ background: "rgba(239,68,68,0.85)", color: "#fff" }}>
                              <X size={12}/>
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}
                  {/* Upload more in edit */}
                  <label className="w-full py-2.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 active:scale-95 cursor-pointer mt-1"
                    style={{ background: "rgba(201,162,39,0.15)", color: AU_TEXT, border: `1px dashed ${AU_DEEP}` }}>
                    <input type="file" multiple accept="image/*,video/*" className="hidden"
                      onChange={async e => {
                        const files = e.target.files;
                        if (!files?.length) return;
                        for (const file of Array.from(files)) {
                          try {
                            const { uploadURL, objectPath } = await requestUploadUrl(file);
                            await fetch(uploadURL, { method: "PUT", body: file, headers: { "Content-Type": file.type } });
                            const p = await postPhoto(`sub_${editingAd!.id}`, objectPath);
                            setEditPhotos(prev => [...prev, p]);
                          } catch { alert("تعذّر رفع الصورة"); }
                        }
                      }} />
                    📎 رفع صور إضافية
                  </label>
                </div>
              </div>

              <button onClick={saveEdit} disabled={editSaving}
                className="w-full py-3.5 rounded-2xl font-black text-base active:scale-95 disabled:opacity-60"
                style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK }}>
                {editSaving ? "جاري الحفظ..." : "حفظ التعديلات"}
              </button>
            </div>
          </div>
        );
      })()}
    </div>
  );
}

/* ─── Submit Form (Guest property submission) ─────────────────────── */
let _coId = 100;
function SubmitForm({ onClose, guestProfile }: { onClose: () => void; guestProfile?: GuestProfile }) {
  const [submissionId]                = useState(() => `${Date.now()}`);
  const photoCardId                   = `sub_${submissionId}`;

  const [ownerType, setOwnerType]     = useState("شخصي");
  const [propertyType, setPropertyType] = useState("شقة");
  const [region, setRegion]           = useState("");
  const [price, setPrice]             = useState("");
  const [floor, setFloor]             = useState("");
  const [area, setArea]               = useState("");
  const [contactName, setContactName] = useState(guestProfile?.name ?? "");
  const [phone, setPhone]             = useState(guestProfile?.phone ?? "");
  const [description, setDescription] = useState("");
  const [agreed, setAgreed]           = useState(false);
  const [sent, setSent]               = useState(false);
  const [sending, setSending]         = useState(false);
  const [sendErr, setSendErr]         = useState("");
  // Company mode: multiple units table — 5 pre-filled floors
  const [coUnits, setCoUnits] = useState<Floor[]>([
    { id: _coId++, name: "طابق التسوية", area: "", price: "" },
    { id: _coId++, name: "أرضية",        area: "", price: "" },
    { id: _coId++, name: "الأول",        area: "", price: "" },
    { id: _coId++, name: "الثاني",       area: "", price: "" },
    { id: _coId++, name: "الثالث",       area: "", price: "" },
  ]);
  const addCoUnit  = () => setCoUnits(u => [...u, { id: _coId++, name: `شقة ${u.length + 1}`, area: "", price: "" }]);
  const delCoUnit  = (id: number) => setCoUnits(u => u.filter(r => r.id !== id));
  const setCoField = (id: number, k: keyof Floor, v: string) =>
    setCoUnits(u => u.map(r => r.id === id ? { ...r, [k]: v } : r));

  const PROPERTY_TYPES = ["شقة", "أرض", "فيلا", "محل تجاري", "مستودع", "عمارة"];
  const isCompany = ownerType === "شركة";

  const handleSend = async () => {
    if (!region || !contactName || !phone || !agreed) return;
    if (!isCompany && !price) return;

    setSendErr("");
    setSending(true);

    let cardData: CardData | undefined;
    if (isCompany) {
      cardData = {
        ...DEFAULT_DATA,
        projectName: `${propertyType} — ${region}`,
        phone: DEFAULT_DATA.phone,
        note1: DEFAULT_DATA.note1,
        description: description || undefined,
        floors: coUnits.map(u => ({ ...u })),
      };
    }

    const sub: Submission = {
      id: submissionId, submittedAt: Date.now(), ownerType, propertyType,
      region, price: isCompany ? "" : price,
      floor: isCompany ? "" : floor,
      area: isCompany ? "" : area,
      contactName, phone, description,
      status: "pending", submittedBy: "guest",
      ...(cardData ? { cardData } : {}),
    };
    try {
      await postSubmission(sub);
      setSent(true);
    } catch {
      setSendErr("تعذّر إرسال الطلب، حاول مجدداً");
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end"
      style={{ background: "rgba(0,0,0,0.6)" }}
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="rounded-t-3xl flex flex-col max-h-[90vh]" dir="rtl"
        style={{ background: `linear-gradient(160deg,${G_DARK},${G_MID})`, border: `2px solid ${AU_DEEP}`, borderBottom: "none" }}>
        <div className="flex items-center justify-between px-5 pt-5 pb-3">
          <h2 className="font-black text-lg" style={{ color: AU_TEXT }}>اعرض عقارك</h2>
          <button onClick={onClose}><X size={22} style={{ color: CREAM_D }} /></button>
        </div>

        {sent ? (
          <div className="flex flex-col items-center justify-center gap-4 py-12 px-6">
            <div className="w-16 h-16 rounded-full flex items-center justify-center"
              style={{ background: `${AU_DEEP}33`, border: `2px solid ${AU_BRT}` }}>
              <Check size={32} style={{ color: AU_BRT }} />
            </div>
            <p className="font-black text-lg text-center" style={{ color: AU_TEXT }}>
              تم تقديم طلب نشر الإعلان!
            </p>
            <div className="rounded-xl px-4 py-3 text-center"
              style={{ background: "rgba(255,255,255,0.07)", border: BORDER }}>
              <p className="text-sm leading-relaxed" style={{ color: CREAM_D }}>
                📋 سيتم مراجعة إعلانك من قِبل الإدارة
              </p>
              <p className="text-sm mt-1 font-bold" style={{ color: CREAM }}>
                وسينشر في قائمة العروض بعد الاعتماد
              </p>
            </div>
            <button onClick={onClose}
              className="mt-2 px-8 py-3 rounded-xl font-bold"
              style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK }}>
              إغلاق
            </button>
          </div>
        ) : (
          <div className="overflow-y-auto px-5 pb-8 space-y-4">
            {/* Owner type */}
            <div>
              <p className="text-sm font-bold mb-2" style={{ color: CREAM_D }}>نوع المالك</p>
              <div className="flex gap-2">
                {["شخصي", "شركة"].map(t => (
                  <button key={t} onClick={() => setOwnerType(t)}
                    className="flex-1 py-2.5 rounded-xl font-bold text-sm active:scale-95"
                    style={{ background: ownerType === t ? `linear-gradient(135deg,${AU_DEEP},${AU_BRT})` : "rgba(255,255,255,0.1)", color: ownerType === t ? G_DARK : CREAM, border: ownerType === t ? "none" : BORDER }}>
                    {t === "شخصي" ? "👤" : "🏢"} {t}
                  </button>
                ))}
              </div>
            </div>

            {/* Property type */}
            <div>
              <p className="text-sm font-bold mb-2" style={{ color: CREAM_D }}>نوع العقار</p>
              <div className="flex flex-wrap gap-2">
                {PROPERTY_TYPES.map(t => (
                  <button key={t} onClick={() => setPropertyType(t)}
                    className="px-3 py-2 rounded-xl text-sm font-bold active:scale-95"
                    style={{ background: propertyType === t ? `linear-gradient(135deg,${AU_DEEP},${AU_BRT})` : "rgba(255,255,255,0.1)", color: propertyType === t ? G_DARK : CREAM, border: propertyType === t ? "none" : BORDER }}>
                    {t}
                  </button>
                ))}
              </div>
            </div>

            {/* Region — always shown */}
            <div>
              <p className="text-sm font-bold mb-1.5" style={{ color: CREAM_D }}>📍 المنطقة *</p>
              <input value={region} onChange={e => setRegion(e.target.value)} dir="rtl"
                className="w-full rounded-xl px-4 py-3 text-base outline-none"
                style={{ background: "rgba(255,255,255,0.12)", color: CREAM, WebkitTextFillColor: CREAM, caretColor: CREAM, border: BORDER, fontFamily: FONT }} />
            </div>

            {/* Personal mode fields */}
            {!isCompany && [
              { label: "السعر *", val: price, set: setPrice, icon: "💰", hint: "" },
              ...(propertyType !== "أرض" ? [{ label: "الطابق", val: floor, set: setFloor, icon: "🏢", hint: "" }] : []),
              { label: "المساحة (م²)", val: area, set: setArea, icon: "📐", hint: "تظهر في البطاقة" },
            ].map(f => (
              <div key={f.label}>
                <div className="flex items-center justify-between mb-1.5">
                  <p className="text-sm font-bold" style={{ color: CREAM_D }}>{f.icon} {f.label}</p>
                  {f.hint && <span className="text-xs" style={{ color: AU_TEXT }}>{f.hint}</span>}
                </div>
                <input value={f.val} onChange={e => f.set(e.target.value)} dir="rtl"
                  className="w-full rounded-xl px-4 py-3 text-base outline-none"
                  style={{ background: "rgba(255,255,255,0.12)", color: CREAM, WebkitTextFillColor: CREAM, caretColor: CREAM, border: BORDER, fontFamily: FONT }} />
              </div>
            ))}

            {/* Company mode: units table */}
            {isCompany && (
              <div>
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm font-bold" style={{ color: CREAM_D }}>🏢 الوحدات العقارية</p>
                  <button onClick={addCoUnit}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold active:scale-95"
                    style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK }}>
                    <Plus size={12} /> إضافة صف
                  </button>
                </div>
                <div className="rounded-xl overflow-hidden" style={{ border: BORDER }}>
                  <table style={{ width: "100%", borderCollapse: "collapse", tableLayout: "fixed" }}>
                    <colgroup>
                      <col style={{ width: "42%" }} /><col style={{ width: "24%" }} /><col style={{ width: "24%" }} /><col style={{ width: "10%" }} />
                    </colgroup>
                    <thead>
                      <tr style={{ background: `linear-gradient(90deg,${G_DARK},${G_MID})` }}>
                        {["الطابق", "المساحة", "السعر", ""].map(h => (
                          <th key={h} style={{ padding: "8px 4px", border: BORDER, color: AU_TEXT, fontWeight: 700, fontSize: "0.8rem", textAlign: "center" }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {coUnits.map((u, i) => (
                        <tr key={u.id} style={{ background: i % 2 === 0 ? "rgba(180,145,42,0.07)" : "rgba(26,92,42,0.35)" }}>
                          {(["name", "area", "price"] as const).map(k => (
                            <td key={k} style={{ padding: "4px", border: BORDER }}>
                              <input value={u[k]} onChange={e => setCoField(u.id, k, e.target.value)}
                                dir="rtl" className="w-full bg-transparent outline-none text-center text-sm font-bold"
                                style={{ color: CREAM, fontFamily: FONT }} />
                            </td>
                          ))}
                          <td style={{ padding: "4px", border: BORDER, textAlign: "center" }}>
                            <button onClick={() => delCoUnit(u.id)} style={{ color: "#f87171" }}>
                              <Trash2 size={13} />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Common fields */}
            {[
              { label: "الاسم الكريم *", val: contactName, set: setContactName, icon: "👤", hint: "" },
              { label: "رقم هاتفك *", val: phone, set: setPhone, icon: "🔒", hint: "سري — لن يظهر في الإعلان للزوار" },
            ].map(f => (
              <div key={f.label}>
                <div className="flex items-center justify-between mb-1.5">
                  <p className="text-sm font-bold" style={{ color: CREAM_D }}>{f.icon} {f.label}</p>
                  {f.hint && <span className="text-xs" style={{ color: AU_TEXT }}>{f.hint}</span>}
                </div>
                <input value={f.val} onChange={e => f.set(e.target.value)} dir="rtl"
                  className="w-full rounded-xl px-4 py-3 text-base outline-none"
                  style={{ background: "rgba(255,255,255,0.12)", color: CREAM, WebkitTextFillColor: CREAM, caretColor: CREAM, border: BORDER, fontFamily: FONT }} />
              </div>
            ))}

            {/* Description */}
            <div>
              <p className="text-sm font-bold mb-1.5 flex justify-between" style={{ color: CREAM_D }}>
                <span>📝 وصف إضافي</span>
                <span style={{ color: description.length > 180 ? "#f87171" : CREAM_D }}>{description.length}/200</span>
              </p>
              <textarea value={description} onChange={e => setDescription(e.target.value.slice(0, 200))}
                dir="rtl" rows={4}
                className="w-full rounded-xl px-4 py-3 outline-none resize-none"
                style={{ background: "rgba(255,255,255,0.12)", color: CREAM, WebkitTextFillColor: CREAM, caretColor: CREAM, border: BORDER, fontFamily: FONT, fontSize: "0.75rem" }} />
            </div>

            {/* Photo upload section */}
            <PhotoUploadSection cardId={photoCardId} />

            {/* Commitment checkbox */}
            <button onClick={() => setAgreed(a => !a)}
              className="flex items-center gap-3 w-full text-right rounded-xl px-4 py-3 active:scale-95"
              style={{ background: agreed ? "rgba(184,145,42,0.18)" : "rgba(255,255,255,0.06)",
                border: agreed ? BORDER : `1px solid rgba(255,255,255,0.15)` }}>
              <div className="shrink-0 w-6 h-6 rounded-md flex items-center justify-center"
                style={{ background: agreed ? `linear-gradient(135deg,${AU_DEEP},${AU_BRT})` : "rgba(255,255,255,0.1)",
                  border: agreed ? "none" : `1px solid ${CREAM_D}` }}>
                {agreed && <Check size={14} style={{ color: G_DARK }} />}
              </div>
              <span className="text-sm font-bold leading-snug text-right"
                style={{ color: agreed ? AU_TEXT : CREAM_D }}>
                أتعهد بدفع عمولة المكتب عند إتمام عملية البيع
              </span>
            </button>

            <div className="rounded-xl px-4 py-3 text-center text-xs"
              style={{ background: "rgba(255,255,255,0.06)", border: `1px solid ${AU_DEEP}66` }}>
              <span style={{ color: CREAM_D }}>📋 سيتم نشر إعلانك بعد مراجعته من الإدارة</span>
            </div>

            {sendErr && (
              <p className="text-sm text-red-400 text-center bg-red-900/20 rounded-xl px-3 py-2">{sendErr}</p>
            )}
            <button onClick={handleSend}
              disabled={sending || !region || (!isCompany && !price) || !contactName || !phone || !agreed}
              className="w-full py-4 rounded-2xl font-black text-base flex items-center justify-center gap-2 active:scale-95 disabled:opacity-40"
              style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK }}>
              <Send size={18} /> {sending ? "جاري الإرسال..." : "نشر الإعلان"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

/* ─── Submissions View (Admin) ───────────────────────────────────── */
function SubmissionsView({ onClose }: { onClose: () => void }) {
  const logoDataUrl = useBase64Image(logoSrc);
  const [subs, setSubs]   = useState<Submission[]>([]);
  const [archive, setArchive] = useState<SavedCard[]>([]);
  const [loading, setLoading] = useState(true);
  const [apiErr, setApiErr]   = useState("");
  const [tab, setTab]   = useState<"pending" | "approved">("pending");
  const [viewCard, setViewCard] = useState<Submission | null>(null);
  const [selectedSubs, setSelectedSubs] = useState<Set<string>>(new Set());
  const [bulkDeleting, setBulkDeleting] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const [subList, cards] = await Promise.all([fetchSubmissions(), fetchArchive()]);
        setSubs(subList.sort((a, b) => b.submittedAt - a.submittedAt));
        setArchive(cards);
      } catch {
        setApiErr("تعذّر الاتصال بالسيرفر، حاول مجدداً");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const pending  = subs.filter(s => s.status === "pending");
  const approved = subs.filter(s => s.status === "approved");
  const displayed = tab === "pending" ? pending : approved;

  const updateStatus = async (id: string, status: Submission["status"]) => {
    let assignedCardNum: number | undefined;
    if (status === "approved") {
      const sub = subs.find(s => s.id === id);
      if (sub) {
        const archiveId = `sub_${sub.id}`;
        const alreadySaved = archive.find(c => c.id === archiveId);
        if (alreadySaved) {
          assignedCardNum = alreadySaved.cardNum;
        } else {
          const cardData = sub.cardData ?? submissionToCardData(sub);
          assignedCardNum = computeNextCardNum(archive);
          const newCard: SavedCard = {
            id:           archiveId,
            savedAt:      Date.now(),
            region:       sub.cardRegion || sub.region,
            owner:        sub.contactName || (sub.submittedBy === "guest" ? "زبون" : "موظف"),
            data:         cardData,
            cardNum:      assignedCardNum,
            guestPhone:   sub.submittedBy === "guest" && sub.phone ? sub.phone : undefined,
            ownerContact: sub.ownerContact || undefined,
            employeeId:   sub.employeeId   || undefined,
            employeeName: sub.employeeName || undefined,
          };
          try {
            await postCard(newCard);
            setArchive(prev => [...prev, newCard]);
          } catch {
            setApiErr("تعذّر حفظ البطاقة في الأرشيف");
            return;
          }
        }
      }
    }
    try {
      await patchSubmission(id, { status, ...(assignedCardNum !== undefined ? { cardNum: assignedCardNum } : {}) });
      setSubs(prev => prev.map(s =>
        s.id === id
          ? { ...s, status, ...(assignedCardNum !== undefined ? { cardNum: assignedCardNum } : {}) }
          : s
      ));
    } catch {
      setApiErr("تعذّر تحديث حالة الطلب");
    }
  };

  const del = async (id: string) => {
    if (!confirm("حذف هذا الطلب؟")) return;
    try {
      await deleteSubmissionApi(id);
      setSubs(prev => prev.filter(s => s.id !== id));
      setArchive(prev => prev.filter(c => c.id !== `sub_${id}`));
    } catch {
      setApiErr("تعذّر حذف الطلب");
    }
  };

  const delBulk = async (ids: string[]) => {
    if (!confirm(`هل أنت متأكد من حذف ${ids.length} طلب معتمد؟ لا يمكن التراجع عن هذا الإجراء.`)) return;
    setBulkDeleting(true);
    try {
      await Promise.allSettled(ids.map(id => deleteSubmissionApi(id)));
      setSubs(prev => prev.filter(s => !ids.includes(s.id)));
      setArchive(prev => prev.filter(c => !ids.map(id => `sub_${id}`).includes(c.id)));
      setSelectedSubs(new Set());
    } catch {
      setApiErr("تعذّر حذف بعض الطلبات");
    } finally {
      setBulkDeleting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col" dir="rtl"
      style={{ background: `linear-gradient(145deg,${G_DARK} 0%,${G_MID} 50%,${G_DARK} 100%)`, fontFamily: FONT }}>
      <div className="flex items-center gap-3 px-4 pt-6 pb-2">
        <button onClick={onClose} className="p-2 rounded-full active:scale-90"
          style={{ background: "rgba(255,255,255,0.1)", color: CREAM }}>
          <ChevronRight size={22} />
        </button>
        <FileText size={20} style={{ color: AU_TEXT }} />
        <h1 className="font-black text-xl" style={{ color: AU_TEXT }}>طلبات البيع</h1>
      </div>

      {loading && (
        <div className="flex-1 flex flex-col items-center justify-center gap-3">
          <div className="w-10 h-10 border-4 border-t-transparent rounded-full animate-spin"
            style={{ borderColor: `${AU_DEEP} transparent ${AU_DEEP} ${AU_DEEP}` }} />
          <p className="text-sm" style={{ color: CREAM_D }}>جاري التحميل...</p>
        </div>
      )}
      {!loading && apiErr && (
        <div className="mx-4 mt-4 rounded-xl px-4 py-3 text-center text-sm text-red-400 bg-red-900/20">{apiErr}</div>
      )}

      {/* Tabs */}
      <div className="flex gap-2 px-4 pb-3 pt-1">
        {(["pending", "approved"] as const).map(t => (
          <button key={t} onClick={() => { setTab(t); setSelectedSubs(new Set()); }}
            className="flex-1 py-2.5 rounded-xl font-bold text-sm active:scale-95"
            style={{
              background: tab === t ? `linear-gradient(135deg,${AU_DEEP},${AU_BRT})` : "rgba(255,255,255,0.08)",
              color: tab === t ? G_DARK : CREAM_D,
              border: tab === t ? "none" : BORDER,
            }}>
            {t === "pending" ? `⏳ بانتظار الموافقة (${pending.length})` : `✅ معتمد (${approved.length})`}
          </button>
        ))}
      </div>

      {/* Select-all bar — only in approved tab */}
      {tab === "approved" && approved.length > 0 && (
        <div className="flex items-center justify-between px-4 pb-2">
          <button
            onClick={() => setSelectedSubs(
              selectedSubs.size === approved.length
                ? new Set()
                : new Set(approved.map(s => s.id))
            )}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl text-sm font-bold active:scale-95"
            style={{ background: "rgba(255,255,255,0.08)", color: CREAM_D, border: BORDER }}>
            <div className="w-4 h-4 rounded border-2 flex items-center justify-center shrink-0"
              style={{
                borderColor: selectedSubs.size === approved.length ? AU_BRT : CREAM_D,
                background: selectedSubs.size === approved.length ? `${AU_BRT}33` : "transparent",
              }}>
              {selectedSubs.size === approved.length && <Check size={10} style={{ color: AU_BRT }} />}
            </div>
            {selectedSubs.size === approved.length ? "إلغاء تحديد الكل" : "تحديد الكل"}
          </button>
          {selectedSubs.size > 0 && (
            <span className="text-xs font-bold" style={{ color: AU_TEXT }}>
              {selectedSubs.size} محدد
            </span>
          )}
        </div>
      )}

      <div className="flex-1 overflow-y-auto px-4 space-y-3" style={{ paddingBottom: selectedSubs.size > 0 ? "100px" : "32px" }}>
        {displayed.length === 0 && (
          <div className="text-center mt-20" style={{ color: CREAM_D }}>
            <FileText size={48} className="mx-auto mb-3 opacity-40" />
            <p>{tab === "pending" ? "لا توجد طلبات بانتظار الموافقة" : "لا توجد طلبات معتمدة"}</p>
          </div>
        )}
        {displayed.map(s => (
          <div key={s.id} className="rounded-2xl p-4 space-y-2"
            style={{
              background: tab === "approved" && selectedSubs.has(s.id) ? "rgba(184,145,42,0.12)" : "rgba(255,255,255,0.07)",
              border: tab === "approved" && selectedSubs.has(s.id) ? `2px solid ${AU_BRT}88` : s.status === "pending" ? `2px solid ${AU_BRT}88` : BORDER,
              transition: "border-color 0.15s, background 0.15s",
            }}>
            <div className="flex items-center justify-between gap-2">
              {tab === "approved" && (
                <button
                  onClick={() => setSelectedSubs(prev => {
                    const n = new Set(prev);
                    n.has(s.id) ? n.delete(s.id) : n.add(s.id);
                    return n;
                  })}
                  className="shrink-0 w-6 h-6 rounded-md border-2 flex items-center justify-center active:scale-90"
                  style={{
                    borderColor: selectedSubs.has(s.id) ? AU_BRT : CREAM_D,
                    background: selectedSubs.has(s.id) ? `${AU_BRT}33` : "transparent",
                  }}>
                  {selectedSubs.has(s.id) && <Check size={13} style={{ color: AU_BRT }} />}
                </button>
              )}
              <div className="flex items-center gap-2 flex-wrap flex-1">
                <span className="text-sm font-black px-2 py-1 rounded-lg"
                  style={{ background: `${AU_DEEP}44`, color: AU_TEXT }}>
                  {s.cardData ? s.cardData.projectName : s.propertyType}
                </span>
                <span className="text-xs px-2 py-1 rounded-lg"
                  style={{ background: "rgba(255,255,255,0.1)", color: CREAM_D }}>
                  {s.submittedBy === "employee" ? "👤 موظف" : "🌐 زبون"} — {s.ownerType}
                </span>
              </div>
              <p className="text-xs shrink-0" style={{ color: CREAM_D }}>
                {new Date(s.submittedAt).toLocaleDateString("ar-SA")}
              </p>
            </div>

            {/* Info grid */}
            <div className="grid grid-cols-2 gap-2 text-sm">
              {(s.cardRegion || s.region) && <p style={{ color: CREAM }}><span style={{ color: CREAM_D }}>المنطقة: </span>{s.cardRegion || s.region}</p>}
              {s.price && <p style={{ color: CREAM }}><span style={{ color: CREAM_D }}>السعر: </span>{s.price}</p>}
              {s.contactName && <p style={{ color: CREAM }}><span style={{ color: CREAM_D }}>الاسم: </span>{s.contactName}</p>}
              {s.phone && <p style={{ color: CREAM }}><span style={{ color: CREAM_D }}>الهاتف: </span>{s.phone}</p>}
            </div>
            {s.ownerContact && (() => {
              const lines = s.ownerContact.split("\n");
              const parse = (prefix: string) => lines.find(l => l.startsWith(prefix))?.slice(prefix.length).trim() ?? "";
              const oName  = parse("اسم: ") || (lines.some(l => l.startsWith("اسم:")) ? "" : s.ownerContact);
              const oPhone = parse("هاتف: ");
              const oLoc   = parse("موقع: ");
              const isStructured = lines.some(l => l.startsWith("اسم:"));
              return (
                <div className="rounded-xl px-3 py-2.5 flex flex-col gap-1.5"
                  style={{ background: "rgba(184,145,42,0.15)", border: `1px solid ${AU_DEEP}88` }}>
                  <div className="flex items-center gap-1.5">
                    <Lock size={11} style={{ color: AU_TEXT }} />
                    <span className="text-xs font-bold" style={{ color: AU_TEXT }}>معلومات سرية — صاحب المشروع</span>
                  </div>
                  {isStructured ? (
                    <>
                      {oName  && <p className="text-sm" style={{ color: CREAM }}>👤 {oName}</p>}
                      {oPhone && <a href={`tel:${oPhone}`} className="text-sm" style={{ color: "#7dd3fc" }}>📞 {oPhone}</a>}
                      {oLoc   && <a href={oLoc} target="_blank" rel="noopener noreferrer" className="text-sm underline truncate" style={{ color: "#86efac" }}>📍 فتح الموقع في الخريطة</a>}
                    </>
                  ) : (
                    <p className="text-sm" style={{ color: AU_TEXT }}>{s.ownerContact}</p>
                  )}
                </div>
              );
            })()}
            {s.description && <p className="text-xs" style={{ color: CREAM_D }}>📝 {s.description}</p>}

            {/* Card preview button — always available, falls back to submissionToCardData */}
            <button onClick={() => setViewCard(s)}
              className="w-full py-2.5 rounded-xl font-bold text-sm active:scale-95 flex items-center justify-center gap-2"
              style={{ background: "rgba(201,162,39,0.15)", color: AU_TEXT, border: BORDER }}>
              <Building2 size={15} /> عرض البطاقة
            </button>

            {/* WhatsApp contact */}
            {s.phone && (
              <a href={`https://api.whatsapp.com/send?phone=962${s.phone.replace(/^0/, "")}&text=${encodeURIComponent(`أهلاً ${s.contactName}، تواصلنا معك بخصوص عقارك`)}`}
                target="_blank" rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 py-2.5 rounded-xl font-bold text-sm"
                style={{ background: "#25D366", color: "#fff" }}>
                <Phone size={15} /> {s.phone} — تواصل
              </a>
            )}

            {/* Approve / Reject */}
            {s.status === "pending" && (
              <div className="flex gap-2">
                <button onClick={() => updateStatus(s.id, "approved")}
                  className="flex-1 py-2.5 rounded-xl font-bold text-sm active:scale-95"
                  style={{ background: "rgba(34,197,94,0.2)", color: "#22c55e", border: "1px solid #22c55e44" }}>
                  ✓ موافقة — نشر الإعلان
                </button>
                <button onClick={() => del(s.id)}
                  className="px-4 py-2.5 rounded-xl font-bold text-sm active:scale-95"
                  style={{ background: "rgba(239,68,68,0.12)", color: "#f87171" }}>
                  رفض
                </button>
              </div>
            )}
            {s.status === "approved" && (
              <div className="flex gap-2">
                <button onClick={() => updateStatus(s.id, "pending")}
                  className="flex-1 py-2 rounded-xl text-xs font-bold active:scale-95"
                  style={{ background: "rgba(255,255,255,0.07)", color: CREAM_D }}>
                  إلغاء النشر
                </button>
                <button onClick={() => del(s.id)}
                  className="px-4 py-2 rounded-xl text-xs font-bold active:scale-95"
                  style={{ background: "rgba(239,68,68,0.12)", color: "#f87171" }}>
                  حذف
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Floating bulk-delete bar — only in approved tab */}
      {tab === "approved" && selectedSubs.size > 0 && (
        <div className="fixed bottom-0 right-0 left-0 px-4 py-4 flex gap-2"
          style={{ background: `linear-gradient(0deg,${G_DARK},${G_DARK}ee)`, borderTop: BORDER }}>
          <button
            disabled={bulkDeleting}
            onClick={() => delBulk([...selectedSubs])}
            className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-2xl font-black text-base active:scale-95"
            style={{
              background: bulkDeleting ? "rgba(239,68,68,0.1)" : "rgba(239,68,68,0.25)",
              color: "#f87171",
              border: "1px solid rgba(239,68,68,0.4)",
              opacity: bulkDeleting ? 0.6 : 1,
            }}>
            {bulkDeleting
              ? <div className="w-5 h-5 border-2 border-t-transparent rounded-full animate-spin" style={{ borderColor: "#f87171 transparent #f87171 #f87171" }} />
              : <Trash2 size={18} />}
            حذف المحددة ({selectedSubs.size})
          </button>
          <button onClick={() => setSelectedSubs(new Set())}
            className="px-4 py-3.5 rounded-2xl font-bold active:scale-95"
            style={{ background: "rgba(255,255,255,0.08)", color: CREAM_D, border: BORDER }}>
            <X size={18} />
          </button>
        </div>
      )}

      {/* Card viewer modal — works for all submissions, falls back to submissionToCardData */}
      {viewCard && (() => {
        const cd = viewCard.cardData ?? submissionToCardData(viewCard);
        return (
          <CardViewer
            items={[{ data: cd }]}
            startIndex={0}
            onClose={() => setViewCard(null)}
            logoUrl={logoDataUrl}
          />
        );
      })()}
    </div>
  );
}

/* ─── Company Submissions View (Admin) ──────────────────────────── */
function CompanySubmissionsView({ onClose }: { onClose: () => void }) {
  const [subs, setSubs]       = useState<Submission[]>([]);
  const [loading, setLoading] = useState(true);
  const [visitorCnt, setVisitorCnt] = useState(0);
  const [viewSub, setViewSub] = useState<Submission | null>(null);
  const [updating, setUpdating] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const [all, vc] = await Promise.all([
          fetchSubmissions(),
          fetchCompanyVisitorCount().catch(() => ({ total: 0 })),
        ]);
        setSubs(all.filter(s => s.submittedBy === "company").sort((a, b) => b.submittedAt - a.submittedAt));
        setVisitorCnt(vc.total);
      } catch { /* ignore */ }
      finally { setLoading(false); }
    })();
  }, []);

  const updateStatus = async (id: string, status: "approved" | "rejected") => {
    setUpdating(id);
    try {
      await patchSubmission(id, { status });
      setSubs(prev => prev.map(s => s.id === id ? { ...s, status } : s));
      if (viewSub?.id === id) setViewSub(v => v ? { ...v, status } : v);
    } catch { alert("تعذّر التحديث"); }
    finally { setUpdating(null); }
  };

  const parseOC = (oc?: string) => {
    const lines = (oc ?? "").split("\n");
    const get = (pfx: string) => lines.find(l => l.startsWith(pfx))?.slice(pfx.length).trim() ?? "";
    return { name: get("اسم: "), phone: get("هاتف: "), url: get("موقع: ") };
  };

  /* ── Detail overlay ── */
  if (viewSub) {
    const oc = parseOC(viewSub.ownerContact);
    return (
      <div className="fixed inset-0 z-50 flex flex-col overflow-y-auto" dir="rtl"
        style={{ background: `linear-gradient(145deg,${G_DARK},${G_MID})`, fontFamily: FONT }}>
        <div className="sticky top-0 z-10 flex items-center gap-3 px-4 pt-6 pb-3"
          style={{ background: G_DARK, borderBottom: `2px solid ${AU_DEEP}` }}>
          <button onClick={() => setViewSub(null)} className="p-2 rounded-full active:scale-90"
            style={{ background: "rgba(255,255,255,0.1)", color: CREAM }}><ChevronRight size={22}/></button>
          <Building2 size={17} style={{ color: "#93c5fd" }}/>
          <div className="flex-1 min-w-0">
            <p className="font-black text-base truncate" style={{ color: AU_TEXT }}>{viewSub.companyName ?? "شركة"}</p>
            <p className="text-xs" style={{ color: CREAM_D }}>{viewSub.region}</p>
          </div>
          <span className="text-xs px-2 py-1 rounded-lg font-bold" style={{
            background: viewSub.status === "approved" ? "rgba(34,197,94,0.15)" : viewSub.status === "pending" ? "rgba(251,191,36,0.15)" : "rgba(239,68,68,0.15)",
            color: viewSub.status === "approved" ? "#22c55e" : viewSub.status === "pending" ? "#fbbf24" : "#f87171",
          }}>
            {viewSub.status === "approved" ? "معتمد" : viewSub.status === "pending" ? "قيد المراجعة" : "مرفوض"}
          </span>
        </div>
        <div className="px-4 py-4 flex flex-col gap-4 pb-20">
          {/* Owner info */}
          <div className="rounded-2xl overflow-hidden" style={{ border: `2px solid ${AU_DEEP}88` }}>
            <div className="px-4 py-2.5" style={{ background: `rgba(184,145,42,0.18)` }}>
              <span className="font-black text-sm flex items-center gap-2" style={{ color: AU_TEXT }}><Lock size={13}/> معلومات سرية</span>
            </div>
            <div className="px-4 py-3 flex flex-col gap-2">
              {oc.name  && <p className="text-sm" style={{ color: CREAM }}><span style={{ color: AU_TEXT }}>اسم صاحب المشروع: </span>{oc.name}</p>}
              {oc.phone && <p className="text-sm" style={{ color: CREAM }}>
                <span style={{ color: AU_TEXT }}>الهاتف: </span>
                <a href={`tel:${oc.phone}`} style={{ color: "#4ade80" }}>{oc.phone}</a>
                <span> · </span>
                <a href={`https://wa.me/962${oc.phone.replace(/^0/,"")}`} target="_blank" rel="noreferrer" style={{ color: "#4ade80" }}>واتساب</a>
              </p>}
              {oc.url   && <p className="text-sm" style={{ color: CREAM }}>
                <span style={{ color: AU_TEXT }}>الخريطة: </span>
                <a href={oc.url} target="_blank" rel="noreferrer" style={{ color: "#60a5fa" }}>عرض الموقع</a>
              </p>}
            </div>
          </div>
          {/* Card data / floors */}
          {viewSub.cardData?.floors && viewSub.cardData.floors.length > 0 && (
            <div className="rounded-2xl overflow-hidden" style={{ border: BORDER }}>
              <div className="px-4 py-2.5" style={{ background: `linear-gradient(90deg,${G_DARK},${G_MID})` }}>
                <span className="font-black text-sm" style={{ color: AU_TEXT }}>جدول الطوابق</span>
              </div>
              <div className="overflow-x-auto px-2 py-2">
                <table className="w-full border-collapse text-sm">
                  <thead>
                    <tr style={{ background: `rgba(184,145,42,0.2)` }}>
                      {["الطابق","المساحة","السعر"].map(h => (
                        <th key={h} className="py-2 px-3 text-right font-black" style={{ color: AU_BRT, border: BORDER }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {viewSub.cardData.floors.map((f, i) => (
                      <tr key={f.id ?? i} style={{ background: i%2===0 ? "rgba(180,145,42,0.08)" : "transparent" }}>
                        <td className="py-2 px-3 font-bold" style={{ color: CREAM, border: BORDER }}>{f.name}</td>
                        <td className="py-2 px-3 text-center" style={{ color: CREAM, border: BORDER }}>{f.area}</td>
                        <td className="py-2 px-3 text-center" style={{ color: "#fff", border: BORDER }}>{f.price}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
          {/* Description */}
          {viewSub.description && (
            <div className="rounded-2xl overflow-hidden" style={{ border: BORDER }}>
              <div className="px-4 py-2.5" style={{ background: `linear-gradient(90deg,${G_DARK},${G_MID})` }}>
                <span className="font-black text-sm" style={{ color: AU_TEXT }}>المواصفات والتفاصيل</span>
              </div>
              <p className="px-4 py-3 text-sm leading-relaxed" style={{ color: CREAM }}>{viewSub.description}</p>
            </div>
          )}
          {/* Actions */}
          {viewSub.status === "pending" && (
            <div className="flex gap-3">
              <button onClick={() => updateStatus(viewSub.id, "approved")} disabled={!!updating}
                className="flex-1 py-3 rounded-2xl font-black text-sm flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50"
                style={{ background: "rgba(34,197,94,0.15)", color: "#22c55e", border: "1.5px solid #22c55e44" }}>
                <Check size={16}/> قبول
              </button>
              <button onClick={() => updateStatus(viewSub.id, "rejected")} disabled={!!updating}
                className="flex-1 py-3 rounded-2xl font-black text-sm flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50"
                style={{ background: "rgba(239,68,68,0.15)", color: "#f87171", border: "1.5px solid #f8717144" }}>
                <X size={16}/> رفض
              </button>
            </div>
          )}
          {viewSub.status !== "pending" && (
            <div className="flex gap-3">
              <button onClick={() => updateStatus(viewSub.id, viewSub.status === "approved" ? "rejected" : "approved")} disabled={!!updating}
                className="flex-1 py-3 rounded-2xl font-bold text-sm active:scale-95 disabled:opacity-50"
                style={{ background: "rgba(255,255,255,0.08)", color: CREAM_D, border: BORDER }}>
                {viewSub.status === "approved" ? "تغيير إلى مرفوض" : "تغيير إلى معتمد"}
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col" dir="rtl"
      style={{ background: `linear-gradient(145deg,${G_DARK},${G_MID})`, fontFamily: FONT }}>
      {/* Header */}
      <div className="flex items-center gap-3 px-4 pt-6 pb-4">
        <button onClick={onClose} className="p-2 rounded-full active:scale-90"
          style={{ background: "rgba(255,255,255,0.1)", color: CREAM }}><ChevronRight size={22}/></button>
        <Building2 size={20} style={{ color: "#93c5fd" }}/>
        <h2 className="font-black text-lg" style={{ color: AU_TEXT }}>إعلانات الشركات</h2>
      </div>

      {/* Stats strip */}
      <div className="mx-4 mb-4 grid grid-cols-3 gap-2">
        {[
          { label: "إجمالي", val: subs.length, col: AU_TEXT },
          { label: "قيد المراجعة", val: subs.filter(s=>s.status==="pending").length, col: "#fbbf24" },
          { label: "زوار الشركات", val: visitorCnt, col: "#93c5fd" },
        ].map(s => (
          <div key={s.label} className="rounded-xl px-2 py-3 text-center"
            style={{ background: "rgba(255,255,255,0.07)", border: BORDER }}>
            <p className="text-xl font-black" style={{ color: s.col }}>{s.val}</p>
            <p className="text-xs mt-0.5" style={{ color: CREAM_D }}>{s.label}</p>
          </div>
        ))}
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto px-4 pb-10 space-y-3">
        {loading && <p className="text-center mt-10 text-sm" style={{ color: CREAM_D }}>جاري التحميل...</p>}
        {!loading && subs.length === 0 && (
          <div className="text-center mt-20">
            <Building2 size={48} className="mx-auto mb-3 opacity-30" style={{ color: CREAM_D }}/>
            <p style={{ color: CREAM_D }}>لا توجد إعلانات من شركات</p>
          </div>
        )}
        {subs.map(s => {
          const oc = parseOC(s.ownerContact);
          return (
            <button key={s.id} onClick={() => setViewSub(s)}
              className="w-full text-right rounded-2xl p-4 active:scale-95"
              style={{ background: "rgba(255,255,255,0.06)", border: s.status==="pending" ? `2px solid ${AU_BRT}66` : s.status==="approved" ? "2px solid #22c55e44" : BORDER }}>
              <div className="flex items-center justify-between gap-2 mb-1.5">
                <span className="font-black text-sm" style={{ color: "#93c5fd" }}>{s.companyName ?? "شركة"}</span>
                <span className="text-xs px-2 py-0.5 rounded-lg" style={{
                  background: s.status==="approved" ? "rgba(34,197,94,0.15)" : s.status==="pending" ? "rgba(251,191,36,0.15)" : "rgba(239,68,68,0.15)",
                  color: s.status==="approved" ? "#22c55e" : s.status==="pending" ? "#fbbf24" : "#f87171",
                }}>
                  {s.status==="approved" ? "معتمد" : s.status==="pending" ? "قيد المراجعة" : "مرفوض"}
                </span>
              </div>
              {s.region && <p className="text-sm mb-0.5" style={{ color: CREAM }}>📍 {s.region}</p>}
              {oc.name && <p className="text-xs" style={{ color: CREAM_D }}>👤 {oc.name}</p>}
              <p className="text-xs mt-1" style={{ color: CREAM_D }}>
                {new Date(s.submittedAt).toLocaleDateString("ar-SA")} — {(s.cardData?.floors?.length ?? 0)} طابق
              </p>
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ── Sub-info helper (module-level, not nested) ── */
function SubInfo({ subId, subs }: { subId: string; subs: Submission[] }) {
  const sub = subs.find(s => s.id === subId);
  if (!sub) return <span className="text-xs" style={{ color: CREAM_D }}>#{subId}</span>;
  return <span className="text-xs" style={{ color: CREAM_D }}>{sub.cardRegion || sub.region} — {sub.propertyType}</span>;
}

/* ─── Featured Ads Manager (Admin) ──────────────────────────────── */
function FeaturedAdsView({ onClose }: { onClose: () => void }) {
  const [ads, setAds]           = useState<FeaturedAd[]>([]);
  const [loading, setLoading]   = useState(true);
  const [subs, setSubs]         = useState<Submission[]>([]);
  const [acting, setActing]     = useState<number | null>(null);
  const [contactLogs, setContactLogs] = useState<ContactLog[]>([]);
  const [activeTab, setActiveTab]     = useState<"ads" | "logs">("ads");
  const [viewFeaturedSub, setViewFeaturedSub] = useState<Submission | null>(null);
  const [deletingLog, setDeletingLog] = useState<number | null>(null);
  const logoDataUrl = useBase64Image(logoSrc);

  useEffect(() => {
    Promise.all([fetchFeaturedAds(), fetchSubmissions(), fetchContactLogs()])
      .then(([fa, ss, cl]) => { setAds(fa); setSubs(ss); setContactLogs(cl); })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const approve = async (id: number) => {
    setActing(id);
    try {
      await approveFeaturedApi(id);
      setAds(prev => prev.map(a => a.id === id ? { ...a, status: "approved" } : a));
    } catch { alert("تعذّر الموافقة"); } finally { setActing(null); }
  };
  const reject = async (id: number) => {
    if (!confirm("رفض هذا الطلب؟")) return;
    setActing(id);
    try {
      await rejectFeaturedApi(id);
      setAds(prev => prev.map(a => a.id === id ? { ...a, status: "rejected" } : a));
    } catch { alert("تعذّر الرفض"); } finally { setActing(null); }
  };
  const deleteLog = async (id: number) => {
    if (!confirm("حذف هذا السجل؟")) return;
    setDeletingLog(id);
    try {
      await deleteContactLogApi(id);
      setContactLogs(prev => prev.filter(l => l.id !== id));
    } catch { alert("تعذّر الحذف"); } finally { setDeletingLog(null); }
  };
  const deleteFeatured = async (id: number) => {
    if (!confirm("حذف هذا الإعلان نهائياً؟ لا يمكن التراجع.")) return;
    setActing(id);
    try {
      await deleteFeaturedApi(id);
      setAds(prev => prev.filter(a => a.id !== id));
    } catch { alert("تعذّر الحذف"); } finally { setActing(null); }
  };

  const pending  = ads.filter(a => a.status === "pending");
  const approved = ads.filter(a => a.status === "approved");
  const now      = Date.now();

  return (
    <div className="min-h-screen flex flex-col" dir="rtl"
      style={{ background: `linear-gradient(145deg,${G_DARK},${G_MID})`, fontFamily: FONT }}>

      <div className="flex items-center gap-3 px-4 pt-6 pb-2">
        <button onClick={onClose} className="p-2 rounded-full active:scale-90"
          style={{ background: "rgba(255,255,255,0.1)", color: CREAM }}>
          <ChevronRight size={22} />
        </button>
        <Crown size={20} style={{ color: AU_TEXT }} />
        <h1 className="font-black text-xl" style={{ color: AU_TEXT }}>الإعلانات المدفوعة</h1>
        {pending.length > 0 && (
          <span className="px-2 py-0.5 rounded-full text-xs font-black" style={{ background: "#ef4444", color: "#fff" }}>
            {pending.length} جديد
          </span>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-2 px-4 pb-3">
        <button onClick={() => setActiveTab("ads")}
          className="px-4 py-2 rounded-xl font-bold text-sm active:scale-95"
          style={{ background: activeTab === "ads" ? `linear-gradient(135deg,${AU_DEEP},${AU_BRT})` : "rgba(255,255,255,0.08)", color: activeTab === "ads" ? G_DARK : CREAM_D }}>
          الإعلانات
        </button>
        <button onClick={() => setActiveTab("logs")}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl font-bold text-sm active:scale-95"
          style={{ background: activeTab === "logs" ? `linear-gradient(135deg,${AU_DEEP},${AU_BRT})` : "rgba(255,255,255,0.08)", color: activeTab === "logs" ? G_DARK : CREAM_D }}>
          سجل التواصل
          {contactLogs.length > 0 && (
            <span className="px-1.5 py-0.5 rounded-full text-xs font-black"
              style={{ background: activeTab === "logs" ? "rgba(0,0,0,0.2)" : "#22c55e", color: "#fff" }}>
              {contactLogs.length}
            </span>
          )}
        </button>
      </div>

      {loading ? (
        <div className="flex-1 flex items-center justify-center">
          <div className="w-10 h-10 border-4 border-t-transparent rounded-full animate-spin" style={{ borderColor: `${AU_DEEP} transparent` }} />
        </div>
      ) : activeTab === "logs" ? (
        /* ── Contact Logs ── */
        <div className="flex-1 overflow-y-auto px-4 pb-20">
          {contactLogs.length === 0 ? (
            <div className="text-center mt-16" style={{ color: CREAM_D }}>
              <Phone size={40} className="mx-auto mb-3 opacity-30" />
              <p>لا توجد سجلات تواصل بعد</p>
            </div>
          ) : (
            <div className="rounded-2xl overflow-hidden" style={{ border: BORDER }}>
              {/* Table header */}
              <div className="grid gap-0 px-3 py-3"
                style={{ gridTemplateColumns: "1fr auto 1fr auto", background: `linear-gradient(90deg,${AU_DEEP}88,${G_DARK})` }}>
                <span className="text-xs font-black text-center" style={{ color: AU_TEXT }}>الزائر</span>
                <span className="text-xs font-black text-center px-2" style={{ color: AU_TEXT }}>البطاقة</span>
                <span className="text-xs font-black text-center" style={{ color: AU_TEXT }}>صاحب الإعلان</span>
                <span className="text-xs font-black text-center px-1" style={{ color: AU_TEXT }}>حذف</span>
              </div>
              {contactLogs.map((log, i) => {
                const adCardNum = ads.find(a => a.id === log.featuredAdId)?.cardNum;
                return (
                  <div key={log.id}
                    className="grid gap-0 px-3 py-3 border-t items-center"
                    style={{ gridTemplateColumns: "1fr auto 1fr auto", background: i % 2 === 0 ? "rgba(255,255,255,0.03)" : "rgba(180,145,42,0.06)", borderColor: `${AU_DEEP}33` }}>
                    <div className="flex flex-col items-center gap-0.5">
                      <span className="font-bold text-sm" style={{ color: CREAM, direction: "ltr" }}>
                        {log.visitorPhone === "—" ? "—" : log.visitorPhone}
                      </span>
                      <span className="text-xs" style={{ color: CREAM_D }}>
                        {new Date(log.contactedAt).toLocaleDateString("ar-JO", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                      </span>
                    </div>
                    <div className="flex items-center justify-center px-2">
                      {adCardNum ? (
                        <span className="text-xs font-black px-1.5 py-0.5 rounded-full whitespace-nowrap"
                          style={{ background: `${AU_DEEP}55`, color: AU_TEXT }}>#{adCardNum}</span>
                      ) : (
                        <span className="text-xs" style={{ color: CREAM_D }}>—</span>
                      )}
                    </div>
                    <div className="flex flex-col items-center gap-0.5">
                      <span className="font-bold text-sm" style={{ color: AU_TEXT, direction: "ltr" }}>{log.ownerPhone}</span>
                      <span className="text-xs truncate max-w-full" style={{ color: CREAM_D }}>{log.ownerName}</span>
                    </div>
                    <div className="flex items-center justify-center px-1">
                      <button onClick={() => deleteLog(log.id)} disabled={deletingLog === log.id}
                        className="p-1.5 rounded-lg active:scale-90 disabled:opacity-40"
                        style={{ background: "rgba(239,68,68,0.15)", color: "#f87171" }}>
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto px-4 pb-20 flex flex-col gap-4">

          {ads.length === 0 && (
            <div className="text-center mt-20" style={{ color: CREAM_D }}>
              <Crown size={48} className="mx-auto mb-3 opacity-30" />
              <p>لا توجد طلبات إعلانات مدفوعة بعد</p>
            </div>
          )}

          {/* Pending */}
          {pending.length > 0 && (
            <div>
              <p className="font-black text-sm mb-2" style={{ color: "#fbbf24" }}>⏳ بانتظار الموافقة ({pending.length})</p>
              {pending.map(a => {
                const sub = subs.find(s => s.id === a.submissionId);
                return (
                  <div key={a.id} className="rounded-2xl p-4 mb-3 flex flex-col gap-3"
                    style={{ background: "rgba(184,145,42,0.1)", border: `1.5px solid ${AU_DEEP}88` }}>
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex flex-col gap-1">
                        <span className="font-black text-sm" style={{ color: CREAM }}>{a.companyName}</span>
                        <SubInfo subId={a.submissionId} subs={subs} />
                        <span className="text-xs" style={{ color: CREAM_D }}>📱 {a.companyPhone}</span>
                      </div>
                      <div className="flex flex-col items-end gap-1">
                        <span className="font-black text-lg" style={{ color: AU_BRT }}>{a.planPrice} JD</span>
                        <span className="text-xs" style={{ color: CREAM_D }}>{a.planLabel}</span>
                      </div>
                    </div>
                    {sub && (
                      <div className="rounded-xl p-2 text-xs" style={{ background: "rgba(0,0,0,0.3)", color: CREAM_D }}>
                        {(sub.cardData?.projectName) || sub.region} — {sub.cardRegion || sub.region}
                      </div>
                    )}
                    {/* View card button */}
                    {sub && (
                      <button onClick={() => setViewFeaturedSub(sub)}
                        className="w-full py-2 rounded-xl font-bold text-sm active:scale-95 flex items-center justify-center gap-2"
                        style={{ background: "rgba(201,162,39,0.15)", color: AU_TEXT, border: BORDER }}>
                        <Building2 size={14} /> عرض البطاقة
                      </button>
                    )}
                    <div className="flex gap-2">
                      <button onClick={() => approve(a.id)} disabled={acting === a.id}
                        className="flex-1 py-2.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50"
                        style={{ background: "linear-gradient(135deg,#16a34a,#22c55e)", color: "#fff" }}>
                        <Star size={15} /> موافقة — نشر مميز
                      </button>
                      <button onClick={() => reject(a.id)} disabled={acting === a.id}
                        className="flex-1 py-2.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50"
                        style={{ background: "rgba(239,68,68,0.15)", color: "#f87171", border: "1px solid #f8717133" }}>
                        <X size={15} /> رفض
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Approved */}
          {approved.length > 0 && (() => {
            const totalRevenue = approved.reduce((sum, a) => sum + (a.planPrice || 0), 0);
            return (
            <div>
              <p className="font-black text-sm mb-2" style={{ color: "#22c55e" }}>✅ معتمدة ({approved.length})</p>
              {approved.map(a => {
                const expired = a.expiresAt && a.expiresAt < now;
                return (
                  <div key={a.id} className="rounded-2xl p-3 mb-2 flex flex-col gap-2"
                    style={{ background: "rgba(34,197,94,0.08)", border: "1px solid rgba(34,197,94,0.3)" }}>
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex flex-col gap-0.5">
                        <span className="font-bold text-sm" style={{ color: CREAM }}>{a.companyName}</span>
                        <span className="text-xs" style={{ color: CREAM_D }}>{a.planLabel}</span>
                        {a.companyPhone && (
                          <span className="text-xs font-bold" style={{ color: AU_TEXT }}>📱 {a.companyPhone}</span>
                        )}
                        <SubInfo subId={a.submissionId} subs={subs} />
                      </div>
                      <div className="flex flex-col items-end gap-1">
                        {a.planPrice > 0 && (
                          <span className="text-base font-black" style={{ color: AU_BRT }}>{a.planPrice} د.أ</span>
                        )}
                        {a.cardNum && (
                          <span className="text-xs font-black px-2 py-0.5 rounded-full"
                            style={{ background: `${AU_DEEP}55`, color: AU_TEXT }}>
                            بطاقة #{a.cardNum}
                          </span>
                        )}
                        {expired
                          ? <span className="text-xs font-bold" style={{ color: "#f87171" }}>منتهية</span>
                          : <span className="text-xs" style={{ color: "#22c55e" }}>حتى {a.expiresAt ? new Date(a.expiresAt).toLocaleDateString("ar-JO") : "—"}</span>
                        }
                        <span className="text-xs font-black px-2 py-0.5 rounded-full"
                          style={{ background: (a.contactsCount ?? 0) > 0 ? "rgba(34,197,94,0.2)" : "rgba(255,255,255,0.07)", color: (a.contactsCount ?? 0) > 0 ? "#22c55e" : CREAM_D }}>
                          📞 {a.contactsCount ?? 0} تواصل
                        </span>
                      </div>
                    </div>
                    {/* View card + delete row */}
                    {(() => {
                      const sub = subs.find(s => s.id === a.submissionId);
                      return (
                        <div className="flex gap-2">
                          {sub && (
                            <button onClick={() => setViewFeaturedSub(sub)}
                              className="flex-1 py-2 rounded-xl font-bold text-sm active:scale-95 flex items-center justify-center gap-2"
                              style={{ background: "rgba(201,162,39,0.15)", color: AU_TEXT, border: BORDER }}>
                              <Building2 size={13} /> عرض البطاقة
                            </button>
                          )}
                          <button onClick={() => deleteFeatured(a.id)} disabled={acting === a.id}
                            className="py-2 px-3 rounded-xl font-bold text-sm active:scale-95 flex items-center justify-center gap-1 disabled:opacity-50"
                            style={{ background: "rgba(239,68,68,0.15)", color: "#f87171", border: "1px solid #f8717133" }}>
                            <Trash2 size={13} /> حذف
                          </button>
                        </div>
                      );
                    })()}
                  </div>
                );
              })}
              {/* Revenue total */}
              <div className="rounded-2xl p-4 mt-2 flex items-center justify-between"
                style={{ background: `linear-gradient(135deg,${AU_DEEP}33,${AU_BRT}22)`, border: `1.5px solid ${AU_DEEP}` }}>
                <div className="flex flex-col gap-0.5">
                  <span className="text-xs font-bold" style={{ color: CREAM_D }}>إجمالي الإيراد عبر CliQ</span>
                  <span className="text-xs" style={{ color: CREAM_D }}>{approved.length} اشتراك مدفوع</span>
                </div>
                <span className="text-2xl font-black" style={{ color: AU_BRT }}>{totalRevenue} <span className="text-sm">د.أ</span></span>
              </div>
            </div>
            );
          })()}
        </div>
      )}

      {/* Card viewer modal for featured ads */}
      {viewFeaturedSub && (() => {
        const cd = viewFeaturedSub.cardData ?? submissionToCardData(viewFeaturedSub);
        return (
          <CardViewer
            items={[{ data: cd }]}
            startIndex={0}
            onClose={() => setViewFeaturedSub(null)}
            logoUrl={logoDataUrl}
          />
        );
      })()}
    </div>
  );
}

/* ─── Employee Manager (Admin) ───────────────────────────────────── */
function EmployeeManager({ onClose }: { onClose: () => void }) {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading]     = useState(true);
  const [apiErr, setApiErr]       = useState("");
  const [showForm, setShowForm]   = useState(false);
  const [editTarget, setEditTarget] = useState<Employee | null>(null);
  const [name, setName]           = useState("");
  const [username, setUsername]   = useState("");
  const [password, setPassword]   = useState("");
  const [formErr, setFormErr]     = useState("");
  const [formBusy, setFormBusy]   = useState(false);

  const [adminUser, setAdminUser]   = useState("");
  const [adminPass, setAdminPass]   = useState("");
  const [adminSaved, setAdminSaved] = useState(false);
  const [adminBusy, setAdminBusy]   = useState(false);
  const [syncBusy, setSyncBusy]     = useState(false);
  const [syncMsg,  setSyncMsg]      = useState<{ok:boolean;text:string}|null>(null);
  const [pullBusy, setPullBusy]     = useState(false);
  const [stats, setStats]           = useState<EmployeeStats[]>([]);
  const [totalCards, setTotalCards] = useState<number | null>(null);
  const [visitorCount, setVisitorCount] = useState<number | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const [emps, info, empStats, overview, vcount] = await Promise.all([
          fetchEmployees(), getAdminApi(), fetchEmployeeStats(), fetchOverviewStats(), fetchVisitorCount(),
        ]);
        setEmployees(emps);
        setAdminUser(info.username ?? "");
        setStats(empStats);
        setTotalCards(overview.totalCards);
        setVisitorCount(vcount.total);
      } catch {
        setApiErr("تعذّر الاتصال بالسيرفر، حاول مجدداً");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const openAdd  = () => { setEditTarget(null); setName(""); setUsername(""); setPassword(""); setFormErr(""); setShowForm(true); };
  const openEdit = (e: Employee) => { setEditTarget(e); setName(e.name); setUsername(e.username); setPassword(""); setFormErr(""); setShowForm(true); };

  const save = async () => {
    if (!username) return;
    if (!editTarget && !password) return; // password required when creating
    setFormErr(""); setFormBusy(true);
    try {
      if (editTarget) {
        await putEmployee(editTarget.id, {
          name: name || undefined,
          username,
          ...(password ? { password } : {}),
        });
        setEmployees(prev => prev.map(e => e.id === editTarget.id ? { ...e, name, username } : e));
      } else {
        await postEmployee({ id: `${Date.now()}`, name, username, password });
        const fresh = await fetchEmployees();
        setEmployees(fresh);
      }
      setShowForm(false);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "";
      setFormErr(msg.includes("409") ? "اسم المستخدم مستخدم مسبقاً" : "تعذّر حفظ الموظف، حاول مجدداً");
    } finally {
      setFormBusy(false);
    }
  };

  const del = async (id: string) => {
    if (!confirm("حذف هذا الموظف؟")) return;
    try {
      await deleteEmployeeApi(id);
      setEmployees(prev => prev.filter(e => e.id !== id));
    } catch {
      setApiErr("تعذّر حذف الموظف");
    }
  };

  const doSync = async () => {
    setSyncBusy(true); setSyncMsg(null);
    try {
      await pushToProd();
      setSyncMsg({ ok: true, text: "✓ تمت المزامنة الكاملة مع الإنتاج" });
    } catch {
      setSyncMsg({ ok: false, text: "تعذّرت المزامنة، حاول مجدداً" });
    } finally {
      setSyncBusy(false);
      setTimeout(() => setSyncMsg(null), 4000);
    }
  };

  const doPull = async () => {
    if (!confirm("سيتم استبدال جميع البيانات ببيانات النسخة المنشورة. هل أنت متأكد؟")) return;
    setPullBusy(true); setSyncMsg(null);
    try {
      await pullFromProd();
      setSyncMsg({ ok: true, text: "✓ تم السحب الكامل من الإنتاج" });
      const [emps, info] = await Promise.all([fetchEmployees(), getAdminApi()]);
      setEmployees(emps);
      setAdminUser(info.username ?? "");
    } catch {
      setSyncMsg({ ok: false, text: "تعذّر السحب، حاول مجدداً" });
    } finally {
      setPullBusy(false);
      setTimeout(() => setSyncMsg(null), 4000);
    }
  };

  const saveAdmin = async () => {
    if (!adminUser || !adminPass) return;
    setAdminBusy(true);
    try {
      await putAdminApi(adminUser, adminPass);
      setAdminSaved(true);
      setAdminPass("");
      setTimeout(() => setAdminSaved(false), 2000);
    } catch {
      setApiErr("تعذّر تحديث بيانات المدير");
    } finally {
      setAdminBusy(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col" dir="rtl"
      style={{ background: `linear-gradient(145deg,${G_DARK} 0%,${G_MID} 50%,${G_DARK} 100%)`, fontFamily: FONT }}>
      <div className="flex items-center justify-between px-4 pt-6 pb-4">
        <div className="flex items-center gap-3">
          <button onClick={onClose} className="p-2 rounded-full active:scale-90"
            style={{ background: "rgba(255,255,255,0.1)", color: CREAM }}>
            <ChevronRight size={22} />
          </button>
          <Users size={20} style={{ color: AU_TEXT }} />
          <h1 className="font-black text-xl" style={{ color: AU_TEXT }}>إدارة الموظفين</h1>
        </div>
        <button onClick={openAdd}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl font-bold text-sm active:scale-95"
          style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK }}>
          <UserPlus size={16} /> إضافة
        </button>
      </div>

      {loading && (
        <div className="flex-1 flex flex-col items-center justify-center gap-3">
          <div className="w-10 h-10 border-4 border-t-transparent rounded-full animate-spin"
            style={{ borderColor: `${AU_DEEP} transparent ${AU_DEEP} ${AU_DEEP}` }} />
          <p className="text-sm" style={{ color: CREAM_D }}>جاري التحميل...</p>
        </div>
      )}
      {!loading && apiErr && (
        <div className="mx-4 mt-4 rounded-xl px-4 py-3 text-center text-sm text-red-400 bg-red-900/20">{apiErr}</div>
      )}

      {!loading && (
      <div className="flex-1 overflow-y-auto px-4 pb-8 space-y-3">
        {/* Admin credentials */}
        <div className="rounded-2xl p-4 space-y-3"
          style={{ background: "rgba(201,162,39,0.1)", border: `2px solid ${AU_DEEP}` }}>
          <p className="font-bold flex items-center gap-2" style={{ color: AU_TEXT }}>
            <ShieldCheck size={16} /> بيانات المدير
          </p>
          <div className="flex gap-2">
            <input value={adminUser} onChange={e => setAdminUser(e.target.value)} placeholder="اسم المستخدم" dir="rtl"
              className="flex-1 rounded-xl px-3 py-2 text-sm outline-none"
              style={{ background: "rgba(255,255,255,0.1)", color: CREAM, border: BORDER, fontFamily: FONT }} />
            <input value={adminPass} onChange={e => setAdminPass(e.target.value)} placeholder="كلمة السر الجديدة" dir="rtl" type="password"
              className="flex-1 rounded-xl px-3 py-2 text-sm outline-none"
              style={{ background: "rgba(255,255,255,0.1)", color: CREAM, border: BORDER, fontFamily: FONT }} />
          </div>
          <button onClick={saveAdmin} disabled={adminBusy || !adminUser || !adminPass}
            className="w-full py-2 rounded-xl font-bold text-sm active:scale-95 disabled:opacity-40"
            style={{ background: adminSaved ? "#22c55e" : `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK }}>
            {adminSaved ? "✓ تم الحفظ" : adminBusy ? "جاري الحفظ..." : "حفظ بيانات المدير"}
          </button>

          {/* Sync to/from Production */}
          <div className="pt-1 border-t" style={{ borderColor: `${AU_DEEP}44` }}>
            <p className="text-xs mb-2 font-bold" style={{ color: CREAM_D }}>
              مزامنة كاملة للبيانات مع النسخة المنشورة (الإعلانات + الموظفون + المدير)
            </p>
            <div className="flex gap-2">
              <button onClick={doPull} disabled={pullBusy || syncBusy}
                className="flex-1 py-2 rounded-xl font-bold text-sm active:scale-95 flex items-center justify-center gap-1 disabled:opacity-40"
                style={{ background: "rgba(239,68,68,0.1)", color: "#fca5a5", border: "1.5px solid rgba(239,68,68,0.3)" }}>
                {pullBusy
                  ? <div className="w-3 h-3 border-2 border-t-transparent rounded-full animate-spin" style={{ borderColor: "#fca5a5 transparent #fca5a5 #fca5a5" }} />
                  : "↓ سحب من الإنتاج"}
              </button>
              <button onClick={doSync} disabled={syncBusy || pullBusy}
                className="flex-1 py-2 rounded-xl font-bold text-sm active:scale-95 flex items-center justify-center gap-1 disabled:opacity-40"
                style={{ background: "rgba(99,102,241,0.18)", color: "#a5b4fc", border: "1.5px solid rgba(99,102,241,0.4)" }}>
                {syncBusy
                  ? <div className="w-3 h-3 border-2 border-t-transparent rounded-full animate-spin" style={{ borderColor: "#a5b4fc transparent #a5b4fc #a5b4fc" }} />
                  : "↑ رفع للإنتاج"}
              </button>
            </div>
            {syncMsg && (
              <p className="text-xs mt-2 text-center font-bold"
                style={{ color: syncMsg.ok ? "#4ade80" : "#f87171" }}>
                {syncMsg.text}
              </p>
            )}
          </div>
        </div>

        {/* Stats row: cards + visitors */}
        <div className="flex gap-3">
          {totalCards !== null && (
            <div className="flex-1 rounded-2xl px-4 py-4 flex flex-col gap-1"
              style={{ background: `linear-gradient(135deg,${AU_DEEP}33,${AU_BRT}22)`, border: `2px solid ${AU_DEEP}` }}>
              <p className="text-xs font-bold" style={{ color: AU_TEXT }}>البطاقات المحفوظة</p>
              <p className="text-3xl font-black" style={{ color: AU_BRT }}>{totalCards}</p>
              <Archive size={18} style={{ color: AU_DEEP, opacity: 0.8 }} />
            </div>
          )}
          {visitorCount !== null && (
            <div className="flex-1 rounded-2xl px-4 py-4 flex flex-col gap-1"
              style={{ background: "linear-gradient(135deg,rgba(59,130,246,0.18),rgba(99,102,241,0.12))", border: "2px solid rgba(99,102,241,0.4)" }}>
              <p className="text-xs font-bold" style={{ color: "#a5b4fc" }}>مستخدمو التطبيق</p>
              <p className="text-3xl font-black" style={{ color: "#818cf8" }}>{visitorCount}</p>
              <div className="flex items-center justify-between mt-1">
                <Users size={18} style={{ color: "#6366f1", opacity: 0.8 }} />
                <button
                  onClick={async () => {
                    if (!confirm("تصفير عداد المستخدمين؟ لا يمكن التراجع عن هذا الإجراء.")) return;
                    try {
                      await deleteAllVisitors();
                      setVisitorCount(0);
                    } catch { alert("تعذّر تصفير العداد"); }
                  }}
                  className="text-xs px-2 py-1 rounded-lg font-bold active:scale-95"
                  style={{ background: "rgba(239,68,68,0.15)", color: "#f87171", border: "1px solid #f8717133" }}>
                  تصفير
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Employee activity report */}
        {stats.length > 0 && (
          <div className="rounded-2xl p-4 space-y-2"
            style={{ background: "rgba(255,255,255,0.07)", border: BORDER }}>
            <p className="font-bold text-sm flex items-center gap-2 mb-3" style={{ color: AU_TEXT }}>
              <BarChart2 size={16} /> تقرير نشاط الموظفين
            </p>
            <div className="grid grid-cols-3 text-xs font-bold pb-2 border-b" style={{ color: CREAM_D, borderColor: "rgba(255,255,255,0.1)" }}>
              <span>الموظف</span>
              <span className="text-center">آخر 24 ساعة</span>
              <span className="text-center">الإجمالي</span>
            </div>
            {stats.map(s => (
              <div key={s.employeeId} className="grid grid-cols-3 text-sm py-1.5 border-b" style={{ borderColor: "rgba(255,255,255,0.06)" }}>
                <span className="font-bold truncate" style={{ color: CREAM }}>{s.employeeName}</span>
                <span className="text-center font-black" style={{ color: s.last24h > 0 ? AU_BRT : CREAM_D }}>{s.last24h}</span>
                <span className="text-center font-bold" style={{ color: AU_TEXT }}>{s.total}</span>
              </div>
            ))}
          </div>
        )}

        {/* Employee list */}
        {employees.length === 0 && (
          <div className="text-center mt-8" style={{ color: CREAM_D }}>
            <Users size={40} className="mx-auto mb-2 opacity-40" />
            <p className="text-sm">لا يوجد موظفون بعد</p>
          </div>
        )}
        {employees.map(emp => {
          const empStat = stats.find(s => s.employeeId === emp.id);
          return (
          <div key={emp.id} className="rounded-2xl p-4"
            style={{ background: "rgba(255,255,255,0.07)", border: BORDER }}>
            <div className="flex items-center justify-between mb-2">
              <div>
                <p className="font-bold" style={{ color: CREAM }}>{emp.name || emp.username}</p>
                {empStat && (
                  <p className="text-xs mt-0.5" style={{ color: CREAM_D }}>
                    آخر 24س: <span style={{ color: empStat.last24h > 0 ? AU_BRT : CREAM_D }}>{empStat.last24h}</span>
                    {" · "}الكلي: <span style={{ color: AU_TEXT }}>{empStat.total}</span>
                  </p>
                )}
              </div>
              <div className="flex gap-2">
                <button onClick={() => openEdit(emp)} className="p-2 rounded-lg active:scale-90"
                  style={{ background: "rgba(201,162,39,0.2)", color: AU_TEXT }}>
                  <Pencil size={15} />
                </button>
                <button onClick={() => del(emp.id)} className="p-2 rounded-lg active:scale-90"
                  style={{ background: "rgba(239,68,68,0.15)", color: "#f87171" }}>
                  <Trash2 size={15} />
                </button>
              </div>
            </div>
            <div className="text-sm">
              <p style={{ color: CREAM_D }}>يوزر: <span style={{ color: CREAM }}>{emp.username}</span></p>
            </div>
          </div>
        ); })}
      </div>
      )}

      {/* Add/Edit form sheet */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end"
          style={{ background: "rgba(0,0,0,0.55)" }}
          onClick={e => { if (e.target === e.currentTarget) setShowForm(false); }}>
          <div className="rounded-t-3xl p-5 flex flex-col gap-4" dir="rtl"
            style={{ background: G_DARK, border: `2px solid ${AU_MID}`, borderBottom: "none" }}>
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-lg" style={{ color: AU_TEXT }}>
                {editTarget ? "تعديل موظف" : "إضافة موظف جديد"}
              </h3>
              <button onClick={() => setShowForm(false)}><X size={20} style={{ color: CREAM_D }} /></button>
            </div>
            {[
              { label: "الاسم", val: name, set: setName, pw: false },
              { label: "اسم المستخدم *", val: username, set: setUsername, pw: false },
              { label: editTarget ? "كلمة السر الجديدة (اتركها فارغة للإبقاء)" : "كلمة السر *", val: password, set: setPassword, pw: true },
            ].map(f => (
              <div key={f.label}>
                <p className="text-sm mb-1.5" style={{ color: CREAM_D }}>{f.label}</p>
                <input value={f.val} onChange={e => f.set(e.target.value)} dir="rtl"
                  type={f.pw ? "password" : "text"}
                  className="w-full rounded-xl px-4 py-3 text-base outline-none"
                  style={{ background: "rgba(255,255,255,0.1)", color: CREAM, border: BORDER, fontFamily: FONT }} />
              </div>
            ))}
            {formErr && <p className="text-sm text-red-400 text-center">{formErr}</p>}
            <button onClick={save} disabled={formBusy || !username || (!editTarget && !password)}
              className="w-full py-3.5 rounded-2xl font-black text-base active:scale-95 disabled:opacity-40"
              style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK }}>
              {formBusy ? "جاري الحفظ..." : editTarget ? "حفظ التعديل" : "إضافة الموظف"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── Inline Photo Uploader (used in submission forms) ──────────── */
function PhotoUploadSection({ cardId }: { cardId: string }) {
  const [photos, setPhotos]     = useState<Photo[]>([]);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress]   = useState(0);
  const [err, setErr]           = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    if (!files.length) return;
    const remaining = 10 - photos.length;
    const toUpload  = files.slice(0, remaining);
    if (!remaining) { setErr("الحد الأقصى 10 صور"); return; }
    setErr(""); setUploading(true); setProgress(0);
    for (let i = 0; i < toUpload.length; i++) {
      const file = toUpload[i]!;
      if (!file.type.startsWith("image/")) continue;
      try {
        const { uploadURL, objectPath } = await requestUploadUrl(file);
        await new Promise<void>((resolve, reject) => {
          const xhr = new XMLHttpRequest();
          xhr.open("PUT", uploadURL);
          xhr.setRequestHeader("Content-Type", file.type);
          xhr.upload.onprogress = ev => {
            if (ev.lengthComputable)
              setProgress(Math.round(((i + ev.loaded / ev.total) / toUpload.length) * 100));
          };
          xhr.onload  = () => xhr.status < 300 ? resolve() : reject(new Error(`HTTP ${xhr.status}`));
          xhr.onerror = () => reject(new Error("فشل الرفع"));
          xhr.send(file);
        });
        const photo = await postPhoto(cardId, objectPath);
        setPhotos(prev => [...prev, photo]);
      } catch { setErr("فشل رفع إحدى الصور"); }
    }
    setUploading(false); setProgress(0);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleDelete = async (photo: Photo) => {
    try {
      await deletePhotoApi(cardId, photo.id);
      setPhotos(prev => prev.filter(p => p.id !== photo.id));
    } catch { setErr("تعذّر حذف الصورة"); }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <p className="text-sm font-bold" style={{ color: CREAM_D }}>📷 صور الإعلان (اختياري)</p>
        <span className="text-xs px-2 py-0.5 rounded-full"
          style={{ background: "rgba(255,255,255,0.1)", color: CREAM_D }}>
          {photos.length}/10
        </span>
      </div>

      {/* Upload progress */}
      {uploading && (
        <div className="mb-2 rounded-full overflow-hidden h-1.5" style={{ background: "rgba(255,255,255,0.1)" }}>
          <div className="h-full rounded-full transition-all" style={{ width: `${progress}%`, background: AU_BRT }} />
        </div>
      )}
      {err && <p className="text-xs text-red-400 mb-2">{err}</p>}

      {/* Thumbnails grid — max-height to keep submit button visible */}
      {photos.length > 0 && (
        <div className="grid grid-cols-4 gap-2 mb-3 overflow-y-auto" style={{ maxHeight: 140 }}>
          {photos.map(photo => (
            <div key={photo.id} className="relative rounded-xl overflow-hidden"
              style={{ aspectRatio: "1", background: "rgba(255,255,255,0.05)" }}>
              <img
                src={photoUrl(photo)}
                alt="صورة"
                className="w-full h-full object-cover"
              />
              <button
                type="button"
                onClick={() => handleDelete(photo)}
                className="absolute top-0.5 left-0.5 w-5 h-5 rounded-full flex items-center justify-center"
                style={{ background: "rgba(239,68,68,0.9)" }}>
                <X size={10} style={{ color: "#fff" }} />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Add button */}
      {photos.length < 10 && (
        <button
          type="button"
          disabled={uploading}
          onClick={() => fileInputRef.current?.click()}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-sm active:scale-95 disabled:opacity-40"
          style={{ background: "rgba(201,162,39,0.15)", color: AU_TEXT, border: `1.5px dashed ${AU_DEEP}` }}>
          <Camera size={16} />
          {uploading ? `جاري الرفع... ${progress}%` : "إضافة صور للإعلان"}
        </button>
      )}

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={handleFileChange}
      />
    </div>
  );
}

/* ─── Photo Gallery Modal ───────────────────────────────────────── */
function PhotoGalleryModal({ card, cardId: cardIdProp, readOnly, onClose }: {
  card?: SavedCard;
  cardId?: string;
  readOnly?: boolean;
  onClose: () => void;
}) {
  const resolvedCardId = cardIdProp ?? card?.id ?? "";
  const [photos, setPhotos]     = useState<Photo[]>([]);
  const [loading, setLoading]   = useState(true);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress]   = useState(0);
  const [err, setErr]           = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!resolvedCardId) return;
    (async () => {
      try {
        const rows = await fetchPhotos(resolvedCardId);
        setPhotos(rows);
      } catch { setErr("تعذّر جلب الصور"); }
      finally { setLoading(false); }
    })();
  }, [resolvedCardId]);

  const handleFileChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (photos.length >= 10) { setErr("الحد الأقصى 10 صور لكل بطاقة"); return; }
    if (!file.type.startsWith("image/")) { setErr("يُقبل ملفات الصور فقط"); return; }
    setErr(""); setUploading(true); setProgress(0);
    try {
      // 1. Get presigned URL
      const { uploadURL, objectPath } = await requestUploadUrl(file);
      // 2. Upload directly to GCS with XHR to track progress
      await new Promise<void>((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open("PUT", uploadURL);
        xhr.setRequestHeader("Content-Type", file.type);
        xhr.upload.onprogress = (ev) => {
          if (ev.lengthComputable) setProgress(Math.round(ev.loaded / ev.total * 100));
        };
        xhr.onload  = () => xhr.status < 300 ? resolve() : reject(new Error(`HTTP ${xhr.status}`));
        xhr.onerror = () => reject(new Error("Upload failed"));
        xhr.send(file);
      });
      // 3. Register in DB
      const photo = await postPhoto(resolvedCardId, objectPath);
      setPhotos(prev => [...prev, photo]);
      setProgress(100);
    } catch (ex) {
      setErr(ex instanceof Error ? ex.message : "فشل رفع الصورة");
    } finally {
      setUploading(false);
      setProgress(0);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const handleDelete = async (photo: Photo) => {
    if (!confirm("حذف هذه الصورة؟")) return;
    try {
      await deletePhotoApi(resolvedCardId, photo.id);
      setPhotos(prev => prev.filter(p => p.id !== photo.id));
    } catch { setErr("تعذّر حذف الصورة"); }
  };

  const [viewPhoto, setViewPhoto] = useState<Photo | null>(null);

  return (
    <div className="fixed inset-0 z-50 flex flex-col" dir="rtl"
      style={{ background: `linear-gradient(145deg,${G_DARK} 0%,#0f2f15 100%)`, fontFamily: FONT }}>
      {/* Header */}
      <div className="flex items-center justify-between px-4 pt-6 pb-3 shrink-0">
        <div className="flex items-center gap-3">
          <button onClick={onClose} className="p-2 rounded-full active:scale-90"
            style={{ background: "rgba(255,255,255,0.1)", color: CREAM }}>
            <ChevronRight size={22} />
          </button>
          <div>
            <p className="font-black text-base" style={{ color: AU_TEXT }}>معرض الصور</p>
            <p className="text-xs" style={{ color: CREAM_D }}>
              {card ? `بطاقة #${card.cardNum} · ${card.data.projectName}` : "صور الإعلان"}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs px-2 py-1 rounded-lg" style={{ background: "rgba(255,255,255,0.1)", color: CREAM_D }}>
            {photos.length}/10
          </span>
          {!readOnly && (
            <button
              disabled={uploading || photos.length >= 10}
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl font-bold text-sm active:scale-95 disabled:opacity-40"
              style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK }}>
              <Camera size={16} /> إضافة
            </button>
          )}
        </div>
      </div>

      {/* Progress bar */}
      {uploading && (
        <div className="mx-4 mb-2 rounded-full overflow-hidden h-1.5" style={{ background: "rgba(255,255,255,0.1)" }}>
          <div className="h-full rounded-full transition-all" style={{ width: `${progress}%`, background: AU_BRT }} />
        </div>
      )}

      {/* Error */}
      {err && (
        <div className="mx-4 mb-2 rounded-xl px-4 py-2 text-sm text-center text-red-400 bg-red-900/20">{err}</div>
      )}

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 pb-8">
        {loading ? (
          <div className="flex flex-col items-center justify-center h-48 gap-3">
            <div className="w-10 h-10 border-4 border-t-transparent rounded-full animate-spin"
              style={{ borderColor: `${AU_DEEP} transparent ${AU_DEEP} ${AU_DEEP}` }} />
            <p className="text-sm" style={{ color: CREAM_D }}>جاري التحميل...</p>
          </div>
        ) : photos.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 gap-3 opacity-60">
            <ImageDown size={48} style={{ color: AU_DEEP }} />
            <p className="text-sm" style={{ color: CREAM_D }}>لا توجد صور بعد</p>
            <p className="text-xs" style={{ color: CREAM_D }}>اضغط "إضافة" لرفع صورة</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3 mt-2">
            {photos.map(photo => (
              <div key={photo.id} className="relative rounded-2xl overflow-hidden group"
                style={{ aspectRatio: "4/3", background: "rgba(255,255,255,0.05)", border: BORDER }}>
                <img
                  src={`${API}/storage${photo.objectPath}`}
                  alt="صورة"
                  className="w-full h-full object-cover cursor-pointer active:scale-95 transition-transform"
                  onClick={() => setViewPhoto(photo)}
                />
                {!readOnly && (
                  <button
                    onClick={() => handleDelete(photo)}
                    className="absolute top-2 left-2 w-8 h-8 rounded-full flex items-center justify-center active:scale-90 shadow-lg"
                    style={{ background: "rgba(239,68,68,0.85)" }}>
                    <X size={14} style={{ color: "#fff" }} />
                  </button>
                )}
                <div className="absolute bottom-0 inset-x-0 px-2 py-1"
                  style={{ background: "linear-gradient(to top,rgba(0,0,0,0.55),transparent)" }}>
                  <p className="text-xs" style={{ color: "rgba(255,255,255,0.7)" }}>
                    {new Date(photo.uploadedAt).toLocaleDateString("ar-SA")}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Full-screen photo viewer */}
      {viewPhoto && (
        <div className="fixed inset-0 z-60 flex items-center justify-center"
          style={{ background: "rgba(0,0,0,0.92)" }}
          onClick={() => setViewPhoto(null)}>
          <img
            src={`${API}/storage${viewPhoto.objectPath}`}
            alt="صورة"
            className="max-w-full max-h-full object-contain rounded-2xl"
            style={{ maxHeight: "90vh", maxWidth: "95vw" }}
            onClick={e => e.stopPropagation()}
          />
          <button className="absolute top-4 right-4 w-10 h-10 rounded-full flex items-center justify-center"
            style={{ background: "rgba(255,255,255,0.15)" }}
            onClick={() => setViewPhoto(null)}>
            <X size={20} style={{ color: "#fff" }} />
          </button>
        </div>
      )}

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleFileChange}
      />
    </div>
  );
}

/* ─── Photo Share Modal ──────────────────────────────────────────── */
function PhotoShareModal({ cards, onClose }: { cards: SavedCard[]; onClose: () => void }) {
  type PhotoEntry = { cardTitle: string; url: string; key: string };
  const [allPhotos, setAllPhotos] = useState<PhotoEntry[]>([]);
  const [selected, setSelected]   = useState<Set<string>>(new Set());
  const [loading, setLoading]     = useState(true);
  const [sharing, setSharing]     = useState(false);
  const [msg, setMsg]             = useState("");

  /* Fetch photos for all cards in parallel */
  useEffect(() => {
    (async () => {
      const entries: PhotoEntry[] = [];
      await Promise.all(cards.map(async card => {
        if (!card.id) return;
        try {
          const ps = await fetchPhotos(card.id);
          ps.forEach(p => {
            const url = photoUrl(p);
            entries.push({ cardTitle: card.data.projectName, url, key: `${card.id}_${p.id}` });
          });
        } catch { /* skip */ }
      }));
      setAllPhotos(entries);
      setSelected(new Set(entries.map(e => e.key)));
      setLoading(false);
    })();
  }, []);

  const toggle = (key: string) => setSelected(prev => {
    const n = new Set(prev);
    n.has(key) ? n.delete(key) : n.add(key);
    return n;
  });
  const toggleAll = () => setSelected(
    selected.size === allPhotos.length ? new Set() : new Set(allPhotos.map(e => e.key))
  );

  const doShare = async () => {
    const toShare = allPhotos.filter(e => selected.has(e.key));
    if (!toShare.length) { setMsg("اختر صورة واحدة على الأقل"); return; }
    setSharing(true); setMsg("جاري تجهيز الصور...");
    try {
      const files: File[] = await Promise.all(toShare.map(async (e, i) => {
        const res  = await fetch(e.url);
        const blob = await res.blob();
        const ext  = blob.type.includes("png") ? "png" : "jpg";
        return new File([blob], `${e.cardTitle}_${i + 1}.${ext}`, { type: blob.type });
      }));

      if (navigator.canShare?.({ files })) {
        await navigator.share({ files });
        setMsg(""); onClose();
      } else {
        /* Fallback: download each file */
        files.forEach((file, i) => {
          const a = document.createElement("a");
          a.href = URL.createObjectURL(file);
          a.download = file.name;
          a.click();
          setTimeout(() => URL.revokeObjectURL(a.href), 5000);
        });
        setMsg(`تم تنزيل ${files.length} صورة`);
      }
    } catch (e: unknown) {
      if (e instanceof Error && e.name !== "AbortError") setMsg("تعذّرت المشاركة");
    } finally { setSharing(false); }
  };

  return (
    <div className="fixed inset-0 z-[60] flex flex-col" dir="rtl"
      style={{ background: `linear-gradient(145deg,${G_DARK},#0a1f0d)`, fontFamily: FONT }}>

      {/* Header */}
      <div className="flex items-center justify-between px-4 pt-6 pb-3 shrink-0"
        style={{ borderBottom: BORDER }}>
        <button onClick={onClose}
          className="flex items-center gap-2 px-3 py-2 rounded-xl font-bold text-sm active:scale-95"
          style={{ background: "rgba(255,255,255,0.1)", color: CREAM }}>
          <X size={16} /> إغلاق
        </button>
        <h2 className="font-black text-base" style={{ color: AU_TEXT }}>
          اختر الصور للمشاركة
        </h2>
        <button onClick={toggleAll}
          className="text-xs px-3 py-2 rounded-xl active:scale-95 font-bold"
          style={{ background: "rgba(255,255,255,0.08)", color: CREAM_D }}>
          {selected.size === allPhotos.length ? "إلغاء الكل" : "تحديد الكل"}
        </button>
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto px-3 py-3">
        {loading ? (
          <div className="flex items-center justify-center h-40 gap-3">
            <div className="w-5 h-5 rounded-full border-2 border-t-transparent animate-spin"
              style={{ borderColor: AU_BRT, borderTopColor: "transparent" }} />
            <span className="text-sm" style={{ color: CREAM_D }}>جاري تحميل الصور...</span>
          </div>
        ) : allPhotos.length === 0 ? (
          <div className="flex items-center justify-center h-40">
            <p className="text-sm" style={{ color: CREAM_D }}>لا توجد صور في البطاقات المختارة</p>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-2">
            {allPhotos.map(e => {
              const isSel = selected.has(e.key);
              return (
                <button key={e.key} onClick={() => toggle(e.key)}
                  className="relative rounded-xl overflow-hidden active:scale-95 transition-transform aspect-square"
                  style={{ border: isSel ? `2.5px solid ${AU_BRT}` : "2.5px solid transparent" }}>
                  <img src={e.url} alt="" className="w-full h-full object-cover" loading="eager" />
                  {/* Selection overlay */}
                  <div className="absolute inset-0 flex items-center justify-center"
                    style={{ background: isSel ? "rgba(0,0,0,0.25)" : "rgba(0,0,0,0.5)" }}>
                    <div className="w-6 h-6 rounded-full flex items-center justify-center"
                      style={{ background: isSel ? AU_BRT : "rgba(255,255,255,0.25)", border: `2px solid ${isSel ? AU_BRT : "rgba(255,255,255,0.5)"}` }}>
                      {isSel && <Check size={14} style={{ color: G_DARK }} />}
                    </div>
                  </div>
                  {/* Card title chip */}
                  <div className="absolute bottom-0 right-0 left-0 px-1.5 py-0.5 text-center"
                    style={{ background: "rgba(0,0,0,0.65)", fontSize: 9, color: CREAM_D }}>
                    {e.cardTitle.length > 12 ? e.cardTitle.slice(0, 12) + "…" : e.cardTitle}
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="shrink-0 px-4 py-4" style={{ borderTop: BORDER }}>
        {msg && <p className="text-xs text-center mb-2" style={{ color: msg.includes("تعذّر") ? "#f87171" : CREAM_D }}>{msg}</p>}
        <button onClick={doShare} disabled={sharing || !selected.size}
          className="w-full py-4 rounded-2xl font-black text-base flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50"
          style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK }}>
          <Share2 size={20} />
          {sharing ? "جاري التجهيز..." : `مشاركة ${selected.size} صورة`}
        </button>
      </div>
    </div>
  );
}

/* ─── Archive View ───────────────────────────────────────────────── */
function ArchiveView({ cards, onLoad, onDelete, onDeleteSelected, onClose, onExportSelected, onSharePhotos, isAdmin = false }: {
  cards: SavedCard[];
  onLoad: (card: SavedCard) => void;
  onDelete: (id: string) => void;
  onDeleteSelected: (ids: string[]) => Promise<void>;
  onClose: () => void;
  onExportSelected: (cards: SavedCard[]) => void;
  onSharePhotos: (cards: SavedCard[]) => void;
  isAdmin?: boolean;
}) {
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [galleryCard, setGalleryCard] = useState<SavedCard | null>(null);
  const [deleting, setDeleting] = useState(false);

  const filtered = cards.filter(c =>
    c.region.includes(query) ||
    c.data.projectName.includes(query) ||
    c.owner.includes(query) ||
    String(c.cardNum).includes(query)
  ).sort((a, b) => b.cardNum - a.cardNum);

  const grouped: Record<string, SavedCard[]> = {};
  filtered.forEach(c => {
    const key = c.region || "غير محدد";
    if (!grouped[key]) grouped[key] = [];
    grouped[key].push(c);
  });

  const toggleCard = (id: string) => {
    setSelected(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const toggleRegion = (regionCards: SavedCard[]) => {
    const ids = regionCards.map(c => c.id);
    const allSelected = ids.every(id => selected.has(id));
    setSelected(prev => {
      const next = new Set(prev);
      ids.forEach(id => allSelected ? next.delete(id) : next.add(id));
      return next;
    });
  };

  const selectedCards = cards.filter(c => selected.has(c.id));

  return (
    <div className="min-h-screen flex flex-col" dir="rtl"
      style={{ background: `linear-gradient(145deg,${G_DARK} 0%,${G_MID} 50%,${G_DARK} 100%)`, fontFamily: FONT }}>

      {/* Header */}
      <div className="flex items-center gap-3 px-4 pt-6 pb-4">
        <button onClick={onClose} className="p-2 rounded-full active:scale-90"
          style={{ background: "rgba(255,255,255,0.1)", color: CREAM }}>
          <ChevronRight size={22} />
        </button>
        <h1 className="font-black text-xl" style={{ color: AU_TEXT }}>أرشيف البطاقات</h1>
        <span className="text-xs px-2 py-1 rounded-full" style={{ background: "rgba(201,162,39,0.2)", color: CREAM_D }}>
          {cards.length} بطاقة
        </span>
      </div>

      {/* Search */}
      <div className="px-4 mb-3">
        <div className="flex items-center gap-2 rounded-xl px-4 py-3"
          style={{ background: "rgba(255,255,255,0.1)", border: BORDER }}>
          <Search size={18} style={{ color: CREAM_D }} />
          <input value={query} onChange={e => setQuery(e.target.value)}
            placeholder="ابحث برقم البطاقة أو المنطقة أو الاسم..." dir="rtl"
            className="flex-1 bg-transparent outline-none text-base"
            style={{ color: CREAM, fontFamily: FONT }} />
          {query && <button onClick={() => setQuery("")}><X size={16} style={{ color: CREAM_D }} /></button>}
        </div>
      </div>

      {/* Selection hint + select all */}
      {cards.length > 0 && (
        <div className="px-4 mb-2 flex items-center justify-between gap-2">
          {selected.size === 0 && (
            <p className="text-xs" style={{ color: CREAM_D }}>
              اضغط على ☑ لتحديد بطاقات وتصديرها دفعة واحدة
            </p>
          )}
          {selected.size > 0 && (
            <p className="text-xs font-bold" style={{ color: AU_TEXT }}>
              {selected.size} بطاقة محددة
            </p>
          )}
          <button
            onClick={() => {
              const allIds = filtered.map(c => c.id);
              const allSel = allIds.every(id => selected.has(id));
              if (allSel) { setSelected(new Set()); }
              else { setSelected(new Set(allIds)); }
            }}
            className="shrink-0 px-3 py-1.5 rounded-xl font-bold text-xs active:scale-95"
            style={{ background: "rgba(201,162,39,0.2)", color: AU_TEXT, border: `1px solid ${AU_DEEP}55` }}>
            {filtered.length > 0 && filtered.every(c => selected.has(c.id)) ? "إلغاء الكل" : "تحديد الكل"}
          </button>
        </div>
      )}

      {/* Results */}
      <div className="flex-1 overflow-y-auto px-4 pb-32 space-y-5">
        {Object.keys(grouped).length === 0 && (
          <div className="text-center mt-20" style={{ color: CREAM_D }}>
            <Archive size={48} className="mx-auto mb-3 opacity-40" />
            <p className="text-base">{query ? "لا توجد نتائج" : "الأرشيف فارغ"}</p>
          </div>
        )}

        {Object.entries(grouped).map(([region, regionCards]) => {
          const allRegionSelected = regionCards.every(c => selected.has(c.id));
          return (
            <div key={region}>
              {/* Region header with select-all toggle */}
              <div className="flex items-center gap-2 mb-2">
                <div className="h-px flex-1" style={{ background: `linear-gradient(90deg,${AU_DEEP},transparent)` }} />
                <button
                  onClick={() => toggleRegion(regionCards)}
                  className="flex items-center gap-2 text-sm font-bold px-3 py-1 rounded-full active:scale-95"
                  style={{ background: allRegionSelected ? `rgba(201,162,39,0.35)` : "rgba(201,162,39,0.15)", color: AU_TEXT }}>
                  {allRegionSelected
                    ? <CheckSquare size={14} />
                    : <Square size={14} />}
                  📍 {region}
                </button>
                <span className="text-xs" style={{ color: CREAM_D }}>{regionCards.length}</span>
              </div>

              {/* Cards */}
              <div className="space-y-2">
                {regionCards.map(card => {
                  const isSelected = selected.has(card.id);
                  return (
                    <div key={card.id} className="rounded-xl overflow-hidden transition-all"
                      style={{
                        background: isSelected ? "rgba(201,162,39,0.15)" : "rgba(255,255,255,0.06)",
                        border: isSelected ? `2px solid ${AU_MID}` : BORDER,
                      }}>
                      <div className="flex items-center gap-2 px-3 py-3">
                        {/* Checkbox */}
                        <button onClick={() => toggleCard(card.id)} className="shrink-0 active:scale-90">
                          {isSelected
                            ? <CheckSquare size={22} style={{ color: AU_BRT }} />
                            : <Square size={22} style={{ color: CREAM_D }} />}
                        </button>

                        {/* Card number badge */}
                        <div className="shrink-0 w-10 h-10 rounded-xl flex flex-col items-center justify-center"
                          style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})` }}>
                          <span className="text-xs font-black leading-none" style={{ color: G_DARK }}>
                            #{card.cardNum}
                          </span>
                        </div>

                        {/* Info */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <p className="font-bold text-base truncate" style={{ color: CREAM }}>
                              {card.data.projectName}
                            </p>
                            {card.companyName && (
                              <span className="text-xs px-1.5 py-0.5 rounded-md font-bold shrink-0 flex items-center gap-0.5"
                                style={{ background: "rgba(37,99,168,0.2)", color: "#93c5fd", border: "1px solid #2563a844" }}>
                                <Building2 size={9}/> {card.companyName}
                              </span>
                            )}
                          </div>
                          {card.owner && (
                            <p className="text-xs mt-0.5 flex items-center gap-1 flex-wrap" style={{ color: AU_TEXT }}>
                              <User size={10} /> {card.owner}
                              {card.guestPhone && (
                                <span className="font-black tracking-wide" style={{ color: AU_BRT, direction: "ltr" }}>
                                  · {card.guestPhone}
                                </span>
                              )}
                            </p>
                          )}
                          {/* Owner contact — admin only */}
                          {isAdmin && card.ownerContact && (() => {
                            const lines = card.ownerContact.split("\n");
                            const parse = (pfx: string) => lines.find(l => l.startsWith(pfx))?.slice(pfx.length).trim() ?? "";
                            const oName  = parse("اسم: ");
                            const oPhone = parse("هاتف: ");
                            const oLoc   = parse("موقع: ");
                            const isStructured = lines.some(l => l.startsWith("اسم:"));
                            return (
                              <div className="mt-1 rounded-lg px-2 py-1.5 flex flex-col gap-0.5"
                                style={{ background: "rgba(184,145,42,0.15)", border: `1px solid ${AU_DEEP}66` }}>
                                <div className="flex items-center gap-1">
                                  <Lock size={9} style={{ color: AU_TEXT }} />
                                  <span className="text-xs font-bold" style={{ color: AU_TEXT }}>صاحب المشروع</span>
                                </div>
                                {isStructured ? (
                                  <>
                                    {oName  && <p className="text-xs" style={{ color: CREAM }}>👤 {oName}</p>}
                                    {oPhone && <a href={`tel:${oPhone}`} className="text-xs font-bold" style={{ color: "#7dd3fc", direction: "ltr" }}>📞 {oPhone}</a>}
                                    {oLoc   && <a href={oLoc} target="_blank" rel="noopener noreferrer" className="text-xs underline" style={{ color: "#86efac" }}>📍 فتح الموقع</a>}
                                  </>
                                ) : (
                                  <p className="text-xs" style={{ color: AU_TEXT }}>{card.ownerContact}</p>
                                )}
                              </div>
                            );
                          })()}
                          <p className="text-xs mt-0.5" style={{ color: CREAM_D }}>
                            {new Date(card.savedAt).toLocaleDateString("ar-SA")}
                          </p>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-2 shrink-0">
                          <button onClick={() => onLoad(card)}
                            className="px-3 py-2 rounded-lg text-sm font-bold active:scale-95"
                            style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK }}>
                            تحميل
                          </button>
                          <button onClick={() => setGalleryCard(card)}
                            className="p-2 rounded-lg active:scale-95"
                            style={{ background: "rgba(201,162,39,0.15)", color: AU_TEXT }}>
                            <Camera size={15} />
                          </button>
                          <button onClick={() => { if (confirm("حذف هذه البطاقة؟")) onDelete(card.id); }}
                            className="p-2 rounded-lg active:scale-95"
                            style={{ background: "rgba(239,68,68,0.15)", color: "#f87171" }}>
                            <Trash2 size={15} />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {/* Floating action bar — shows when items are selected */}
      {selected.size > 0 && (
        <div className="fixed bottom-0 right-0 left-0 px-4 py-4 flex flex-col gap-2"
          style={{ background: `linear-gradient(0deg,${G_DARK},${G_DARK}ee)`, borderTop: BORDER }}>
          <div className="flex gap-2">
            <button
              onClick={() => onExportSelected(selectedCards)}
              className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-2xl font-black text-base active:scale-95 shadow-xl"
              style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK }}>
              <ImageDown size={18} />
              تصدير ({selected.size})
            </button>
            <button
              disabled={deleting}
              onClick={async () => {
                if (!confirm(`هل أنت متأكد من مسح ${selected.size} بطاقة؟ لا يمكن التراجع عن هذا الإجراء.`)) return;
                setDeleting(true);
                try {
                  await onDeleteSelected([...selected]);
                  setSelected(new Set());
                } finally {
                  setDeleting(false);
                }
              }}
              className="flex items-center justify-center gap-2 px-4 py-3.5 rounded-2xl font-black text-base active:scale-95"
              style={{ background: deleting ? "rgba(239,68,68,0.1)" : "rgba(239,68,68,0.25)",
                       color: "#f87171", border: "1px solid rgba(239,68,68,0.4)",
                       opacity: deleting ? 0.6 : 1 }}>
              {deleting
                ? <div className="w-5 h-5 border-2 border-t-transparent rounded-full animate-spin" style={{ borderColor: "#f87171 transparent #f87171 #f87171" }} />
                : <Trash2 size={18} />}
            </button>
            <button onClick={() => setSelected(new Set())}
              className="px-4 py-3.5 rounded-2xl font-bold active:scale-95"
              style={{ background: "rgba(255,255,255,0.08)", color: CREAM_D, border: BORDER }}>
              <X size={18} />
            </button>
          </div>
          {selected.size > 0 && (
            <p className="text-center text-xs" style={{ color: CREAM_D }}>
              {selected.size} بطاقة محددة — اضغط على 🗑 للمسح
            </p>
          )}
        </div>
      )}

      {/* Photo gallery overlay */}
      {galleryCard && (
        <PhotoGalleryModal card={galleryCard} onClose={() => setGalleryCard(null)} />
      )}
    </div>
  );
}

/* ─── Main ───────────────────────────────────────────────────────── */
export default function Home() {
  const cardRef    = useRef<HTMLDivElement>(null);
  const [exporting, setExporting] = useState(false);
  const logoDataUrl = useBase64Image(logoSrc);

  /* ── Role / Auth ── */
  const [role, setRole] = useState<Role | null>(null);
  const [loggedEmployee, setLoggedEmployee] = useState<{ id: string; name: string } | null>(null);
  const [guestProfile, setGuestProfile] = useState<GuestProfile | undefined>(undefined);
  const [companyProfile, setCompanyProfile] = useState<CompanyProfile | undefined>(undefined);
  const [employees, setEmployeesState] = useState<Employee[]>([]);
  const [appLoading, setAppLoading]   = useState(true);
  const [appErr, setAppErr]           = useState("");
  const [pendingCount, setPendingCount] = useState(0);
  const [saveErr, setSaveErr]          = useState("");

  const [view, setView]               = useState<"editor" | "archive" | "employees" | "submissions" | "companies" | "featured">("editor");
  const [featuredPendingCount, setFeaturedPendingCount] = useState(0);
  const [savedCards, setSavedCards]   = useState<SavedCard[]>([]);
  const [region, setRegion]           = useState("");
  const [owner, setOwner]             = useState("");
  const [saveFlash, setSaveFlash]     = useState(false);
  const [currentCardId, setCurrentCardId] = useState<string | null>(null);
  const [currentCardNum, setCurrentCardNum] = useState<number | null>(null);

  /* Batch export state */
  const [batchRunning, setBatchRunning]       = useState(false);
  const [batchQueue, setBatchQueue]           = useState<SavedCard[]>([]);
  const [batchIndex, setBatchIndex]           = useState(-1);
  const isBatching = batchRunning;

  /* Gallery shown after batch capture */
  const [batchGallery, setBatchGallery] = useState<{ name: string; url: string }[]>([]);

  /* Photo share modal state */
  const [photoShareCards, setPhotoShareCards] = useState<SavedCard[] | null>(null);

  const [modal, setModal] = useState<{
    label: string; value: string; multiline?: boolean; onSave: (v: string) => void;
  } | null>(null);

  const edit = (label: string, value: string, onSave: (v: string) => void, multiline?: boolean) =>
    setModal({ label, value, onSave, multiline });

  const [data, setData] = useState<CardData>(DEFAULT_DATA);
  const set = (k: keyof CardData, v: string) => setData(p => ({ ...p, [k]: v }));
  const setFloor = (id: number, k: keyof Floor, v: string) =>
    setData(p => ({ ...p, floors: p.floors.map(f => f.id === id ? { ...f, [k]: v } : f) }));
  const delFloor = (id: number) =>
    setData(p => ({ ...p, floors: p.floors.filter(f => f.id !== id) }));
  const addFloor = () =>
    setData(p => ({ ...p, floors: [...p.floors, { id: nextId++, name: "اسم الطابق", area: "م²", price: "ألف" }] }));

  /* ── App init ── */
  useEffect(() => {
    let destroyed = false;
    (async () => {
      try {
        await setupAdminIfNeeded();
        const [cards, emps, subs] = await Promise.all([fetchArchive(), fetchEmployees(), fetchSubmissions()]);
        if (destroyed) return;
        /* Convert approved company submissions → SavedCard for archive display */
        const companyCards: SavedCard[] = subs
          .filter(s => s.submittedBy === "company" && s.status === "approved" && !cards.some(c => c.id === `sub_${s.id}`))
          .map(s => ({
            id: `sub_${s.id}`,
            savedAt: s.submittedAt,
            region: s.region || s.cardRegion || "",
            owner: s.companyName || s.contactName || "",
            data: s.cardData ?? submissionToCardData(s),
            cardNum: s.cardNum ?? 0,
            ownerContact: s.ownerContact,
            companyName: s.companyName,
          }));
        setSavedCards([...cards, ...companyCards]);
        setEmployeesState(emps);
        setPendingCount(subs.filter(s => s.status === "pending").length);
        fetchFeaturedAds().then(fa => setFeaturedPendingCount(fa.filter(a => a.status === "pending").length)).catch(() => {});
        /* Auto-login guest if profile saved from previous session */
        try {
          const saved = localStorage.getItem("guestProfile");
          if (saved) {
            const gp = JSON.parse(saved) as GuestProfile;
            if (gp?.name && gp?.phone) {
              setRole("guest");
              setGuestProfile(gp);
            }
          }
        } catch { /* ignore */ }
      } catch {
        if (!destroyed)
          setAppErr("تعذّر الاتصال بالسيرفر، تأكد من الاتصال وأعد التحميل");
      } finally {
        if (!destroyed) setAppLoading(false);
      }
    })();
    return () => { destroyed = true; };
  }, []);

  /* ── Guest view: refresh cards + submissions every 60 s ── */
  useEffect(() => {
    if (role !== "guest") return;
    const id = setInterval(async () => {
      try {
        const [fresh, subs] = await Promise.all([fetchArchive(), fetchSubmissions()]);
        const companyCards: SavedCard[] = subs
          .filter(s => s.submittedBy === "company" && s.status === "approved" && !fresh.some(c => c.id === `sub_${s.id}`))
          .map(s => ({
            id: `sub_${s.id}`, savedAt: s.submittedAt,
            region: s.region || s.cardRegion || "",
            owner: s.companyName || s.contactName || "",
            data: s.cardData ?? submissionToCardData(s),
            cardNum: s.cardNum ?? 0,
            ownerContact: s.ownerContact,
            companyName: s.companyName,
          }));
        setSavedCards([...fresh, ...companyCards]);
      } catch { /* silent — keep stale data */ }
    }, 60_000);
    return () => clearInterval(id);
  }, [role]);

  /* ── Live notification polling — refreshes pending count every 30 s ── */
  const prevFeaturedCountRef = useRef(0);
  useEffect(() => {
    if (appLoading) return;
    /* Request browser notification permission on first load (admin only)
       Guard with typeof — iOS Safari < 16.4 does NOT support Notification API */
    if (typeof Notification !== "undefined" && Notification.permission === "default") {
      Notification.requestPermission().catch(() => {});
    }
    const tick = async () => {
      try {
        const [subs, fa] = await Promise.all([fetchSubmissions(), fetchFeaturedAds()]);
        setPendingCount(subs.filter(s => s.status === "pending").length);
        const newFeaturedCount = fa.filter(a => a.status === "pending").length;
        /* Send browser notification when a new paid ad request arrives */
        if (
          typeof Notification !== "undefined" &&
          newFeaturedCount > prevFeaturedCountRef.current &&
          Notification.permission === "granted"
        ) {
          new Notification("إعلان مميز جديد!", {
            body: `يوجد ${newFeaturedCount} طلب إعلان مدفوع ينتظر موافقتك`,
            icon: "/icons/icon-192.png",
          });
        }
        prevFeaturedCountRef.current = newFeaturedCount;
        setFeaturedPendingCount(newFeaturedCount);
      } catch { /* silent — keep last known count */ }
    };
    tick(); /* immediate first check */
    const id = setInterval(tick, 30_000);
    return () => clearInterval(id);
  }, [appLoading]);

  /* ── Next card number ── */
  const nextCardNum = (cards: SavedCard[]) =>
    cards.length === 0 ? 1 : Math.max(...cards.map(c => c.cardNum ?? 0)) + 1;

  /* ── Save ── */
  const saveCard = async () => {
    setSaveErr("");
    try {
      let updated: SavedCard[];
      if (currentCardId) {
        const exists = savedCards.find(c => c.id === currentCardId);
        if (exists) {
          const card = { ...exists, savedAt: Date.now(), region, owner, data };
          await postCard(card);
          updated = savedCards.map(c => c.id === currentCardId ? card : c);
        } else {
          const num = currentCardNum ?? nextCardNum(savedCards);
          const card: SavedCard = { id: currentCardId, cardNum: num, savedAt: Date.now(), region, owner, data };
          await postCard(card);
          updated = [...savedCards, card];
        }
      } else {
        const newId = `${Date.now()}_${Math.random().toString(36).slice(2)}`;
        const num = nextCardNum(savedCards);
        const card: SavedCard = { id: newId, cardNum: num, savedAt: Date.now(), region, owner, data };
        await postCard(card);
        updated = [...savedCards, card];
        setCurrentCardId(newId);
        setCurrentCardNum(num);
      }
      setSavedCards(updated);
      setSaveFlash(true);
      setTimeout(() => setSaveFlash(false), 1500);
    } catch {
      setSaveErr("تعذّر حفظ البطاقة، تحقق من الاتصال بالسيرفر");
    }
  };

  /* ── Load ── */
  const loadCard = (card: SavedCard) => {
    setData(card.data);
    setRegion(card.region);
    setOwner(card.owner);
    setCurrentCardId(card.id);
    setCurrentCardNum(card.cardNum);
    setView("editor");
  };

  /* ── Delete ── */
  const deleteCard = async (id: string) => {
    try {
      await deleteCardApi(id);
      setSavedCards(prev => prev.filter(c => c.id !== id));
      if (currentCardId === id) { setCurrentCardId(null); setCurrentCardNum(null); }
    } catch {
      setSaveErr("تعذّر حذف البطاقة، تحقق من الاتصال بالسيرفر");
    }
  };

  const deleteCardsSelected = async (ids: string[]) => {
    await Promise.allSettled(ids.map(id => deleteCardApi(id)));
    setSavedCards(prev => prev.filter(c => !ids.includes(c.id)));
    if (currentCardId && ids.includes(currentCardId)) { setCurrentCardId(null); setCurrentCardNum(null); }
  };

  /* ── New card ── */
  const newCard = () => {
    setData({ ...DEFAULT_DATA, floors: DEFAULT_DATA.floors.map(f => ({ ...f })) });
    setRegion("");
    setOwner("");
    setCurrentCardId(null);
    setCurrentCardNum(null);
  };

  /* ── Capture a card element as a File blob ── */
  const captureFromRef = async (ref: React.RefObject<HTMLDivElement | null>, filename: string): Promise<File | null> => {
    if (!ref.current) return null;
    const filter = (node: HTMLElement) =>
      !(node instanceof HTMLElement && node.dataset.exportHide === "true");
    try {
      await toPng(ref.current, { quality: 1, pixelRatio: 3, cacheBust: true, filter });
      const dataUrl = await toPng(ref.current, { quality: 1, pixelRatio: 3, cacheBust: true, filter });
      const res = await fetch(dataUrl);
      const blob = await res.blob();
      return new File([blob], `${filename}.png`, { type: "image/png" });
    } catch { return null; }
  };
  const captureCard = (filename: string) => captureFromRef(cardRef, filename);

  /* ── Share or download files ── */
  const shareOrDownload = async (files: File[]) => {
    if (!files.length) return;
    const canShare = "share" in navigator &&
      "canShare" in navigator &&
      (navigator as any).canShare({ files });
    if (canShare) {
      try {
        await (navigator as any).share({ files, title: "بطاقات عقارية" });
        return;
      } catch { /* user cancelled or error — fallback below */ }
    }
    // Fallback: download one by one
    for (const file of files) {
      const url = URL.createObjectURL(file);
      const a = document.createElement("a");
      a.href = url; a.download = file.name; a.click();
      URL.revokeObjectURL(url);
      await new Promise(r => setTimeout(r, 600));
    }
  };

  /* ── Single export ── */
  const exportImage = async () => {
    if (!cardRef.current) return;
    setExporting(true);
    try {
      const file = await captureCard(data.projectName);
      if (file) await shareOrDownload([file]);
    } finally { setExporting(false); }
  };

  /* ── Batch export: render each card in a fresh DOM node via createRoot ── */
  const startBatchExport = async (exportCards: SavedCard[]) => {
    if (!exportCards.length) return;
    setBatchRunning(true);
    setBatchQueue(exportCards);
    setBatchIndex(0);

    const blobs: { name: string; url: string }[] = [];

    for (let i = 0; i < exportCards.length; i++) {
      setBatchIndex(i);
      const card = exportCards[i];

      // Create isolated container — completely independent of React render cycle
      const container = document.createElement("div");
      container.style.cssText = "position:fixed;left:-9999px;top:0;width:384px;z-index:-1;";
      document.body.appendChild(container);

      const root = createRoot(container);
      await new Promise<void>(resolve => {
        root.render(
          createElement(CardPreview, {
            data: card.data,
            logoUrl: logoDataUrl,
            cardNum: card.cardNum ?? undefined,
          })
        );
        // Give time for fonts & images to render
        setTimeout(resolve, 900);
      });

      // Capture the rendered card
      const el = container.firstElementChild as HTMLElement | null;
      if (el) {
        try {
          // Two-pass to warm up font/image cache
          await toPng(el, { quality: 1, pixelRatio: 3, cacheBust: true });
          const dataUrl = await toPng(el, { quality: 1, pixelRatio: 3, cacheBust: true });
          blobs.push({ name: `${card.data.projectName}.png`, url: dataUrl });
        } catch { /* skip failed card */ }
      }

      root.unmount();
      container.remove();
    }

    setBatchRunning(false);
    setBatchQueue([]);
    setBatchIndex(-1);
    if (blobs.length > 0) setBatchGallery(blobs);
  };

  /* ══ App loading / error gates ══ */
  if (appLoading) return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-4" dir="rtl"
      style={{ background: `linear-gradient(145deg,${G_DARK},${G_MID})`, fontFamily: FONT }}>
      <div className="w-14 h-14 border-4 border-t-transparent rounded-full animate-spin"
        style={{ borderColor: `${AU_DEEP} transparent ${AU_DEEP} ${AU_DEEP}` }} />
      <p className="font-bold text-lg" style={{ color: AU_TEXT }}>جاري التحميل...</p>
    </div>
  );
  if (appErr) return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-4 px-6 text-center" dir="rtl"
      style={{ background: `linear-gradient(145deg,${G_DARK},${G_MID})`, fontFamily: FONT }}>
      <p className="font-bold text-lg text-red-400">{appErr}</p>
      <button onClick={() => window.location.reload()}
        className="px-6 py-3 rounded-2xl font-bold"
        style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK }}>
        إعادة المحاولة
      </button>
    </div>
  );

  /* ══ Role gates ══ */
  if (!role) return <LoginPage
    onLogin={(r, emp, gp, cp) => {
      setRole(r);
      if (emp) setLoggedEmployee(emp);
      if (gp) setGuestProfile(gp);
      if (cp) setCompanyProfile(cp);
    }}
    employees={employees} />;
  if (role === "guest") return <GuestPage cards={savedCards} guestProfile={guestProfile}
    onBack={() => { setRole(null); setLoggedEmployee(null); setGuestProfile(undefined); }} />;
  if (role === "company") return <CompanyPage companyProfile={companyProfile ?? { name: "", phone: "" }}
    onBack={() => { setRole(null); setCompanyProfile(undefined); }} />;
  if (role === "employee") return <EmployeeEditor onLogout={() => { setRole(null); setLoggedEmployee(null); }} savedCards={savedCards} employee={loggedEmployee ?? undefined} />;

  /* ══ Admin-only views ══ */
  if (view === "employees") return <EmployeeManager onClose={() => setView("editor")} />;
  if (view === "submissions") return (
    <SubmissionsView onClose={async () => {
      const fresh = await fetchArchive().catch(() => savedCards);
      const subs  = await fetchSubmissions().catch(() => []);
      setSavedCards(fresh);
      setPendingCount(subs.filter(s => s.status === "pending").length);
      setView("editor");
    }} />
  );

  /* ══ Companies view (admin) ══ */
  if (view === "companies") return <CompanySubmissionsView onClose={() => setView("editor")} />;

  /* ══ Featured ads view (admin) ══ */
  if (view === "featured") return <FeaturedAdsView onClose={() => {
    setView("editor");
    fetchFeaturedAds().then(fa => setFeaturedPendingCount(fa.filter(a => a.status === "pending").length)).catch(() => {});
  }} />;

  /* ══ Archive view ══ */
  if (view === "archive") {
    return (
      <>
        {/* Batch progress overlay */}
        {isBatching && (
          <div className="fixed inset-0 z-50 flex flex-col items-center justify-center pointer-events-none"
            style={{ background: "rgba(0,0,0,0.6)" }}>
            <div className="rounded-2xl p-6 flex flex-col items-center gap-3 text-center"
              style={{ background: G_DARK, border: BORDER, minWidth: "230px" }}>
              <div className="w-12 h-12 rounded-full flex items-center justify-center"
                style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})` }}>
                <Download size={22} style={{ color: G_DARK }} />
              </div>
              <p className="font-black text-base" style={{ color: AU_TEXT }}>
                جاري التصدير...
              </p>
              <p className="text-sm" style={{ color: CREAM_D }}>
                {batchIndex + 1} / {batchQueue.length}
              </p>
            </div>
          </div>
        )}

        {/* Batch gallery overlay — appears after export completes */}
        {batchGallery.length > 0 && (
          <div className="fixed inset-0 z-50 flex flex-col"
            style={{ background: "rgba(0,0,0,0.92)", fontFamily: FONT }}>
            {/* Header */}
            <div className="flex items-center justify-between px-4 py-3 shrink-0"
              style={{ background: G_DARK, borderBottom: BORDER }}>
              <button onClick={() => setBatchGallery([])}
                className="flex items-center gap-2 px-3 py-2 rounded-xl font-bold text-sm active:scale-95"
                style={{ background: "rgba(239,68,68,0.12)", color: "#f87171", border: "1px solid #f8717133" }}>
                <X size={15} /> إغلاق
              </button>
              <p className="font-black text-sm" style={{ color: AU_TEXT }}>
                {batchGallery.length} بطاقة جاهزة
              </p>
              <button
                onClick={async () => {
                  try {
                    const files = await Promise.all(
                      batchGallery.map(async item => {
                        const r = await fetch(item.url);
                        const blob = await r.blob();
                        return new File([blob], item.name, { type: "image/png" });
                      })
                    );
                    if (navigator.share && navigator.canShare?.({ files })) {
                      await navigator.share({ files, title: "بطاقات عقارية" });
                    } else {
                      batchGallery.forEach(item => {
                        const a = document.createElement("a");
                        a.href = item.url; a.download = item.name; a.click();
                      });
                    }
                  } catch { /* user cancelled */ }
                }}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl font-bold text-sm active:scale-95"
                style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK }}>
                <Share2 size={14} /> مشاركة الكل
              </button>
            </div>
            {/* Instructions */}
            <div className="text-center py-2 text-xs px-4 shrink-0" style={{ color: CREAM_D }}>
              اضغط "مشاركة الكل" لإرسال جميع البطاقات دفعة واحدة &nbsp;|&nbsp; أو تنزيل كل بطاقة على حدة
            </div>
            {/* Grid */}
            <div className="flex-1 overflow-y-auto p-3 grid grid-cols-1 gap-4">
              {batchGallery.map((item, idx) => (
                <div key={idx} className="rounded-2xl overflow-hidden"
                  style={{ border: BORDER, background: G_DARK }}>
                  <img src={item.url} alt={item.name}
                    className="w-full block"
                    style={{ maxWidth: "100%", display: "block" }} />
                  <div className="flex items-center justify-between px-3 py-2 gap-2"
                    style={{ borderTop: `1px solid ${AU_DEEP}44` }}>
                    <span className="text-xs truncate" style={{ color: CREAM_D }}>{item.name}</span>
                    <a href={item.url} download={item.name}
                      className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold text-xs active:scale-95"
                      style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`, color: G_DARK, textDecoration: "none" }}>
                      <Download size={13} /> تنزيل
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        {photoShareCards && (
          <PhotoShareModal cards={photoShareCards} onClose={() => setPhotoShareCards(null)} />
        )}
        <ArchiveView
          cards={savedCards}
          onLoad={loadCard}
          onDelete={deleteCard}
          onDeleteSelected={deleteCardsSelected}
          onClose={() => setView("editor")}
          onExportSelected={startBatchExport}
          onSharePhotos={cards => setPhotoShareCards(cards)}
          isAdmin={true}
        />
      </>
    );
  }

  /* ══ Editor view ══ */
  return (
    <div className="min-h-screen flex flex-col items-center justify-start py-6 px-3"
      style={{ background: `linear-gradient(145deg,${G_DARK} 0%,${G_MID} 50%,${G_DARK} 100%)`, fontFamily: FONT }}>

      {/* Top buttons */}
      <div className="mb-3 flex items-center gap-2 flex-wrap justify-center w-full max-w-sm">
        <button onClick={exportImage} disabled={exporting}
          className="flex items-center gap-1.5 px-4 py-2.5 rounded-full font-bold shadow-xl transition-all active:scale-95 disabled:opacity-70 text-sm"
          style={{ background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT},${AU_DEEP})`, color: G_DARK, border: `1.5px solid ${AU_MID}` }}>
          <Download size={16} />
          {exporting ? "جاري..." : "تصدير الصورة"}
        </button>
        <button onClick={saveCard}
          className="flex items-center gap-1.5 px-4 py-2.5 rounded-full font-bold shadow-xl transition-all active:scale-95 text-sm relative"
          style={{
            background: saveFlash ? "linear-gradient(135deg,#16a34a,#22c55e)" : saveErr ? "rgba(239,68,68,0.15)" : "rgba(255,255,255,0.12)",
            color: saveFlash ? "#fff" : saveErr ? "#f87171" : CREAM,
            border: `1.5px solid ${saveFlash ? "#22c55e" : saveErr ? "#ef4444" : AU_DEEP}`,
          }}
          title={saveErr || undefined}>
          <Save size={16} />
          {saveFlash ? "تم الحفظ ✓" : saveErr ? "خطأ في الحفظ!" : currentCardId ? "تحديث" : "حفظ"}
        </button>
        <button onClick={addFloor}
          className="flex items-center gap-1.5 px-4 py-2.5 rounded-full font-bold shadow-xl transition-all active:scale-95 text-sm"
          style={{ background: "rgba(255,255,255,0.12)", color: CREAM, border: `1.5px solid ${AU_DEEP}` }}>
          <Plus size={16} /> صف
        </button>
        <button onClick={newCard}
          className="flex items-center gap-1.5 px-4 py-2.5 rounded-full font-bold shadow-xl transition-all active:scale-95 text-sm"
          style={{ background: "rgba(255,255,255,0.12)", color: CREAM, border: `1.5px solid ${AU_DEEP}` }}>
          <FilePlus size={16} /> جديد
        </button>
        <button onClick={() => setView("archive")}
          className="flex items-center gap-1.5 px-4 py-2.5 rounded-full font-bold shadow-xl transition-all active:scale-95 text-sm relative"
          style={{ background: "rgba(255,255,255,0.12)", color: CREAM, border: `1.5px solid ${AU_DEEP}` }}>
          <Archive size={16} /> الأرشيف
          {savedCards.length > 0 && (
            <span className="absolute -top-1.5 -left-1.5 w-5 h-5 rounded-full text-xs font-black flex items-center justify-center"
              style={{ background: AU_BRT, color: G_DARK }}>{savedCards.length}</span>
          )}
        </button>
      </div>

      {/* Admin extra navigation */}
      {role === "admin" && (
        <div className="mb-3 flex items-center gap-2 flex-wrap justify-center w-full max-w-sm">
          <button onClick={() => setView("employees")}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-full font-bold transition-all active:scale-95 text-sm"
            style={{ background: "rgba(255,255,255,0.1)", color: CREAM, border: `1.5px solid ${AU_DEEP}88` }}>
            <Users size={15} /> الموظفون
          </button>
          <button onClick={() => setView("submissions")}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-full font-bold transition-all active:scale-95 text-sm relative"
            style={{ background: "rgba(255,255,255,0.1)", color: CREAM, border: `1.5px solid ${AU_DEEP}88` }}>
            <FileText size={15} /> طلبات البيع
            {(() => {
              const cnt = pendingCount;
              return cnt > 0 ? (
                <span className="absolute -top-2 -left-1 min-w-[20px] h-5 px-1 rounded-full text-xs font-black flex items-center justify-center"
                  style={{ background: "#ef4444", color: "#fff" }}>
                  {cnt}
                </span>
              ) : null;
            })()}
          </button>
          <button onClick={() => setView("companies")}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-full font-bold transition-all active:scale-95 text-sm"
            style={{ background: "rgba(37,99,168,0.15)", color: "#93c5fd", border: "1.5px solid #2563a888" }}>
            <Building2 size={15} /> شركات
          </button>
          <button onClick={() => setView("featured")}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-full font-bold transition-all active:scale-95 text-sm relative"
            style={{ background: "rgba(184,145,42,0.15)", color: AU_TEXT, border: `1.5px solid ${AU_DEEP}88` }}>
            <Crown size={15} /> إعلانات مدفوعة
            {featuredPendingCount > 0 && (
              <span className="absolute -top-2 -left-1 min-w-[20px] h-5 px-1 rounded-full text-xs font-black flex items-center justify-center"
                style={{ background: "#ef4444", color: "#fff" }}>{featuredPendingCount}</span>
            )}
          </button>
          <button onClick={() => setRole(null)}
            className="flex items-center gap-1.5 px-3 py-2.5 rounded-full font-bold transition-all active:scale-95 text-sm"
            style={{ background: "rgba(239,68,68,0.12)", color: "#f87171", border: "1.5px solid #f8717144" }}>
            <LogOut size={15} /> خروج
          </button>
        </div>
      )}


      {/* Meta fields */}
      <div className="mb-4 w-full max-w-sm flex gap-2">
        <div className="flex-1 flex items-center gap-2 rounded-xl px-3 py-2.5"
          style={{ background: "rgba(255,255,255,0.08)", border: BORDER }}>
          <span style={{ color: AU_TEXT }}>📍</span>
          <input value={region} onChange={e => setRegion(e.target.value)} placeholder="المنطقة" dir="rtl"
            className="flex-1 bg-transparent outline-none text-sm font-semibold"
            style={{ color: CREAM, fontFamily: FONT }} />
        </div>
        <div className="flex-1 flex items-center gap-2 rounded-xl px-3 py-2.5"
          style={{ background: "rgba(201,162,39,0.08)", border: `2px solid rgba(184,145,42,0.4)` }}>
          <Lock size={14} style={{ color: AU_TEXT, flexShrink: 0 }} />
          <input value={owner} onChange={e => setOwner(e.target.value)} placeholder="صاحب المشروع (سري)" dir="rtl"
            className="flex-1 bg-transparent outline-none text-sm font-semibold"
            style={{ color: AU_TEXT, fontFamily: FONT }} />
        </div>
      </div>

      {/* ── CARD ── */}
      <div ref={cardRef} dir="rtl" className="w-full max-w-sm rounded-2xl overflow-hidden shadow-2xl"
        style={{ background: `linear-gradient(170deg,${G_DARK} 0%,${G_MID} 55%,${G_DARK} 100%)`, fontFamily: FONT, border: BORDER }}>

        <div className="px-5 pt-5 pb-4 flex items-center justify-between gap-3">
          <div className="flex-1 min-w-0">
            <h1 className="font-black text-right leading-tight cursor-pointer active:opacity-70"
              style={{ color: AU_TEXT, fontSize: "1.35rem", textShadow: "0 1px 4px rgba(0,0,0,0.5)" }}
              onClick={() => edit("اسم الشركة", data.companyName, v => set("companyName", v))}>
              {data.companyName}
            </h1>
            <p className="text-sm mt-1 cursor-pointer active:opacity-70" style={{ color: CREAM_D }}
              onClick={() => edit("الوصف", data.subtitle, v => set("subtitle", v))}>
              {data.subtitle}
            </p>
          </div>
          <div className="w-16 h-16 rounded-xl shrink-0 shadow-lg overflow-hidden"
            style={{ background: "#fff", border: `2px solid ${AU_MID}` }}>
            <img src={logoDataUrl} alt="شعار الشركة" className="w-full h-full object-contain" />
          </div>
        </div>

        <div className="mx-4 h-px" style={{ background: `linear-gradient(90deg,transparent,${AU_MID},transparent)` }} />

        <div className="mx-4 mt-3 mb-2 rounded-lg py-2 px-3 flex items-center justify-center gap-3 cursor-pointer active:opacity-80"
          style={{ background: `linear-gradient(90deg,${AU_DEEP},${AU_BRT},${AU_DEEP})` }}
          onClick={() => edit("اسم المشروع", data.projectName, v => set("projectName", v))}>
          <span style={{ color: G_DARK, fontSize: "0.65rem" }}>◆</span>
          <span className="font-black text-lg" style={{ color: G_DARK }}>{data.projectName}</span>
          <span style={{ color: G_DARK, fontSize: "0.65rem" }}>◆</span>
        </div>

        <div className="mx-4 mt-1 rounded-xl overflow-hidden" style={{ border: BORDER }}>
          <table style={{ width: "100%", borderCollapse: "collapse", tableLayout: "fixed" }}>
            <colgroup>
              <col style={{ width: "42%" }} /><col style={{ width: "29%" }} /><col style={{ width: "29%" }} />
            </colgroup>
            <thead>
              <tr style={{ background: `linear-gradient(90deg,${G_DARK},${G_MID},${G_DARK})` }}>
                {["الطابق", "المساحة", "السعر"].map(h => (
                  <th key={h} style={{ padding: "10px 6px", border: BORDER, color: AU_TEXT, fontWeight: 800, fontSize: "0.95rem", textAlign: "center" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.floors.map((floor, i) => (
                <tr key={floor.id} style={{ background: i % 2 === 0 ? "rgba(180,145,42,0.07)" : "rgba(26,92,42,0.35)" }}>
                  <td style={{ padding: "4px 6px", border: BORDER }}>
                    <div className="flex items-center gap-1">
                      <input value={floor.name} onChange={e => setFloor(floor.id, "name", e.target.value)}
                        dir="rtl" className="flex-1 min-w-0 bg-transparent outline-none text-right text-sm font-semibold"
                        style={{ color: CREAM, fontFamily: FONT }} />
                      <button data-export-hide="true" onClick={() => delFloor(floor.id)}
                        className="shrink-0 text-red-400 active:scale-90 p-0.5 rounded">
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </td>
                  <td style={{ padding: "4px", border: BORDER }}>
                    <div className="flex items-center justify-center gap-0.5">
                      <input value={floor.area.replace(/\s*م²\s*$/, "")}
                        onChange={e => setFloor(floor.id, "area", (e.target.value.trim() || "") + " م²")}
                        onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); document.querySelector<HTMLInputElement>(`[data-admprice="${floor.id}"]`)?.focus(); } }}
                        data-admarea={floor.id}
                        dir="ltr" placeholder="المساحة"
                        className="w-full bg-transparent outline-none text-center text-sm font-bold"
                        style={{ color: CREAM, fontFamily: FONT, maxWidth: "60px" }} />
                      <span className="text-xs shrink-0 font-bold" style={{ color: AU_TEXT }}>م²</span>
                    </div>
                  </td>
                  <td style={{ padding: "4px", border: BORDER }}>
                    <div className="flex items-center justify-center gap-0.5">
                      <input value={floor.price.replace(/\s*ألف\s*$/, "")}
                        onChange={e => setFloor(floor.id, "price", (e.target.value.trim() || "") + " ألف")}
                        onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); const next = data.floors[i + 1]; if (next) document.querySelector<HTMLInputElement>(`[data-admarea="${next.id}"]`)?.focus(); } }}
                        data-admprice={floor.id}
                        dir="ltr" placeholder="السعر"
                        className="w-full bg-transparent outline-none text-center text-sm font-bold"
                        style={{ color: "#fff", fontFamily: FONT, maxWidth: "55px" }} />
                      <span className="text-xs shrink-0 font-bold" style={{ color: AU_TEXT }}>ألف</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mx-4 mt-3 mb-4 rounded-xl overflow-hidden" style={{ border: BORDER }}>
          <div className="flex items-stretch">
            <div className="flex flex-col items-center justify-center gap-1 px-3 py-3 cursor-pointer active:opacity-80 shrink-0"
              style={{ background: "rgba(201,162,39,0.18)", borderLeft: BORDER, minWidth: "100px" }}
              onClick={() => edit("رقم الهاتف", data.phone, v => set("phone", v))}>
              <span style={{ fontSize: "0.95rem" }}>📞</span>
              <span className="font-black text-sm tracking-wide" style={{ color: AU_TEXT, direction: "ltr" }}>{data.phone}</span>
              <span className="text-xs" style={{ color: CREAM_D }}>للتواصل</span>
            </div>
            <div className="flex-1 flex flex-col">
              {data.note1 ? (
                <div className="flex-1 flex items-center justify-center px-3 py-2 text-xs font-semibold text-center cursor-pointer active:opacity-80 leading-relaxed"
                  style={{ color: CREAM, borderBottom: BORDER }}
                  onClick={() => edit("ملاحظة الأجور", data.note1, v => set("note1", v), true)}>
                  {data.note1}
                </div>
              ) : null}
              <div className="flex-1 flex items-center justify-center px-3 py-2 text-xs font-medium text-center cursor-pointer active:opacity-80 leading-relaxed"
                style={{ color: "#fff", background: "rgba(26,61,28,0.4)" }}
                onClick={() => edit("الملاحظة التسويقية", data.note2, v => set("note2", v), true)}>
                {data.note2}
              </div>
            </div>
          </div>
        </div>

        {/* Card number strip — visible in export */}
        {currentCardNum && (
          <div className="mx-4 mb-4 mt-2 flex items-center justify-between px-4 py-2 rounded-lg"
            style={{ background: `linear-gradient(90deg,${AU_DEEP}55,${G_DARK}88)`, border: `1px solid ${AU_DEEP}` }}>
            <span className="text-xs font-semibold" style={{ color: CREAM_D }}>شقق وأراضي المستقبل</span>
            <span className="font-black text-base" style={{ color: AU_TEXT }}>
              بطاقة #{currentCardNum}
            </span>
          </div>
        )}
      </div>

      <p className="mt-4 text-sm" style={{ color: "rgba(255,255,255,0.45)" }}>
        اضغط على أي نص لتعديله ✏️
      </p>

      {modal && (
        <EditModal label={modal.label} value={modal.value} multiline={modal.multiline}
          onSave={modal.onSave} onClose={() => setModal(null)} />
      )}
    </div>
  );
}
