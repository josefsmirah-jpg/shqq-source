import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Privacy from "@/pages/privacy";
import { useEffect, useRef, useState } from "react";

const queryClient = new QueryClient();

const G_DARK  = "#1d5c28";
const AU_BRT  = "#e0b830";
const AU_DEEP = "#b8912a";
const CREAM   = "#f5ecd4";
const FONT    = "'Cairo', 'Tajawal', sans-serif";

/* ── Update-check hook ─────────────────────────────────────────── */
function useUpdateNotifier() {
  const [updateReady, setUpdateReady] = useState(false);
  const initialVersion = useRef<number | null>(null);

  useEffect(() => {
    const base = import.meta.env.BASE_URL || "/";
    const url  = `${base}version.json`.replace(/\/\//g, "/");

    const check = async () => {
      try {
        const res  = await fetch(`${url}?t=${Date.now()}`, { cache: "no-store" });
        if (!res.ok) return;
        const data = await res.json() as { v: number };
        if (initialVersion.current === null) {
          initialVersion.current = data.v;
        } else if (data.v !== initialVersion.current) {
          setUpdateReady(true);
        }
      } catch { /* network error — skip */ }
    };

    check();
    const id = setInterval(check, 90_000);
    return () => clearInterval(id);
  }, []);

  return updateReady;
}

/* ── Update Banner ─────────────────────────────────────────────── */
function UpdateBanner() {
  const [visible, setVisible] = useState(true);

  if (!visible) return null;

  return (
    <div
      dir="rtl"
      style={{
        position: "fixed",
        top: 0,
        right: 0,
        left: 0,
        zIndex: 99999,
        fontFamily: FONT,
        background: `linear-gradient(135deg,${AU_DEEP},${AU_BRT})`,
        boxShadow: "0 4px 20px rgba(0,0,0,0.4)",
      }}
    >
      <div className="flex items-center justify-between gap-3 px-4 py-3">
        <div className="flex items-center gap-2">
          <span style={{ fontSize: 20 }}>🔄</span>
          <div>
            <p style={{ color: G_DARK, fontWeight: 900, fontSize: 14, lineHeight: 1.2 }}>
              يوجد تحديث جديد للتطبيق
            </p>
            <p style={{ color: G_DARK, fontSize: 11, opacity: 0.75 }}>
              اضغط تحديث لتجربة أفضل
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => window.location.reload()}
            style={{
              background: G_DARK,
              color: AU_BRT,
              fontWeight: 900,
              fontSize: 13,
              padding: "7px 16px",
              borderRadius: 10,
              border: "none",
              cursor: "pointer",
            }}
          >
            تحديث الآن
          </button>
          <button
            onClick={() => setVisible(false)}
            style={{
              background: "rgba(0,0,0,0.15)",
              color: G_DARK,
              fontWeight: 900,
              fontSize: 16,
              width: 32,
              height: 32,
              borderRadius: 8,
              border: "none",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            ✕
          </button>
        </div>
      </div>
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/privacy" component={Privacy} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const updateReady = useUpdateNotifier();

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        {updateReady && <UpdateBanner />}
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
