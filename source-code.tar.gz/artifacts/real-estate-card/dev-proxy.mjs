/**
 * Simple HTTP proxy: forwards port 5173 → port 8080 (API server)
 * This replaces the Vite dev server in the Replit preview.
 * The built frontend (served by the API server) is always stable.
 */
import http from "http";
import { execSync } from "child_process";

const TARGET_PORT = 8080;
const LISTEN_PORT = Number(process.env.PORT ?? 5173);

// Force-kill anything on the listen port before starting
try {
  execSync(`fuser -k ${LISTEN_PORT}/tcp`, { stdio: "ignore" });
} catch (_) {}

// Give OS time to release the port
await new Promise((r) => setTimeout(r, 1500));

const server = http.createServer((req, res) => {
  const options = {
    hostname: "localhost",
    port: TARGET_PORT,
    path: req.url,
    method: req.method,
    headers: { ...req.headers, host: `localhost:${TARGET_PORT}` },
  };

  const proxy = http.request(options, (upstream) => {
    res.writeHead(upstream.statusCode, upstream.headers);
    upstream.pipe(res, { end: true });
  });

  proxy.on("error", (err) => {
    res.writeHead(502);
    res.end(`API server not ready: ${err.message}`);
  });

  req.pipe(proxy, { end: true });
});

server.on("error", (err) => {
  if (err.code === "EADDRINUSE") {
    console.error(`[dev-proxy] Port ${LISTEN_PORT} still busy, forcing kill and retrying...`);
    try { execSync(`fuser -k ${LISTEN_PORT}/tcp`, { stdio: "ignore" }); } catch (_) {}
    setTimeout(() => {
      server.listen(LISTEN_PORT, "0.0.0.0", () => {
        console.log(`[dev-proxy] :${LISTEN_PORT} → :${TARGET_PORT} ready (retry)`);
      });
    }, 2000);
  } else {
    console.error("[dev-proxy] fatal:", err);
    process.exit(1);
  }
});

server.listen(LISTEN_PORT, "0.0.0.0", () => {
  console.log(`[dev-proxy] :${LISTEN_PORT} → :${TARGET_PORT} ready`);
});
