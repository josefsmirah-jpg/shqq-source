import { Router } from "express";
import { db, employeesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { hashPassword, verifyPassword } from "../lib/password";

const router = Router();

/** Columns returned to callers — password hash is never sent to the client */
const publicCols = {
  id:       employeesTable.id,
  username: employeesTable.username,
  name:     employeesTable.name,
};

/* GET /api/employees — returns all employees without password */
router.get("/employees", async (_req, res) => {
  try {
    const rows = await db.select(publicCols).from(employeesTable);
    res.json(rows);
  } catch {
    res.status(500).json({ error: "فشل جلب الموظفين" });
  }
});

/* POST /api/employees — create a new employee (409 if already exists) */
router.post("/employees", async (req, res) => {
  try {
    const emp = req.body as Record<string, unknown>;
    if (typeof emp?.id !== "string" || typeof emp?.username !== "string") {
      return res.status(400).json({ error: "id و username مطلوبان ويجب أن يكونا نصاً" });
    }
    if (typeof emp.password !== "string" || emp.password.length === 0) {
      return res.status(400).json({ error: "password مطلوب" });
    }
    const [row] = await db
      .insert(employeesTable)
      .values({
        id:       emp.id,
        username: emp.username,
        password: hashPassword(emp.password),
        name:     String(emp.name ?? ""),
      })
      .onConflictDoNothing()
      .returning(publicCols);
    if (!row) return res.status(409).json({ error: "الموظف موجود مسبقاً" });
    res.status(201).json(row);
  } catch {
    res.status(500).json({ error: "فشل إضافة الموظف" });
  }
});

/** Helper: update employee by id, return public row or null */
async function updateEmployee(id: string, body: Record<string, unknown>) {
  const set: { username?: string; password?: string; name?: string } = {};
  if (typeof body.username === "string") set.username = body.username;
  if (typeof body.password === "string") set.password = hashPassword(body.password);
  if (typeof body.name === "string") set.name = body.name;
  if (Object.keys(set).length === 0) return null;
  const [row] = await db
    .update(employeesTable)
    .set(set)
    .where(eq(employeesTable.id, id))
    .returning(publicCols);
  return row ?? null;
}

/* PUT /api/employees — update employee (id in body) */
router.put("/employees", async (req, res) => {
  try {
    const body = req.body as Record<string, unknown>;
    if (typeof body.id !== "string") return res.status(400).json({ error: "id مطلوب في body" });
    const row = await updateEmployee(body.id, body);
    if (!row) return res.status(404).json({ error: "الموظف غير موجود أو لا توجد بيانات للتحديث" });
    res.json(row);
  } catch {
    res.status(500).json({ error: "فشل تحديث الموظف" });
  }
});

/* PUT /api/employees/:id — update employee (RESTful, id in path) */
router.put("/employees/:id", async (req, res) => {
  try {
    const row = await updateEmployee(req.params.id, req.body as Record<string, unknown>);
    if (!row) return res.status(404).json({ error: "الموظف غير موجود أو لا توجد بيانات للتحديث" });
    res.json(row);
  } catch {
    res.status(500).json({ error: "فشل تحديث الموظف" });
  }
});

/** Helper: delete employee by id */
async function deleteEmployee(id: string) {
  await db.delete(employeesTable).where(eq(employeesTable.id, id));
}

/* DELETE /api/employees — delete employee (id in body) */
router.delete("/employees", async (req, res) => {
  try {
    const body = req.body as Record<string, unknown>;
    if (typeof body.id !== "string") return res.status(400).json({ error: "id مطلوب في body" });
    await deleteEmployee(body.id);
    res.json({ ok: true });
  } catch {
    res.status(500).json({ error: "فشل حذف الموظف" });
  }
});

/* DELETE /api/employees/:id — delete employee (RESTful, id in path) */
router.delete("/employees/:id", async (req, res) => {
  try {
    await deleteEmployee(req.params.id);
    res.json({ ok: true });
  } catch {
    res.status(500).json({ error: "فشل حذف الموظف" });
  }
});

/* POST /api/employees/verify — verify employee login */
router.post("/employees/verify", async (req, res) => {
  try {
    const body = req.body as Record<string, unknown>;
    if (typeof body.username !== "string" || typeof body.password !== "string") {
      return res.status(400).json({ error: "username و password مطلوبان" });
    }
    const rows = await db
      .select()
      .from(employeesTable)
      .where(eq(employeesTable.username, body.username));
    if (rows.length === 0) return res.json({ ok: false });
    const ok = verifyPassword(body.password, rows[0]!.password);
    res.json({ ok, id: ok ? rows[0]!.id : undefined, name: ok ? rows[0]!.name : undefined });
  } catch {
    res.status(500).json({ error: "فشل التحقق من بيانات الموظف" });
  }
});

/* POST /api/employees/bulk — replace all employees */
router.post("/employees/bulk", async (req, res) => {
  const emps = req.body;
  if (!Array.isArray(emps)) return res.status(400).json({ error: "يجب أن يكون المدخل مصفوفة" });
  const invalid = emps.findIndex((e) => typeof e?.id !== "string" || typeof e?.username !== "string");
  if (invalid !== -1) return res.status(400).json({ error: `العنصر ${invalid} يفتقر إلى id أو username نصي` });
  try {
    await db.delete(employeesTable);
    if (emps.length > 0) {
      await db.insert(employeesTable).values(
        (emps as Record<string, unknown>[]).map(e => ({
          id:       String(e.id),
          username: String(e.username),
          password: typeof e.password === "string" ? hashPassword(e.password) : hashPassword(""),
          name:     String(e.name ?? ""),
        }))
      );
    }
    res.json({ ok: true, count: emps.length });
  } catch {
    res.status(500).json({ error: "فشل تحديث الموظفين" });
  }
});

export default router;
