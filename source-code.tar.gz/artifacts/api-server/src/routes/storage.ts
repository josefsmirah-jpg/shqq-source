import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import { Readable } from "stream";
import { ObjectStorageService, ObjectNotFoundError } from "../lib/objectStorage";

const router: IRouter = Router();
const objectStorageService = new ObjectStorageService();

/* Photos/objects are content-addressed — safe to cache in browser for 24 h.
   This OVERRIDES the global /api no-cache middleware set in app.ts */
router.use(["/storage/objects", "/storage/public-objects"], (_req: Request, res: Response, next: NextFunction) => {
  res.setHeader("Cache-Control", "public, max-age=86400, stale-while-revalidate=3600");
  next();
});

/**
 * POST /storage/uploads/request-url
 * Body: { name, size, contentType }
 * Returns: { uploadURL, objectPath, metadata }
 */
router.post("/storage/uploads/request-url", async (req: Request, res: Response) => {
  const { name, size, contentType } = req.body as Record<string, unknown>;
  if (!contentType) {
    res.status(400).json({ error: "contentType is required" });
    return;
  }
  try {
    const uploadURL  = await objectStorageService.getObjectEntityUploadURL();
    const objectPath = objectStorageService.normalizeObjectEntityPath(uploadURL);
    res.json({ uploadURL, objectPath, metadata: { name, size, contentType } });
  } catch (error) {
    console.error("Error generating upload URL", error);
    res.status(500).json({ error: "Failed to generate upload URL" });
  }
});

/**
 * GET /storage/public-objects/<filePath>
 * Serves public assets unconditionally.
 * Uses router.use for prefix matching (avoids path-to-regexp wildcard issues).
 */
router.use("/storage/public-objects", async (req: Request, res: Response, next: NextFunction) => {
  if (req.method !== "GET") { next(); return; }
  const filePath = req.path.replace(/^\//, ""); // strip leading slash
  try {
    const file = await objectStorageService.searchPublicObject(filePath);
    if (!file) { res.status(404).json({ error: "Not found" }); return; }
    const response = await objectStorageService.downloadObject(file);
    const headers = Object.fromEntries(response.headers.entries());
    res.set(headers).status(response.status);
    if (response.body) {
      Readable.fromWeb(response.body as Parameters<typeof Readable.fromWeb>[0]).pipe(res);
    } else {
      res.end();
    }
  } catch {
    res.status(500).json({ error: "Failed to serve public object" });
  }
});

/**
 * GET /storage/objects/<objectPath>
 * Serves uploaded objects. req.path holds the path after the prefix.
 */
router.use("/storage/objects", async (req: Request, res: Response, next: NextFunction) => {
  if (req.method !== "GET") { next(); return; }
  const rawPath = `/objects${req.path}`;
  try {
    const file = await objectStorageService.getObjectEntityFile(rawPath);
    const response = await objectStorageService.downloadObject(file, 3600);
    const headers = Object.fromEntries(response.headers.entries());
    res.set(headers).status(response.status);
    if (response.body) {
      Readable.fromWeb(response.body as Parameters<typeof Readable.fromWeb>[0]).pipe(res);
    } else {
      res.end();
    }
  } catch (error) {
    if (error instanceof ObjectNotFoundError) {
      res.status(404).json({ error: "Object not found" });
    } else {
      res.status(500).json({ error: "Failed to serve object" });
    }
  }
});

export default router;
