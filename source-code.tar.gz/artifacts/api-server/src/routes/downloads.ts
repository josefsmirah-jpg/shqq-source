import { Router } from "express";
import path from "path";
import { fileURLToPath } from "url";

const router = Router();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const downloadsDir = path.resolve(__dirname, "../downloads");

router.get("/download/android-project", (_req, res) => {
  const file = path.join(downloadsDir, "android-project.tar.gz");
  res.setHeader("Content-Type", "application/gzip");
  res.setHeader("Content-Disposition", "attachment; filename=android-project.tar.gz");
  res.setHeader("Cache-Control", "no-cache");
  res.sendFile(file, (err) => {
    if (err) res.status(404).json({ error: "File not found" });
  });
});

export default router;
