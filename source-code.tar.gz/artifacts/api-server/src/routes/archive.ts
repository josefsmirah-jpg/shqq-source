import { Router } from "express";
import { db, savedCardsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router = Router();

/* GET /api/archive — list all saved cards newest first */
router.get("/archive", async (_req, res) => {
  try {
    const rows = await db
      .select()
      .from(savedCardsTable)
      .orderBy(desc(savedCardsTable.savedAt));
    res.json(rows);
  } catch {
    res.status(500).json({ error: "فشل جلب الأرشيف" });
  }
});

/* POST /api/archive — create or replace a card */
router.post("/archive", async (req, res) => {
  try {
    const card = req.body as Record<string, unknown>;
    if (typeof card?.id !== "string") return res.status(400).json({ error: "id مطلوب" });
    const [row] = await db
      .insert(savedCardsTable)
      .values({
        id:           card.id,
        savedAt:      Number(card.savedAt ?? Date.now()),
        cardNum:      Number(card.cardNum ?? 0),
        region:       String(card.region ?? ""),
        owner:        String(card.owner ?? ""),
        guestPhone:   card.guestPhone   != null ? String(card.guestPhone)   : null,
        ownerContact: card.ownerContact != null ? String(card.ownerContact) : null,
        data:         card.data ?? {},
        employeeId:   card.employeeId   != null ? String(card.employeeId)   : null,
        employeeName: card.employeeName != null ? String(card.employeeName) : null,
      })
      .onConflictDoUpdate({
        target: savedCardsTable.id,
        set: {
          savedAt:      Number(card.savedAt ?? Date.now()),
          cardNum:      Number(card.cardNum ?? 0),
          region:       String(card.region ?? ""),
          owner:        String(card.owner ?? ""),
          guestPhone:   card.guestPhone   != null ? String(card.guestPhone)   : null,
          ownerContact: card.ownerContact != null ? String(card.ownerContact) : null,
          data:         card.data ?? {},
          employeeId:   card.employeeId   != null ? String(card.employeeId)   : null,
          employeeName: card.employeeName != null ? String(card.employeeName) : null,
        },
      })
      .returning();
    res.json(row);
  } catch {
    res.status(500).json({ error: "فشل حفظ البطاقة" });
  }
});

/** Helper: update card by id */
async function updateCard(id: string, updates: Partial<typeof savedCardsTable.$inferInsert>) {
  const [row] = await db
    .update(savedCardsTable)
    .set(updates)
    .where(eq(savedCardsTable.id, id))
    .returning();
  return row ?? null;
}

/* PUT /api/archive — update a card (id in body) */
router.put("/archive", async (req, res) => {
  try {
    const body = req.body as Record<string, unknown>;
    if (typeof body.id !== "string") return res.status(400).json({ error: "id مطلوب في body" });
    const { id, ...updates } = body;
    const row = await updateCard(id, updates as Partial<typeof savedCardsTable.$inferInsert>);
    if (!row) return res.status(404).json({ error: "البطاقة غير موجودة" });
    res.json(row);
  } catch {
    res.status(500).json({ error: "فشل تحديث البطاقة" });
  }
});

/* PUT /api/archive/:id — update a specific card (RESTful, id in path) */
router.put("/archive/:id", async (req, res) => {
  try {
    const row = await updateCard(req.params.id, req.body as Partial<typeof savedCardsTable.$inferInsert>);
    if (!row) return res.status(404).json({ error: "البطاقة غير موجودة" });
    res.json(row);
  } catch {
    res.status(500).json({ error: "فشل تحديث البطاقة" });
  }
});

/* DELETE /api/archive — delete a card (id in body) */
router.delete("/archive", async (req, res) => {
  try {
    const body = req.body as Record<string, unknown>;
    if (typeof body.id !== "string") return res.status(400).json({ error: "id مطلوب في body" });
    await db.delete(savedCardsTable).where(eq(savedCardsTable.id, body.id));
    res.json({ ok: true });
  } catch {
    res.status(500).json({ error: "فشل حذف البطاقة" });
  }
});

/* DELETE /api/archive/:id — delete a card (RESTful, id in path) */
router.delete("/archive/:id", async (req, res) => {
  try {
    await db.delete(savedCardsTable).where(eq(savedCardsTable.id, req.params.id));
    res.json({ ok: true });
  } catch {
    res.status(500).json({ error: "فشل حذف البطاقة" });
  }
});

/* POST /api/archive/bulk — replace entire archive */
router.post("/archive/bulk", async (req, res) => {
  const cards = req.body;
  if (!Array.isArray(cards)) return res.status(400).json({ error: "يجب أن يكون المدخل مصفوفة" });
  const invalid = cards.findIndex((c) => typeof c?.id !== "string");
  if (invalid !== -1) return res.status(400).json({ error: `العنصر ${invalid} يفتقر إلى id نصي` });
  try {
    await db.delete(savedCardsTable);
    if (cards.length > 0) {
      await db.insert(savedCardsTable).values(
        (cards as Record<string, unknown>[]).map(c => ({
          id:           String(c.id),
          savedAt:      Number(c.savedAt ?? Date.now()),
          cardNum:      Number(c.cardNum ?? 0),
          region:       String(c.region ?? ""),
          owner:        String(c.owner ?? ""),
          guestPhone:   c.guestPhone   != null ? String(c.guestPhone)   : null,
          ownerContact: c.ownerContact != null ? String(c.ownerContact) : null,
          data:         c.data ?? {},
          employeeId:   c.employeeId   != null ? String(c.employeeId)   : null,
          employeeName: c.employeeName != null ? String(c.employeeName) : null,
        }))
      );
    }
    res.json({ ok: true, count: cards.length });
  } catch {
    res.status(500).json({ error: "فشل تحديث الأرشيف" });
  }
});

export default router;
