import { Router } from "express";
import { db, photosTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

/* GET /api/archive/:cardId/photos */
router.get("/archive/:cardId/photos", async (req, res) => {
  try {
    const rows = await db
      .select()
      .from(photosTable)
      .where(eq(photosTable.cardId, req.params.cardId));
    res.json(rows);
  } catch {
    res.status(500).json({ error: "فشل جلب الصور" });
  }
});

/* POST /api/archive/:cardId/photos — register a photo after upload */
router.post("/archive/:cardId/photos", async (req, res) => {
  try {
    const { cardId } = req.params;
    const body = req.body as { objectPath?: string };
    if (!body.objectPath) return res.status(400).json({ error: "objectPath مطلوب" });

    const existing = await db
      .select()
      .from(photosTable)
      .where(eq(photosTable.cardId, cardId));
    if (existing.length >= 10) {
      return res.status(400).json({ error: "الحد الأقصى للصور هو 10 لكل بطاقة" });
    }

    const [row] = await db
      .insert(photosTable)
      .values({
        id:         `${Date.now()}_${Math.random().toString(36).slice(2)}`,
        cardId,
        objectPath: body.objectPath,
        uploadedAt: Date.now(),
      })
      .returning();
    res.json(row);
  } catch {
    res.status(500).json({ error: "فشل حفظ الصورة" });
  }
});

/* DELETE /api/archive/:cardId/photos/:photoId */
router.delete("/archive/:cardId/photos/:photoId", async (req, res) => {
  try {
    await db
      .delete(photosTable)
      .where(eq(photosTable.id, req.params.photoId));
    res.json({ ok: true });
  } catch {
    res.status(500).json({ error: "فشل حذف الصورة" });
  }
});

export default router;
