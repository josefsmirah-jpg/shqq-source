import { Router } from "express";
import { db, companyVisitorsTable } from "@workspace/db";
import { count } from "drizzle-orm";

const router = Router();

router.post("/company-visitors", async (req, res) => {
  try {
    const { id, companyName, phone } = req.body as { id?: string; companyName?: string; phone?: string };
    if (!id) return res.status(400).json({ error: "id مطلوب" });
    await db
      .insert(companyVisitorsTable)
      .values({ id: String(id), companyName: String(companyName ?? ""), phone: String(phone ?? ""), visitedAt: Date.now() })
      .onConflictDoNothing();
    res.json({ ok: true });
  } catch {
    res.status(500).json({ error: "فشل تسجيل زائر الشركة" });
  }
});

router.get("/company-visitors/count", async (_req, res) => {
  try {
    const [result] = await db.select({ total: count() }).from(companyVisitorsTable);
    res.json({ total: result?.total ?? 0 });
  } catch {
    res.status(500).json({ error: "فشل جلب عدد شركات" });
  }
});

export default router;
