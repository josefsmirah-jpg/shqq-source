import { Router } from "express";
import { db, submissionsTable, savedCardsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router = Router();

/* GET /api/submissions — list all submissions newest first */
router.get("/submissions", async (_req, res) => {
  try {
    const rows = await db
      .select()
      .from(submissionsTable)
      .orderBy(desc(submissionsTable.submittedAt));
    res.json(rows);
  } catch {
    res.status(500).json({ error: "فشل جلب الطلبات" });
  }
});

/* GET /api/submissions/by-phone/:phone — fetch submissions by guest phone */
router.get("/submissions/by-phone/:phone", async (req, res) => {
  try {
    const phone = decodeURIComponent(req.params.phone).trim();
    const rows = await db
      .select()
      .from(submissionsTable)
      .where(eq(submissionsTable.phone, phone))
      .orderBy(desc(submissionsTable.submittedAt));
    res.json(rows);
  } catch {
    res.status(500).json({ error: "فشل جلب الطلبات" });
  }
});

/* POST /api/submissions — create a new submission */
router.post("/submissions", async (req, res) => {
  try {
    const s = req.body as Record<string, unknown>;
    if (!s?.id) return res.status(400).json({ error: "id مطلوب" });
    const [row] = await db
      .insert(submissionsTable)
      .values({
        id:           String(s.id),
        submittedAt:  Number(s.submittedAt ?? Date.now()),
        status:       String(s.status ?? "pending"),
        submittedBy:  String(s.submittedBy ?? "guest"),
        ownerType:    String(s.ownerType ?? ""),
        propertyType: String(s.propertyType ?? ""),
        region:       String(s.region ?? ""),
        price:        String(s.price ?? ""),
        floor:        String(s.floor ?? ""),
        area:         String(s.area ?? ""),
        contactName:  String(s.contactName ?? ""),
        phone:        String(s.phone ?? ""),
        description:  String(s.description ?? ""),
        ownerContact: s.ownerContact != null ? String(s.ownerContact) : null,
        cardRegion:   s.cardRegion   != null ? String(s.cardRegion)   : null,
        cardData:     s.cardData ?? null,
        employeeId:   s.employeeId   != null ? String(s.employeeId)   : null,
        employeeName: s.employeeName != null ? String(s.employeeName) : null,
        companyName:  s.companyName  != null ? String(s.companyName)  : null,
      })
      .onConflictDoNothing()
      .returning();
    res.json(row ?? { id: s.id });
  } catch {
    res.status(500).json({ error: "فشل إرسال الطلب" });
  }
});

/** Helper: update submission by id */
async function updateSubmission(id: string, updates: Partial<typeof submissionsTable.$inferInsert>) {
  const [row] = await db
    .update(submissionsTable)
    .set(updates)
    .where(eq(submissionsTable.id, id))
    .returning();
  return row ?? null;
}

/* PUT /api/submissions — update submission (id in body) */
router.put("/submissions", async (req, res) => {
  try {
    const body = req.body as Record<string, unknown>;
    if (typeof body.id !== "string") return res.status(400).json({ error: "id مطلوب في body" });
    const { id, ...updates } = body;
    const row = await updateSubmission(id, updates as Partial<typeof submissionsTable.$inferInsert>);
    if (!row) return res.status(404).json({ error: "الطلب غير موجود" });
    res.json(row);
  } catch {
    res.status(500).json({ error: "فشل تحديث الطلب" });
  }
});

/* PUT /api/submissions/:id — update status or fields (RESTful, id in path) */
router.put("/submissions/:id", async (req, res) => {
  try {
    const row = await updateSubmission(req.params.id, req.body as Partial<typeof submissionsTable.$inferInsert>);
    if (!row) return res.status(404).json({ error: "الطلب غير موجود" });
    res.json(row);
  } catch {
    res.status(500).json({ error: "فشل تحديث الطلب" });
  }
});

/* DELETE /api/submissions/:id — cascade: deletes from submissions + archive */
router.delete("/submissions/:id", async (req, res) => {
  try {
    const { id } = req.params;
    await db.delete(submissionsTable).where(eq(submissionsTable.id, id));
    await db.delete(savedCardsTable).where(eq(savedCardsTable.id, `sub_${id}`));
    res.json({ ok: true });
  } catch {
    res.status(500).json({ error: "فشل حذف الطلب" });
  }
});

export default router;
