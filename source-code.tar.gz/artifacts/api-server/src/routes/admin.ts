import { Router } from "express";
import { db, adminConfigTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { hashPassword, verifyPassword } from "../lib/password";

const router = Router();

async function getAdmin() {
  const rows = await db.select().from(adminConfigTable).where(eq(adminConfigTable.id, 1));
  return rows[0] ?? null;
}

/* GET /api/admin — returns { username } or { configured: false } if not set up */
router.get("/admin", async (_req, res) => {
  try {
    const row = await getAdmin();
    if (!row) return res.json({ configured: false });
    res.json({ username: row.username, configured: true });
  } catch {
    res.status(500).json({ error: "فشل جلب إعدادات الأدمن" });
  }
});

/**
 * POST /api/admin/setup — one-time first-run setup.
 * Creates admin credentials only if no admin row exists yet.
 * Fails (409) if admin is already configured.
 */
router.post("/admin/setup", async (req, res) => {
  try {
    const existing = await getAdmin();
    if (existing) {
      return res.status(409).json({ error: "الأدمن مضبوط مسبقاً" });
    }
    const body = req.body as Record<string, unknown>;
    if (typeof body.username !== "string" || typeof body.password !== "string") {
      return res.status(400).json({ error: "username و password مطلوبان" });
    }
    const [row] = await db
      .insert(adminConfigTable)
      .values({ id: 1, username: body.username, passwordHash: hashPassword(body.password) })
      .returning();
    res.status(201).json({ username: row!.username });
  } catch {
    res.status(500).json({ error: "فشل إعداد الأدمن" });
  }
});

/* POST /api/admin/verify — verify credentials, returns { ok: boolean } */
router.post("/admin/verify", async (req, res) => {
  try {
    const body = req.body as Record<string, unknown>;
    const { username, password } = body;
    if (typeof username !== "string" || typeof password !== "string") {
      return res.status(400).json({ error: "username و password مطلوبان" });
    }
    const row = await getAdmin();
    if (!row) return res.json({ ok: false });
    const ok = row.username === username && verifyPassword(password, row.passwordHash);
    res.json({ ok });
  } catch {
    res.status(500).json({ error: "فشل التحقق من بيانات الأدمن" });
  }
});

/* PUT /api/admin — update admin credentials */
router.put("/admin", async (req, res) => {
  try {
    const body = req.body as Record<string, unknown>;
    const { username, password } = body;
    const existing = await getAdmin();
    if (!existing) return res.status(404).json({ error: "الأدمن غير مضبوط" });

    const set: { username?: string; passwordHash?: string } = {};
    if (typeof username === "string") set.username = username;
    if (typeof password === "string") set.passwordHash = hashPassword(password);

    if (Object.keys(set).length === 0) {
      return res.status(400).json({ error: "لا توجد بيانات للتحديث" });
    }

    const [row] = await db
      .update(adminConfigTable)
      .set(set)
      .where(eq(adminConfigTable.id, 1))
      .returning();
    res.json({ username: row!.username });
  } catch {
    res.status(500).json({ error: "فشل تحديث إعدادات الأدمن" });
  }
});

export default router;
