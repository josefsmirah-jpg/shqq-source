import { Router } from "express";
import { db, pool, employeesTable, adminConfigTable, savedCardsTable, submissionsTable, featuredAdsTable } from "@workspace/db";

const router = Router();
const SYNC_SECRET = process.env.SYNC_SECRET ?? "";
const PROD_URL    = "https://design-palette--josefsmirah.replit.app";

/* ─── Secret guard ─────────────────────────────────────────────────────── */
function checkSecret(req: import("express").Request, res: import("express").Response): boolean {
  const secret = (req.headers["x-sync-secret"] as string | undefined) ?? (req.query.s as string | undefined);
  if (!SYNC_SECRET || secret !== SYNC_SECRET) {
    res.status(403).json({ error: "Forbidden" });
    return false;
  }
  return true;
}

/* ─── Build full snapshot of ALL critical tables ───────────────────────── */
async function buildSnapshot() {
  const [employees, adminRows, savedCards, submissions, featuredAds] = await Promise.all([
    db.select().from(employeesTable),
    db.select().from(adminConfigTable),
    db.select().from(savedCardsTable),
    db.select().from(submissionsTable),
    db.select().from(featuredAdsTable),
  ]);
  return {
    employees,
    adminConfig:   adminRows[0] ?? null,
    savedCards,
    submissions,
    featuredAds,
  };
}

/* ─── Apply a snapshot to the local DB ─────────────────────────────────── */
async function applySnapshot(snap: Awaited<ReturnType<typeof buildSnapshot>>) {
  const { employees, adminConfig, savedCards, submissions, featuredAds } = snap;

  await pool.query("BEGIN");
  try {
    /* employees */
    await db.delete(employeesTable);
    if (employees.length > 0) await db.insert(employeesTable).values(employees);

    /* admin_config */
    if (adminConfig) {
      await db
        .insert(adminConfigTable)
        .values({ id: 1, username: adminConfig.username, passwordHash: adminConfig.passwordHash })
        .onConflictDoUpdate({
          target: adminConfigTable.id,
          set: { username: adminConfig.username, passwordHash: adminConfig.passwordHash },
        });
    }

    /* saved_cards */
    await db.delete(savedCardsTable);
    if (savedCards.length > 0) await db.insert(savedCardsTable).values(savedCards as typeof savedCardsTable.$inferInsert[]);

    /* submissions */
    await db.delete(submissionsTable);
    if (submissions.length > 0) await db.insert(submissionsTable).values(submissions as typeof submissionsTable.$inferInsert[]);

    /* featured_ads — serial PK, restore with original ids + reset sequence */
    await pool.query("DELETE FROM featured_ads");
    if (featuredAds.length > 0) {
      for (const ad of featuredAds) {
        await pool.query(
          `INSERT INTO featured_ads (id, submission_id, company_name, company_phone, plan_days, plan_label,
           plan_price, status, submitted_at, approved_at, expires_at, contacts_count, card_num)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
           ON CONFLICT (id) DO UPDATE SET
             submission_id=$2, company_name=$3, company_phone=$4, plan_days=$5, plan_label=$6,
             plan_price=$7, status=$8, submitted_at=$9, approved_at=$10,
             expires_at=$11, contacts_count=$12, card_num=$13`,
          [
            ad.id, ad.submissionId, ad.companyName, ad.companyPhone,
            ad.planDays, ad.planLabel, ad.planPrice, ad.status,
            ad.submittedAt, ad.approvedAt ?? null, ad.expiresAt ?? null,
            ad.contactsCount, ad.cardNum ?? null,
          ],
        );
      }
      /* reset sequence so next insert gets a new id above the max */
      const maxId = Math.max(...featuredAds.map(a => a.id ?? 0));
      await pool.query(`SELECT setval(pg_get_serial_sequence('featured_ads','id'), $1, true)`, [maxId]);
    }

    await pool.query("COMMIT");
  } catch (e) {
    await pool.query("ROLLBACK");
    throw e;
  }
}

/* ─── GET /api/sync/export ─────────────────────────────────────────────── */
router.get("/sync/export", async (req, res) => {
  if (!checkSecret(req, res)) return;
  try {
    res.json(await buildSnapshot());
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

/* ─── POST /api/sync/import ─────────────────────────────────────────────── */
router.post("/sync/import", async (req, res) => {
  if (!checkSecret(req, res)) return;
  try {
    const snap = req.body as Awaited<ReturnType<typeof buildSnapshot>>;
    await applySnapshot(snap);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

/* ─── POST /api/sync/push-to-prod ──────────────────────────────────────── */
router.post("/sync/push-to-prod", async (_req, res) => {
  try {
    if (!SYNC_SECRET) return res.status(500).json({ error: "SYNC_SECRET not configured" });
    const snap = await buildSnapshot();
    const r = await fetch(`${PROD_URL}/api/sync/import`, {
      method:  "POST",
      headers: { "Content-Type": "application/json", "x-sync-secret": SYNC_SECRET },
      body:    JSON.stringify(snap),
    });
    const data = await r.json() as { ok?: boolean; error?: string };
    if (!r.ok || !data.ok) return res.status(502).json({ error: data.error ?? "فشل الإرسال" });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

/* ─── POST /api/sync/pull-from-prod ────────────────────────────────────── */
router.post("/sync/pull-from-prod", async (_req, res) => {
  try {
    if (!SYNC_SECRET) return res.status(500).json({ error: "SYNC_SECRET not configured" });
    const r = await fetch(`${PROD_URL}/api/sync/export?s=${encodeURIComponent(SYNC_SECRET)}`);
    if (!r.ok) return res.status(502).json({ error: "فشل الجلب من الإنتاج" });
    const snap = await r.json() as Awaited<ReturnType<typeof buildSnapshot>>;
    await applySnapshot(snap);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

/* ═══════════════════════════════════════════════════════════════════════
   AUTO-SYNC ENGINE
   In non-production environments, any successful write triggers an
   automatic background push to production (debounced 400 ms).
   In production (REPL_DEPLOYMENT=1) this is completely disabled
   to prevent sync loops.
   ═══════════════════════════════════════════════════════════════════════ */
const IS_PROD = Boolean(process.env.REPL_DEPLOYMENT);
let syncTimer: ReturnType<typeof setTimeout> | null = null;
let syncPending = false;

export function scheduleAutoSync() {
  if (IS_PROD || !SYNC_SECRET) return;          // disabled in production
  if (syncTimer) clearTimeout(syncTimer);
  syncPending = true;
  syncTimer = setTimeout(async () => {
    syncTimer = null;
    syncPending = false;
    try {
      const snap = await buildSnapshot();
      const r = await fetch(`${PROD_URL}/api/sync/import`, {
        method:  "POST",
        headers: { "Content-Type": "application/json", "x-sync-secret": SYNC_SECRET },
        body:    JSON.stringify(snap),
      });
      if (!r.ok) {
        const t = await r.text();
        console.error("[auto-sync] failed:", r.status, t.substring(0, 120));
      }
    } catch (e) {
      console.error("[auto-sync] error:", e);
    }
  }, 400);
}

export { buildSnapshot, applySnapshot };
export default router;
