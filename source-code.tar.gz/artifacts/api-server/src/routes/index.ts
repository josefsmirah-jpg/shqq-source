import { Router, type IRouter } from "express";
import healthRouter      from "./health";
import archiveRouter     from "./archive";
import submissionsRouter from "./submissions";
import employeesRouter   from "./employees";
import adminRouter       from "./admin";
import statsRouter       from "./stats";
import storageRouter     from "./storage";
import photosRouter      from "./photos";
import visitorsRouter        from "./visitors";
import companyVisitorsRouter from "./company-visitors";
import featuredAdsRouter     from "./featured-ads";
import syncRouter            from "./sync";
import downloadsRouter       from "./downloads";

const router: IRouter = Router();

router.use(healthRouter);
router.use(archiveRouter);
router.use(submissionsRouter);
router.use(employeesRouter);
router.use(adminRouter);
router.use(statsRouter);
router.use(storageRouter);
router.use(photosRouter);
router.use(visitorsRouter);
router.use(companyVisitorsRouter);
router.use(featuredAdsRouter);
router.use(syncRouter);
router.use(downloadsRouter);

export default router;
