import { Router } from "express";
import { db } from "@workspace/db";
import { featuredAdsTable, featuredAdContactLogsTable } from "@workspace/db/schema";
import { eq, sql, desc } from "drizzle-orm";
import { savedCardsTable, submissionsTable } from "@workspace/db/schema";

const router = Router();

/* POST /featured-ads — company submits a paid ad request */
router.post("/featured-ads", async (req, res) => {
  try {
    const { submissionId, companyName, companyPhone, planDays, planLabel, planPrice, cardNum } = req.body;
    if (!submissionId || !planDays) return res.status(400).json({ error: "missing fields" });
    await db.insert(featuredAdsTable).values({
      submissionId, companyName: companyName || "",
      companyPhone: companyPhone || "",
      planDays, planLabel: planLabel || "", planPrice: planPrice || 0,
      status: "pending", submittedAt: Date.now(),
      cardNum: cardNum ?? null,
    });
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

/* GET /featured-ads/next-card-num — returns the next available card number */
router.get("/featured-ads/next-card-num", async (_req, res) => {
  try {
    const cards = await db.select({ cardNum: savedCardsTable.cardNum }).from(savedCardsTable);
    const subs  = await db.select({ cardNum: submissionsTable.cardNum }).from(submissionsTable);
    const maxCard = cards.reduce((m, c) => Math.max(m, c.cardNum ?? 0), 0);
    const maxSub  = subs.reduce((m, s) => Math.max(m, Number(s.cardNum ?? 0) || 0), 0);
    res.json({ nextCardNum: Math.max(maxCard, maxSub) + 1 });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

/* GET /featured-ads — admin: all requests */
router.get("/featured-ads", async (_req, res) => {
  try {
    const rows = await db.select().from(featuredAdsTable).orderBy(featuredAdsTable.submittedAt);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

/* GET /featured-ads/approved — guest: currently active featured ads */
router.get("/featured-ads/approved", async (_req, res) => {
  try {
    const rows = await db.select().from(featuredAdsTable)
      .where(eq(featuredAdsTable.status, "approved"));
    const now = Date.now();
    const active = rows.filter(r => !r.expiresAt || r.expiresAt > now);
    res.json(active);
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

/* GET /featured-ads/contact-logs — admin: all contact log entries */
router.get("/featured-ads/contact-logs", async (_req, res) => {
  try {
    const rows = await db.select().from(featuredAdContactLogsTable)
      .orderBy(desc(featuredAdContactLogsTable.contactedAt));
    res.json(rows);
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

/* PATCH /featured-ads/:id/approve — admin approves */
router.patch("/featured-ads/:id/approve", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const row = await db.select().from(featuredAdsTable).where(eq(featuredAdsTable.id, id));
    if (!row.length) return res.status(404).json({ error: "not found" });
    const approvedAt = Date.now();
    const expiresAt  = approvedAt + row[0].planDays * 86_400_000;
    await db.update(featuredAdsTable)
      .set({ status: "approved", approvedAt, expiresAt })
      .where(eq(featuredAdsTable.id, id));
    res.json({ ok: true, expiresAt });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

/* PATCH /featured-ads/:id/reject — admin rejects */
router.patch("/featured-ads/:id/reject", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.update(featuredAdsTable)
      .set({ status: "rejected" })
      .where(eq(featuredAdsTable.id, id));
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

/* POST /featured-ads/:id/contact — guest contacted a featured advertiser */
router.post("/featured-ads/:id/contact", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { visitorPhone, ownerPhone, ownerName } = req.body as {
      visitorPhone?: string; ownerPhone?: string; ownerName?: string;
    };

    await db.update(featuredAdsTable)
      .set({ contactsCount: sql`contacts_count + 1` })
      .where(eq(featuredAdsTable.id, id));

    if (visitorPhone) {
      await db.insert(featuredAdContactLogsTable).values({
        featuredAdId: id,
        visitorPhone: visitorPhone.trim(),
        ownerPhone:   (ownerPhone ?? "").trim(),
        ownerName:    (ownerName  ?? "").trim(),
        contactedAt:  Date.now(),
      });
    }

    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.delete("/featured-ads/contact-logs/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: "invalid id" });
    await db.delete(featuredAdContactLogsTable).where(eq(featuredAdContactLogsTable.id, id));
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

router.delete("/featured-ads/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: "invalid id" });
    await db.delete(featuredAdsTable).where(eq(featuredAdsTable.id, id));
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: String(e) }); }
});

export default router;
