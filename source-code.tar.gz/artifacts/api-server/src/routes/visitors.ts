import { Router } from "express";
import { db, visitorsTable } from "@workspace/db";
import { desc, count } from "drizzle-orm";

const router = Router();

/* POST /api/visitors — log a new visitor */
router.post("/visitors", async (req, res) => {
  try {
    const { id, name, phone } = req.body as { id?: string; name?: string; phone?: string };
    if (!id) return res.status(400).json({ error: "id مطلوب" });
    await db
      .insert(visitorsTable)
      .values({ id: String(id), name: String(name ?? ""), phone: String(phone ?? ""), visitedAt: Date.now() })
      .onConflictDoNothing();
    res.json({ ok: true });
  } catch {
    res.status(500).json({ error: "فشل تسجيل الزائر" });
  }
});

/* GET /api/visitors/count — total unique visitor count */
router.get("/visitors/count", async (_req, res) => {
  try {
    const [result] = await db.select({ total: count() }).from(visitorsTable);
    res.json({ total: result?.total ?? 0 });
  } catch {
    res.status(500).json({ error: "فشل جلب عدد الزوار" });
  }
});

/* GET /api/visitors — list recent visitors (admin only) */
router.get("/visitors", async (_req, res) => {
  try {
    const rows = await db.select().from(visitorsTable).orderBy(desc(visitorsTable.visitedAt)).limit(200);
    res.json(rows);
  } catch {
    res.status(500).json({ error: "فشل جلب الزوار" });
  }
});

/* DELETE /api/visitors — reset visitor count (admin only) */
router.delete("/visitors", async (_req, res) => {
  try {
    await db.delete(visitorsTable);
    res.json({ ok: true });
  } catch {
    res.status(500).json({ error: "فشل تصفير العداد" });
  }
});

export default router;
