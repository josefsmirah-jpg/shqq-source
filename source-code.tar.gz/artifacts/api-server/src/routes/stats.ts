import { Router } from "express";
import { pool } from "@workspace/db";

const router = Router();

/* GET /api/stats/employees — per-employee listing counts (24h + total) */
router.get("/stats/employees", async (_req, res) => {
  try {
    const now = Date.now();
    const cutoff24h = now - 24 * 60 * 60 * 1000; // ms timestamp 24h ago

    const { rows } = await pool.query<{
      employee_id: string;
      employee_name: string;
      total: string;
      last24h: string;
    }>(`
      SELECT
        employee_id,
        employee_name,
        COUNT(*)::text                                                    AS total,
        COUNT(*) FILTER (WHERE saved_at >= $1)::text                     AS last24h
      FROM saved_cards
      WHERE employee_id IS NOT NULL
      GROUP BY employee_id, employee_name
      ORDER BY COUNT(*) DESC
    `, [cutoff24h]);

    res.json(rows.map(r => ({
      employeeId:   r.employee_id,
      employeeName: r.employee_name,
      total:        Number(r.total),
      last24h:      Number(r.last24h),
    })));
  } catch (err) {
    console.error("stats/employees error:", err);
    res.status(500).json({ error: "فشل جلب الإحصائيات" });
  }
});

/* GET /api/stats/overview — total cards + total submissions */
router.get("/stats/overview", async (_req, res) => {
  try {
    const [cards, subs] = await Promise.all([
      pool.query<{ count: string }>("SELECT COUNT(*)::text AS count FROM saved_cards"),
      pool.query<{ count: string }>("SELECT COUNT(*)::text AS count FROM submissions WHERE status = 'approved'"),
    ]);
    res.json({
      totalCards:    Number(cards.rows[0]?.count ?? 0),
      totalApproved: Number(subs.rows[0]?.count ?? 0),
    });
  } catch {
    res.status(500).json({ error: "فشل جلب الإحصائيات العامة" });
  }
});

export default router;
