import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import path from "path";
import { fileURLToPath } from "url";
import router from "./routes";
import { logger } from "./lib/logger";
import { scheduleAutoSync } from "./routes/sync";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

/* Prevent HTTP caching on all API responses so clients always get fresh data */
app.use("/api", (_req, res, next) => {
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
  res.setHeader("Pragma", "no-cache");
  res.setHeader("Expires", "0");
  next();
});

/* Auto-sync: after every successful write, push to production in background */
app.use("/api", (req, res, next) => {
  const WRITE_METHODS = ["POST", "PUT", "PATCH", "DELETE"];
  const SKIP_PATHS    = ["/sync/", "/auth/"];
  const shouldSync = WRITE_METHODS.includes(req.method) &&
    !SKIP_PATHS.some(p => req.path.startsWith(p));

  if (shouldSync) {
    res.on("finish", () => {
      if (res.statusCode < 400) scheduleAutoSync();
    });
  }
  next();
});

app.use("/api", router);

/* Serve the real-estate-card SPA static files for all non-API routes.
   process.cwd() is the workspace root in both dev and production. */
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
/* dist/index.mjs lives at artifacts/api-server/dist/ — go up two levels to reach workspace root */
const frontendDist = path.resolve(__dirname, "../../real-estate-card/dist/public");

/* Hashed assets (JS/CSS/images) get long-term cache; everything else is no-cache */
app.use(express.static(frontendDist, {
  setHeaders(res, filePath) {
    if (/\/assets\//.test(filePath)) {
      res.setHeader("Cache-Control", "public, max-age=31536000, immutable");
    } else {
      res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");
    }
  },
}));

/* Serve downloadable files from the downloads directory */
const downloadsDir = path.resolve(__dirname, "../downloads");
app.get("/android-project.tar.gz", (_req, res) => {
  const file = path.join(downloadsDir, "android-project.tar.gz");
  res.setHeader("Content-Type", "application/gzip");
  res.setHeader("Content-Disposition", "attachment; filename=android-project.tar.gz");
  res.setHeader("Cache-Control", "no-cache");
  res.sendFile(file, (err) => {
    if (err) res.status(404).json({ error: "File not found" });
  });
});

/* SPA fallback — serve index.html for any unmatched route so React Router works */
app.use((_req, res) => {
  res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
  res.setHeader("Pragma", "no-cache");
  res.setHeader("Expires", "0");
  res.sendFile(path.join(frontendDist, "index.html"));
});

export default app;
