import { scryptSync, randomBytes, timingSafeEqual } from "node:crypto";

const KEYLEN = 64;

/**
 * Hash a plaintext password. Returns a string in the format "salt:hash"
 * using scrypt (CPU/memory-hard, safe for password storage).
 */
export function hashPassword(plaintext: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(plaintext, salt, KEYLEN).toString("hex");
  return `${salt}:${hash}`;
}

/**
 * Verify a plaintext password against a stored "salt:hash" string.
 * Uses timing-safe comparison to prevent timing attacks.
 */
export function verifyPassword(plaintext: string, stored: string): boolean {
  const parts = stored.split(":");
  if (parts.length !== 2) return false;
  const [salt, storedHash] = parts as [string, string];
  try {
    const inputHash = scryptSync(plaintext, salt, KEYLEN);
    const storedBuf = Buffer.from(storedHash, "hex");
    if (inputHash.length !== storedBuf.length) return false;
    return timingSafeEqual(inputHash, storedBuf);
  } catch {
    return false;
  }
}
