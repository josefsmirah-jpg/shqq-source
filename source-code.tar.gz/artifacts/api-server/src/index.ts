import app from "./app";
import { logger } from "./lib/logger";
import { pool } from "@workspace/db";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

/* ── Auto-sync schema on every startup (dev + prod) ── */
async function syncSchema() {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS company_visitors (
        id          TEXT PRIMARY KEY,
        company_name TEXT NOT NULL DEFAULT '',
        phone        TEXT NOT NULL DEFAULT '',
        visited_at   BIGINT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS featured_ads (
        id            SERIAL PRIMARY KEY,
        submission_id VARCHAR(100) NOT NULL,
        company_name  VARCHAR(200) NOT NULL DEFAULT '',
        company_phone VARCHAR(50)  NOT NULL DEFAULT '',
        plan_days     INTEGER NOT NULL,
        plan_label    VARCHAR(100) NOT NULL DEFAULT '',
        plan_price    INTEGER NOT NULL DEFAULT 0,
        status        VARCHAR(20)  NOT NULL DEFAULT 'pending',
        submitted_at  BIGINT NOT NULL,
        approved_at   BIGINT,
        expires_at    BIGINT
      );

      ALTER TABLE featured_ads
        ADD COLUMN IF NOT EXISTS contacts_count INTEGER NOT NULL DEFAULT 0;

      ALTER TABLE saved_cards
        ADD COLUMN IF NOT EXISTS owner_contact TEXT,
        ADD COLUMN IF NOT EXISTS company_name  TEXT;

      ALTER TABLE submissions
        ADD COLUMN IF NOT EXISTS card_data    JSONB,
        ADD COLUMN IF NOT EXISTS card_region  TEXT,
        ADD COLUMN IF NOT EXISTS card_num     INTEGER,
        ADD COLUMN IF NOT EXISTS owner_contact TEXT,
        ADD COLUMN IF NOT EXISTS company_name  TEXT,
        ADD COLUMN IF NOT EXISTS submitted_by  TEXT NOT NULL DEFAULT 'guest';
    `);
    logger.info("Schema sync complete");
  } catch (err) {
    logger.warn({ err }, "Schema sync warning — continuing startup");
  }
}

async function main() {
  // Verify database connectivity on startup (DATABASE_URL must be set)
  try {
    await pool.query("SELECT 1");
    logger.info("Database connection verified");
  } catch (err) {
    logger.error({ err }, "Failed to connect to database — DATABASE_URL must be set and valid");
    process.exit(1);
  }

  await syncSchema();

  app.listen(port, (err) => {
    if (err) {
      logger.error({ err }, "Error listening on port");
      process.exit(1);
    }
    logger.info({ port }, "Server listening");
  });
}

main();
