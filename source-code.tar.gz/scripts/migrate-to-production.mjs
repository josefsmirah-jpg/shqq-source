/**
 * One-time migration script: copies all data from dev DB → production API
 * Run with: node scripts/migrate-to-production.mjs
 */
import pg from "pg";
import { createRequire } from "module";

const PROD_API = "https://design-palette--josefsmirah.replit.app/api";
const J = { "Content-Type": "application/json" };

const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });

async function query(sql, params = []) {
  const res = await pool.query(sql, params);
  return res.rows;
}

async function postToApi(path, body) {
  const r = await fetch(`${PROD_API}${path}`, {
    method: "POST",
    headers: J,
    body: JSON.stringify(body),
  });
  if (!r.ok) {
    const txt = await r.text();
    throw new Error(`POST ${path} → ${r.status}: ${txt.slice(0, 200)}`);
  }
  return r.json();
}

async function run() {
  console.log("🚀 Starting migration from dev → production...\n");

  /* ── 1. Employees ── */
  const employees = await query("SELECT * FROM employees ORDER BY name");
  console.log(`👥 Migrating ${employees.length} employees...`);
  let empOk = 0, empSkip = 0;
  for (const emp of employees) {
    try {
      await postToApi("/employees", {
        id: emp.id, username: emp.username,
        password: emp.password, name: emp.name,
      });
      empOk++;
    } catch (e) {
      if (String(e).includes("409") || String(e).includes("duplicate") || String(e).includes("already")) {
        empSkip++;
      } else {
        console.warn(`  ⚠️  Employee ${emp.name}: ${e.message}`);
      }
    }
  }
  console.log(`  ✓ Employees: ${empOk} added, ${empSkip} already exist\n`);

  /* ── 2. Saved Cards ── */
  const cards = await query("SELECT * FROM saved_cards ORDER BY saved_at");
  console.log(`📋 Migrating ${cards.length} saved cards...`);
  let cardOk = 0, cardSkip = 0;
  for (const c of cards) {
    try {
      await postToApi("/archive", {
        id: c.id, savedAt: Number(c.saved_at),
        region: c.region || "", owner: c.owner || "",
        data: c.data, cardNum: c.card_num,
        ownerContact: c.owner_contact,
      });
      cardOk++;
    } catch (e) {
      if (String(e).includes("409") || String(e).includes("duplicate") || String(e).includes("already")) {
        cardSkip++;
      } else {
        console.warn(`  ⚠️  Card ${c.id}: ${e.message}`);
        cardSkip++;
      }
    }
  }
  console.log(`  ✓ Cards: ${cardOk} added, ${cardSkip} skipped\n`);

  /* ── 3. Submissions ── */
  const subs = await query("SELECT * FROM submissions ORDER BY submitted_at");
  console.log(`📝 Migrating ${subs.length} submissions...`);
  let subOk = 0, subSkip = 0;
  for (const s of subs) {
    try {
      const body = {
        id: s.id, submittedAt: Number(s.submitted_at),
        status: s.status, submittedBy: s.submitted_by || "guest",
        ownerType: s.owner_type || "", propertyType: s.property_type || "",
        region: s.region || "", price: s.price || "",
        floor: s.floor || "", area: s.area || "",
        contactName: s.contact_name || "", phone: s.phone || "",
        description: s.description || "",
        ownerContact: s.owner_contact,
        cardData: s.card_data,
        cardRegion: s.card_region,
        cardNum: s.card_num,
        companyName: s.company_name,
      };
      await postToApi("/submissions", body);
      subOk++;
    } catch (e) {
      if (String(e).includes("409") || String(e).includes("duplicate") || String(e).includes("already")) {
        subSkip++;
      } else {
        console.warn(`  ⚠️  Submission ${s.id}: ${e.message}`);
        subSkip++;
      }
    }
  }
  console.log(`  ✓ Submissions: ${subOk} added, ${subSkip} skipped\n`);

  /* ── 4. Photos ── */
  const photos = await query("SELECT * FROM photos ORDER BY uploaded_at");
  console.log(`📸 Migrating ${photos.length} photos...`);
  let photoOk = 0, photoSkip = 0;
  for (const p of photos) {
    try {
      await postToApi(`/archive/${p.card_id}/photos`, {
        objectPath: p.object_path,
      });
      photoOk++;
    } catch (e) {
      photoSkip++;
    }
  }
  console.log(`  ✓ Photos: ${photoOk} added, ${photoSkip} skipped\n`);

  console.log("✅ Migration complete!");
  await pool.end();
}

run().catch(e => {
  console.error("Migration failed:", e);
  pool.end();
  process.exit(1);
});
