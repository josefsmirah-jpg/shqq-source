#!/usr/bin/env node
/**
 * نقل بيانات Dev → Production عبر API
 * البيانات: saved_cards + submissions + photos
 */

const DEV_URL  = "http://localhost:8080";
const PROD_URL = "https://design-palette--josefsmirah.replit.app";

async function get(url) {
  const r = await fetch(url);
  return r.json();
}

async function post(url, body) {
  const r = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  return r.json();
}

// ===== 1. Cards (bulk) =====
console.log("\n📦 نقل البطاقات...");
const cards = await get(`${DEV_URL}/api/archive`);
const cardsResult = await post(`${PROD_URL}/api/archive/bulk`, cards);
console.log(`✅ بطاقات: ${cardsResult.count} / ${cards.length}`);

// ===== 2. Submissions (one by one) =====
console.log("\n📋 نقل الطلبات...");
const subs = await get(`${DEV_URL}/api/submissions`);
const existingProdSubs = await get(`${PROD_URL}/api/submissions`);
const existingIds = new Set(existingProdSubs.map(s => s.id));

let subOk = 0, subSkip = 0;
for (const s of subs) {
  if (existingIds.has(s.id)) { subSkip++; continue; }
  const r = await post(`${PROD_URL}/api/submissions`, s);
  if (r?.id) subOk++;
  else subSkip++;
}
console.log(`✅ طلبات: ${subOk} جديدة + ${subSkip} موجودة (إجمالي ${subs.length})`);

// ===== 3. Photos (per card) =====
console.log("\n🖼️ نقل الصور...");
let photoOk = 0, photoSkip = 0;
for (const card of cards) {
  const devPhotos = await get(`${DEV_URL}/api/archive/${card.id}/photos`);
  if (!Array.isArray(devPhotos) || devPhotos.length === 0) continue;
  
  const prodPhotos = await get(`${PROD_URL}/api/archive/${card.id}/photos`);
  const existingPhotoIds = new Set(Array.isArray(prodPhotos) ? prodPhotos.map(p => p.id) : []);
  
  for (const photo of devPhotos) {
    if (existingPhotoIds.has(photo.id)) { photoSkip++; continue; }
    const r = await post(`${PROD_URL}/api/archive/${card.id}/photos`, photo);
    if (r?.id) photoOk++;
    else photoSkip++;
  }
}
console.log(`✅ صور: ${photoOk} جديدة + ${photoSkip} موجودة`);

// ===== Final Verification =====
console.log("\n🔍 التحقق النهائي...");
const [pc, ps] = await Promise.all([
  get(`${PROD_URL}/api/archive`),
  get(`${PROD_URL}/api/submissions`),
]);
console.log(`إنتاج: ${pc.length} بطاقة | ${ps.length} طلب`);
console.log("\n✅ اكتملت عملية النقل!");
