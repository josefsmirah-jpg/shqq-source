import { pgTable, serial, varchar, integer, bigint } from "drizzle-orm/pg-core";

export const featuredAdsTable = pgTable("featured_ads", {
  id:           serial("id").primaryKey(),
  submissionId: varchar("submission_id", { length: 100 }).notNull(),
  companyName:  varchar("company_name",  { length: 200 }).notNull().default(""),
  companyPhone: varchar("company_phone", { length: 50  }).notNull().default(""),
  planDays:     integer("plan_days").notNull(),
  planLabel:    varchar("plan_label",  { length: 100 }).notNull(),
  planPrice:    integer("plan_price").notNull(),
  status:       varchar("status", { length: 20 }).notNull().default("pending"),
  submittedAt:    bigint("submitted_at",  { mode: "number" }).notNull(),
  approvedAt:     bigint("approved_at",   { mode: "number" }),
  expiresAt:      bigint("expires_at",    { mode: "number" }),
  contactsCount:  integer("contacts_count").notNull().default(0),
  cardNum:        integer("card_num"),
});
