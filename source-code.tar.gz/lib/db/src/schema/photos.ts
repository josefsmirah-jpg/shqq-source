import { pgTable, text, bigint } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const photosTable = pgTable("photos", {
  id:         text("id").primaryKey(),
  cardId:     text("card_id").notNull(),
  objectPath: text("object_path").notNull(),
  uploadedAt: bigint("uploaded_at", { mode: "number" }).notNull(),
});

export const insertPhotoSchema = createInsertSchema(photosTable);
export type InsertPhoto = z.infer<typeof insertPhotoSchema>;
export type PhotoRow    = typeof photosTable.$inferSelect;
