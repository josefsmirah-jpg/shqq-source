import { pgTable, text, integer, bigint, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const savedCardsTable = pgTable("saved_cards", {
  id:           text("id").primaryKey(),
  savedAt:      bigint("saved_at", { mode: "number" }).notNull(),
  cardNum:      integer("card_num").notNull().default(0),
  region:       text("region").notNull().default(""),
  owner:        text("owner").notNull().default(""),
  guestPhone:   text("guest_phone"),
  ownerContact: text("owner_contact"),
  data:         jsonb("data").notNull(),
  employeeId:   text("employee_id"),
  employeeName: text("employee_name"),
});

export const insertSavedCardSchema = createInsertSchema(savedCardsTable);
export type InsertSavedCard = z.infer<typeof insertSavedCardSchema>;
export type SavedCardRow    = typeof savedCardsTable.$inferSelect;
