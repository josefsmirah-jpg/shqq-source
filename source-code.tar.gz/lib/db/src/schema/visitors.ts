import { pgTable, text, bigint } from "drizzle-orm/pg-core";

export const visitorsTable = pgTable("visitors", {
  id:        text("id").primaryKey(),
  name:      text("name").notNull().default(""),
  phone:     text("phone").notNull().default(""),
  visitedAt: bigint("visited_at", { mode: "number" }).notNull(),
});

export type VisitorRow = typeof visitorsTable.$inferSelect;
