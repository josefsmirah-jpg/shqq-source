import { pgTable, text, bigint } from "drizzle-orm/pg-core";

export const companyVisitorsTable = pgTable("company_visitors", {
  id:          text("id").primaryKey(),
  companyName: text("company_name").notNull().default(""),
  phone:       text("phone").notNull().default(""),
  visitedAt:   bigint("visited_at", { mode: "number" }).notNull(),
});

export type CompanyVisitorRow = typeof companyVisitorsTable.$inferSelect;
