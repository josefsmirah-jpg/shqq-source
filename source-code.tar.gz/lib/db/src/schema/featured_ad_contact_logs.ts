import { pgTable, serial, integer, varchar, bigint } from "drizzle-orm/pg-core";

export const featuredAdContactLogsTable = pgTable("featured_ad_contact_logs", {
  id:            serial("id").primaryKey(),
  featuredAdId:  integer("featured_ad_id").notNull(),
  visitorPhone:  varchar("visitor_phone", { length: 50 }).notNull().default(""),
  ownerPhone:    varchar("owner_phone",   { length: 50 }).notNull().default(""),
  ownerName:     varchar("owner_name",    { length: 200 }).notNull().default(""),
  contactedAt:   bigint("contacted_at",  { mode: "number" }).notNull(),
});
