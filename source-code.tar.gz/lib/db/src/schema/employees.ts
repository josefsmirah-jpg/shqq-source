import { pgTable, text } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const employeesTable = pgTable("employees", {
  id:       text("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name:     text("name").notNull(),
});

export const insertEmployeeSchema = createInsertSchema(employeesTable);
export type InsertEmployee = z.infer<typeof insertEmployeeSchema>;
export type EmployeeRow    = typeof employeesTable.$inferSelect;
