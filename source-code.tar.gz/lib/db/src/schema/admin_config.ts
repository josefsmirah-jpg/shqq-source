import { pgTable, text, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const adminConfigTable = pgTable("admin_config", {
  id:             integer("id").primaryKey().default(1),
  username:       text("username").notNull(),
  passwordHash:   text("password_hash").notNull(),
});

export const insertAdminConfigSchema = createInsertSchema(adminConfigTable);
export type InsertAdminConfig = z.infer<typeof insertAdminConfigSchema>;
export type AdminConfigRow    = typeof adminConfigTable.$inferSelect;
