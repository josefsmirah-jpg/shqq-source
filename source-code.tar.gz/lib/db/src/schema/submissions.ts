import { pgTable, text, bigint, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const submissionsTable = pgTable("submissions", {
  id:           text("id").primaryKey(),
  submittedAt:  bigint("submitted_at", { mode: "number" }).notNull(),
  status:       text("status").notNull().default("pending"),
  submittedBy:  text("submitted_by").notNull().default("guest"),
  ownerType:    text("owner_type").notNull().default(""),
  propertyType: text("property_type").notNull().default(""),
  region:       text("region").notNull().default(""),
  price:        text("price").notNull().default(""),
  floor:        text("floor").notNull().default(""),
  area:         text("area").notNull().default(""),
  contactName:  text("contact_name").notNull().default(""),
  phone:        text("phone").notNull().default(""),
  description:  text("description").notNull().default(""),
  ownerContact: text("owner_contact"),
  cardRegion:   text("card_region"),
  cardData:     jsonb("card_data"),
  cardNum:      text("card_num"),
  employeeId:   text("employee_id"),
  employeeName: text("employee_name"),
  companyName:  text("company_name"),
});

export const insertSubmissionSchema = createInsertSchema(submissionsTable);
export type InsertSubmission = z.infer<typeof insertSubmissionSchema>;
export type SubmissionRow    = typeof submissionsTable.$inferSelect;
